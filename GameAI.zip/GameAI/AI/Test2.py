# -*- coding: utf-8 -*-
import os
import datetime
import random

# 输入 restCards, 玩家当前的手牌，例如[8, 8, 8, 10, 10, 10, 11, 11, 12, 12, 13, 14, 16, 17]
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]

restCards = [8, 8, 8, 10, 10, 10, 11, 11, 12, 12, 13, 14, 16, 17]
landlordCardSequence = [[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
peasantCardSequence = [[10,11,12,13,14],[3,3],[]]

openCards = restCards[:]
for value in landlordCardSequence:
    openCards += value
for value in peasantCardSequence:
    openCards += value
#openCards = restCards + landlordCardSequence + peasantCardSequence
print(openCards)
print(restCards)

cards = [1,2,3,4,5,6,7,8,9,10]
print(cards[0:8])

def Func(list):
    #list = list[1:2]
    #list = [1,2]
    list.pop()
    return list

ret = Func(cards)
print(cards, ret)

ret = [[]]
if ret:
    print("Not Empty")

ret = []
if ret == []:
    print("Empty")

"""
if 0 > None: # Exception
    print("0 > None")
elif 0 == None:
    print("0 == None")
else:
    print("0 < None")
"""

cardCombination = [[3],[4,4],[5,5,5]]
cardCombination.remove([4,4])
print(cardCombination)

print([3] + [[]])
print([] + [[30,40]])
ret = []
ret.append([30,40])
print(ret)
ret.append([])
print(ret)
ret += [[]]
print(ret)

class CardKind(object):
    INVALID = 1000
    SINGLE = 1010 #单张

CardKindOrder = {
    CardKind.INVALID : 1,
    CardKind.SINGLE : 2
}

print(CardKind.SINGLE)
print(CardKindOrder[CardKind.SINGLE])

listElement = [1,2,3,4,5]
print(listElement[4::-1])
print(listElement[::-1])
print(listElement[::-2])

for key in range(-1, 0-len(listElement)-1, -1):
    print(listElement[key])

class AISparringFirstCard(object):
    def __init__(self, name):
        self.name = name
        pass

    @staticmethod
    def Run(self):
        print(self.name)
        return [sys.argv[2]]

obj1 = AISparringFirstCard("Top1")
obj1.Run()

obj2 = AISparringFirstCard("Top2")
obj2.Run()