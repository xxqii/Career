#! /usr/bin/env python
# -*- coding=utf-8 -*-
import itertools

# 组合
#list1 = 'abcd'
list1 = [1,2,3]
list2 = []

for i in range(1,len(list1)+1):
    iter = itertools.combinations(list1,i)
    list2.append(list(iter))

print(list2)

# 排列
#list1 = 'abc'
list1 = [1,2,3]
list2 = []
for i in range(1,len(list1)+1):
    iter = itertools.permutations(list1,i)
    list2.append(list(iter))

print(list2)

c = [1,2,3,4,4,5,5]
a = c
b = [4,5]
a = a + b
print(a,c)
c.remove(5)
c = [1, 'a']
print(c)

def Func(var):
    print("Before：",var)
    var = True
    print("After:", var)

for i in range(1,3):
    Func(i)

var = 1.0
Func(var)
print(var)

bVar = None
if bVar == False:
    print("False")

bVar = False

a = [1,2,3]
a.insert(0, 0)
print(a+[])
print(a.__class__)

class Class(object):
    def __init__(self):
        pass

cla = Class()
print(str(cla.__class__))

args = ('Radical Strategy Choosen', 0.22, [[7, 8, 9, 10, 11], [20, 20]])
for arg in args:
    print(arg, sep='', end=' ')
print()
for arg in args:
    print(arg, sep='', end=' ')