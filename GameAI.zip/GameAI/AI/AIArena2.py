# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-12-28

import random
import datetime
import traceback
import sys

from Util.CardUtil import *
from DouDiZhu2 import *
from AI2Players import *
from AISparringLeft import *
from AISparringRight import *
from Util.LogUtil import *

#二人斗地主 AI VS AI， AI擂台赛，用来优选改进AI

# 牌局结束
def gameOver(winnerRole):
    if winnerRole == CardRole.LANDLORD:
        print("Landlord won")
    else:
        print("Peasant won")
    print("Ended:", datetime.datetime.now())

# 人类出牌
def humanPlayCards(role, game):
    #if game.lastCardKind == []: #引牌
    #else: # 管牌
    ret = []
    print("Now Your rest Cards are:", game.getRestCardsByRole(role))
    while(True):
        rawCardKind = input("Please Input cards you want to play, e.g 3,3,3,4:")
        if rawCardKind:
            #cards = [int(x.strip()) for x in rawCardKind.split(',')]
            cards = []
            for x in rawCardKind.split(','):
                try:
                    cards.append(int(x.strip()))
                except:
                    #traceback.print_exc()
                    continue

            cardKind = generateCardKindFromCards(cards)
            if cardKind != None and isSubList(cardKind, game.getRestCardsByRole(role)):
                if getCardKind(cardKind) == CardKind.INVALID: #输入牌型不正确
                    print("INVALID CardKind Input Cards:", cards)
                # 还需要判断是否能管牌
                elif game.getLastCardArray() == []: # 首牌引牌
                    ret = cardKind
                    break
                elif canCardKindCover(cardKind, game.getLastCardArray()): #管牌，需要比牌
                    ret = cardKind
                    break
                else:
                    print("INVALID Input Cards:", cards, "NOT Larger than:", game.getLastCardArray())
            else:
                print("INVALID Input Cards:", cards)
        else:
            # 首牌、引牌不允许让牌
            if game.getLastCardArray() == []:
                pass
            else:
                ret = []  # 让牌，出空牌
                break
    return ret


def gameRound(game, roleAI1, ai1, ai2):
    # 出牌
    currentRole = CardRole.LANDLORD
    while (True):
        winnerRole = game.isOver()
        if winnerRole == CardRole.INVALID:  # 无人胜利
            pass
        else:  # 地主或者农民胜利
            gameOver(winnerRole)
            return winnerRole
            #break

        cardKind = None
        if currentRole == roleAI1:  # Human
            # cardKind = humanPlayCards(currentRole, game)
            #cardKind = game.AIPlayCards(currentRole, ai1)
            cardKind = ai1.AIPlayCards(currentRole, game)
        else:  # AI
            try:
                #cardKind = game.AIPlayCards(currentRole, ai2)
                cardKind = ai2.AIPlayCards(currentRole, game)
            except:
                traceback.print_exc()

        if currentRole == CardRole.LANDLORD:
            LogUtil.Log("Landlord Played:", cardKind)
        elif currentRole == CardRole.PEASANT:
            LogUtil.Log("Peasant Played:", cardKind)
        else:
            print("Exception Role Invallid:", currentRole)
            raise BaseException("Exception Invalid CardRole:", currentRole)

        game.playedCards(currentRole, cardKind)
        currentRole = getNextRole2Players(currentRole)

'''
print("脚本名：", sys.argv[0])
for i in range(1, len(sys.argv)):
    print("参数", i, sys.argv[i])
'''

totalCount = 10
if len(sys.argv) > 1:
    totalCount = int(sys.argv[1])
#print("Usage: AIArena2 leftAI RightAI totalCount")
print("Total Cycle Count:", totalCount)

# 选择身份
'''
order = int(input("Which identity do AI1 want? Landlord is 1, Peasant is 0:"))
roleAI1 = CardRole.INVALID
if order == 1:
    roleAI1 = CardRole.LANDLORD
else:
    roleAI1 = CardRole.PEASANT
'''
#TODO 可以用到命令行参数argv和反射
leftAI = AISparringLeft()
rightAI = AISparringRight()
print("Left AI: ", leftAI.__class__)
print("Right AI: ", rightAI.__class__)

leftAIAsLandlordWonCount = 0
leftAIAsPeasantWonCount = 0
rightAIAsLandlordWonCount = 0
rightAIAsPeasantWonCount = 0
LogUtil.logOutDisabled()
for i in range(0, totalCount, 1):
    # 发牌
    cards = initCardsFor2Players()
    #cards = initCardsFor2Players17vs17()
    landlord_cards = cards[0]  # 地主20张牌
    peasant_cards = cards[1]  # 农民剩下的17张牌，之前20:-1有BUG，少了一张牌

    landlord_cards = sorted(landlord_cards)
    peasant_cards = sorted(peasant_cards)

    landlordGame = DouDiZhu2(landlord_cards, peasant_cards)
    print("Started:", datetime.datetime.now())
    print("landlord_cards = ", landlord_cards)
    print("peasant_cards = ", peasant_cards)

    landlordRoundRole = gameRound(landlordGame, CardRole.LANDLORD, leftAI, rightAI)
    if landlordRoundRole == CardRole.LANDLORD:
        leftAIAsLandlordWonCount += 1
    else:
        rightAIAsPeasantWonCount += 1
    print("Result:As LANDLORD", leftAIAsLandlordWonCount, ":", rightAIAsPeasantWonCount)

    peasantGame = DouDiZhu2(landlord_cards, peasant_cards)
    peasantRoundRole = gameRound(peasantGame, CardRole.PEASANT, leftAI, rightAI)
    if peasantRoundRole == CardRole.LANDLORD:
        rightAIAsLandlordWonCount += 1
    else:
        leftAIAsPeasantWonCount += 1
    print("Result: As PEASANT", leftAIAsPeasantWonCount, ":", rightAIAsLandlordWonCount)

    #if landlordRoundRole != peasantRoundRole: #同一手牌，AI身份互换之后，结果不一样，需要记录,所以再打一次，并记录
    if landlordRoundRole == CardRole.PEASANT and peasantRoundRole == CardRole.LANDLORD:
        LogUtil.logOutEnabled()
        landlordGame = DouDiZhu2(landlord_cards, peasant_cards)
        gameRound(landlordGame, CardRole.LANDLORD, leftAI, rightAI)
        peasantGame = DouDiZhu2(landlord_cards, peasant_cards)
        gameRound(peasantGame, CardRole.PEASANT, leftAI, rightAI)
        LogUtil.logOutDisabled()

    print("Result: Total Left Vs Right", leftAIAsLandlordWonCount + leftAIAsPeasantWonCount, \
          ":", rightAIAsLandlordWonCount + rightAIAsPeasantWonCount)