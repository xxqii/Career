import random
import datetime
import traceback
import sys

from Util.CardUtil import *
from DouDiZhu3 import *
from AI3Players import *
from AISparringLeft import *
from AISparringRight import *
from Util.LogUtil import *

# 牌局结束
def gameOver(winnerRole):
    if winnerRole == CardRole.LANDLORD:
        print("Landlord won")
    else:
        print("Peasant won")
    print("Ended:", datetime.datetime.now())

# 人类出牌
def humanPlayCards(role, game):
    #if game.lastCardKind == []: #引牌
    #else: # 管牌
    ret = []
    print("Now Your rest Cards are:", game.getRestCardsByRole(role))
    while(True):
        rawCardKind = input("Please Input cards you want to play, e.g 3,3,3,4:")
        if rawCardKind:
            #cards = [int(x.strip()) for x in rawCardKind.split(',')]
            cards = []
            for x in rawCardKind.split(','):
                try:
                    cards.append(int(x.strip()))
                except:
                    #traceback.print_exc()
                    continue

            cardKind = generateCardKindFromCards(cards)
            if cardKind != None and isSubList(cardKind, game.getRestCardsByRole(role)):
                if getCardKind(cardKind) == CardKind.INVALID: #输入牌型不正确
                    print("INVALID CardKind Input Cards:", cards)
                # 还需要判断是否能管牌
                elif game.getLastCardKind() == []: # 首牌引牌
                    ret = cardKind
                    break
                elif canCardKindCover(cardKind, game.getLastCardKind()): #管牌，需要比牌
                    ret = cardKind
                    break
                else:
                    print("INVALID Input Cards:", cards, "NOT Larger than:", game.getLastCardKind())
            else:
                print("INVALID Input Cards:", cards)
        else:
            # 首牌、引牌不允许让牌
            if game.getLastCardKind() == []:
                pass
            else:
                ret = []  # 让牌，出空牌
                break
    return ret

def gameRound(game, roleAI1, roleAI2, ai1, ai2, ai3):
    # 出牌
    currentRole = CardRole.LANDLORD
    while(True):
        winnerRole = game.isOver()
        if winnerRole == CardRole.INVALID:
            pass
        else:
            gameOver(winnerRole)
            return winnerRole

        cardKind = None
        if currentRole == roleAI1:
            #cardKind = game.AIPlayCards(currentRole, ai1)
            cardKind = ai1.AIPlayCards(currentRole, game)
        elif currentRole == roleAI2:
            #cardKind = game.AIPlayCards(currentRole, ai2)
            cardKind = ai2.AIPlayCards(currentRole, game)
        else:
            #cardKind = game.AIPlayCards(currentRole, ai3)
            cardKind = ai3.AIPlayCards(currentRole, game)
        '''
        else: # AI
            try:
                cardKind = game.AIPlayCards(currentRole, ai2)
            except:
                traceback.print_exc()
        '''

        if currentRole == CardRole.LANDLORD:
            LogUtil.Log("Landlord Played:", cardKind)
        elif currentRole == CardRole.PEASANT_DOWN:
            LogUtil.Log("Peasant_down played: ", cardKind)
        elif currentRole == CardRole.PEASANT_UP:
            LogUtil.Log("Peasant_up played: ", cardKind)
        else:
            print("Exception Role Invalid:", currentRole)
            raise BaseException("Exception Role Invalid")

        game.playedCards(currentRole, cardKind)
        currentRole = getNextRole3Players(currentRole)

totalCount = 1
if len(sys.argv) > 1:
    totalCount = int(sys.argv[1])
print("Total Cycle Count:", totalCount)

landAI = AISparringLeft()
peaDownAI = AISparringRight()
peaUpAI = AISparringRight()
print("land AI: ", landAI.__class__)
print("peaDownAI: ", peaDownAI.__class__)
print("peaUpAI: ", peaUpAI.__class__)

leftAIAsLandlordWonCount = 0
leftAIAsPeasantWonCount = 0
rightAIAsLandlordWonCount = 0
rightAIAsPeasantWonCount = 0

for i in range(0, totalCount, 1):
    # 发牌
    cards = initCardsFor3Players()
    landlord_cards = sorted(cards[0])
    down_peasant_cards = sorted(cards[1])
    up_peasant_cards = sorted(cards[2])

    landlordGame = DouDiZhu3(landlord_cards, down_peasant_cards, up_peasant_cards)

    print("Started: ", datetime.datetime.now())
    print("landlord_cards = ", landlord_cards)
    print("peasant_down_cards = ", down_peasant_cards)
    print("peasant_up_cards = ", up_peasant_cards)

    landlordRoundRole = gameRound(landlordGame, CardRole.LANDLORD, CardRole.PEASANT_DOWN, landAI, peaDownAI, peaUpAI)
    if landlordRoundRole == CardRole.LANDLORD:
        leftAIAsLandlordWonCount += 1
    else:
        rightAIAsPeasantWonCount += 1
    print("Result: As LANDLORD", leftAIAsLandlordWonCount, ":", rightAIAsPeasantWonCount)

    peasantGame = DouDiZhu3(landlord_cards, down_peasant_cards, up_peasant_cards)
    peasantRoundRole_down = gameRound(peasantGame, CardRole.PEASANT_DOWN, CardRole.PEASANT_UP, landAI, peaDownAI, peaUpAI)

    #peasantRoundRole = gameRound(peasantGame, CardRole.PEASANT, leftAI, rightAI)
    if peasantRoundRole_down == CardRole.LANDLORD:
        rightAIAsLandlordWonCount += 1
    else:
        leftAIAsPeasantWonCount += 1
    print("Result: As PEASANT", leftAIAsPeasantWonCount, ":", rightAIAsLandlordWonCount)

    peasantGame = DouDiZhu3(landlord_cards, down_peasant_cards, up_peasant_cards)
    peasantRoundRole_up = gameRound(peasantGame, CardRole.PEASANT_UP, CardRole.LANDLORD, landAI, peaDownAI, peaUpAI)
    if peasantRoundRole_up == CardRole.LANDLORD:
        rightAIAsLandlordWonCount += 1
    else:
        leftAIAsPeasantWonCount += 1

    if (landlordRoundRole == CardRole.PEASANT_UP or landlordRoundRole == CardRole.PEASANT_DOWN) \
        and (peasantRoundRole_down == CardRole.LANDLORD or peasantRoundRole_up == CardRole.LANDLORD):
        LogUtil.logOutEnabled()
        landlordGame = DouDiZhu3(landlord_cards, down_peasant_cards, up_peasant_cards)
        #gameRound(landlordGame, CardRole.LANDLORD, leftAI, rightAI)
        gameRound(peasantGame, CardRole.LANDLORD, CardRole.PEASANT_DOWN, landAI, peaDownAI, peaUpAI)
        peasantGame = DouDiZhu3(landlord_cards, down_peasant_cards, up_peasant_cards)
        #gameRound(peasantGame, CardRole.PEASANT, leftAI, rightAI)
        gameRound(peasantGame, CardRole.LANDLORD, CardRole.PEASANT_DOWN, landAI, peaDownAI, peaUpAI)
        LogUtil.logOutDisabled()

    print("Result: Total Left Vs Right", leftAIAsLandlordWonCount + leftAIAsPeasantWonCount, \
          ":", rightAIAsLandlordWonCount + rightAIAsPeasantWonCount)
