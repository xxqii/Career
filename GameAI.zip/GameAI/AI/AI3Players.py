# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-12-17

# 三人斗地主决策AI
from Util.CardUtil import *
from Util.LogUtil import *

from Strategy import *
from Value import *

from AI2Players import *

class AI3Players(AI2Players):
    def __init__(self):
        AI2Players.__init__(self)

    @staticmethod
    def getLeadRankAsController(gameInfo, cardArray, power, param, cardCombination): #大值先出
        ret = 0.0
        addition = 0.0
        size = len(cardCombination)
        restCardsLength = 0
        for cardKind in cardCombination:
            restCardsLength += len(cardKind)
            if getCardKind(cardKind) in (CardKind.BOMB,CardKind.ROCKET):
                size = size - 2
        restCardsLength -= len(cardArray)
        if size <= 1: # TODO 除了骗炸或者使用炸弹，没理由不一把收牌
            addition += 10000

        # 三人斗地主非农民且无法控牌，考虑冲牌
        elif gameInfo.getCurrentRole() != CardRole.LANDLORD and canControl(cardCombination, gameInfo) == False \
                and restCardsLength <= 2:
            if restCardsLength == 1: #可以一步冲到单报
                addition += 2000
            elif restCardsLength == 2:  #可以一步冲到双报
                addition += 1000

        #value = min(power, 100)
        value = min(power, 100 * param)
        #ret = value * 1000 - size * 20 + (len(cardArray) / cardArray[0] if len(cardArray) > 0 else 0)
        weakPoints = getWeakPoints(cardCombination, gameInfo)
        #ret = value * 10 - weakPoints * 20 * param + (len(cardArray) + CardValue.Card_2 - cardArray[0])/10
        ret = value * 10 - weakPoints * 20 * param + (len(cardArray) / (cardArray[0] + cardArray[-1]))
        ret += addition
        LogUtil.Log("getLeadRankAsController:", ret, cardArray, value, "weakPoints=", weakPoints, cardCombination)
        return ret

    @staticmethod
    def getLeadRankAsRunner(cardArray, power, size): #大值先出
        if size == 1: # TODO 除了骗炸或者使用炸弹，没理由不出
            return 999999 + power

        ret = len(cardArray) * power * (20 - size) #长牌、短组合先出
        return ret

    @staticmethod
    def getFirstRank(cardArray, power, param, cardCombination, gameInfo): #小值优先出
        kind = getCardKind(cardArray)
        rate = power / param
        value = 100 - min(rate, 100)  # 需要忽略炸弹翻倍的影响
        size = len(cardCombination)
        weakPoints = getWeakPoints(cardCombination, gameInfo)
        if kind in (CardKind.BOMB, CardKind.ROCKET): # TODO 炸弹不轻出
            ret = value * 10 + weakPoints * 20  + 100
        else:
            ret = value * 10 + weakPoints * 20

        cardValue = (cardArray[0] + cardArray[-1])
        ret += cardValue
        if rate > 80: # 80%胜率，加强之
            ret /= param
        elif rate < 30: # 胜率不足，削弱之
            ret *= param

        LogUtil.Log("getFirstRank:", ret, cardArray, value, weakPoints, cardValue)
        return ret

    @staticmethod
    def getCoverRank(cardArray, power, param, cardCombination, gameInfo): #小值优先出
        kind = getCardKind(cardArray)
        rate = power/param
        value = 100 - min(power/param, 100)
        weakPoints = getWeakPoints(cardCombination, gameInfo)
        '''
        if kind in (CardKind.BOMB, CardKind.ROCKET): # TODO 炸弹不轻出
            ret = value * 10 + weakPoints * 20 + 100
        else:
            ret = value * 10 + weakPoints * 20
        '''
        ret = value * 10 + weakPoints * 20 + 2000 - kind

        if len(cardArray) == 0: #空牌，对于长牌、大牌，降权小；对于短牌、小牌，降权多
            cardValue = CardValue.Card_R + CardValue.Card_R
        else:
            cardValue = (cardArray[0] + cardArray[-1])

        ret += cardValue
        if rate > 80: # 80%胜率，加强之
            ret /= param
        elif rate < 30: # 胜率不足，削弱之
            ret *= param
        LogUtil.Log("getCoverRank:", cardArray, ret, value, param, "weakPoints=", weakPoints, cardValue)
        return ret

    @staticmethod
    def getGuardRank(cardArray, power, param, cardCombination, gameInfo): #大值优先
        keyCardValue = cardArray[0]
        kind = getCardKind(cardArray)
        size = len(cardCombination)
        weakPoints = getWeakPoints(cardCombination, gameInfo)
        #if power >= 90: # 任何一个牌组有80%以上的牌力，则参考管牌，主要按照牌力来排序
        #    ret = power * 100 + GuardCardRank[keyCardValue] * 10 - size * 5
        if len(cardArray) == 1: #单张
            ret = GuardCardRank[keyCardValue] * 10 + power - weakPoints * 2
        elif kind == CardKind.BOMB or kind == CardKind.ROCKET:
            ret = 0 + power - weakPoints * 2
        else:
            #ret = keyCardValue + power - size * 2
            ret = GuardCardRank[keyCardValue] * 10 + power - weakPoints * 2
        LogUtil.Log("getGuardRank:", ret, cardArray, power, weakPoints)
        return ret

    # 首牌决策
    # 输入gameInfo,包含现在的所有牌局信息，参见DouDiZhu2的类定义
    # 输入 initCards，地主初始20张手牌，例如[6, 6, 6, 7, 7, 7, 8, 8, 8, 10, 10, 10, 11, 11, 12, 12, 13, 14, 16, 17]
    # 输出 可能的出牌 牌型List，例如[[5]] 或者 [[3,3],[5,5,5,4]]
    def FirstCard(self, gameInfo):
        #sortedCards = sorted(initCards)
        sortedCards = gameInfo.getRestCards()

        cardsList = []
        cardsList.append(sortedCards)
        cardCombinations = combinateCardsList(cardsList)
        # for key, combination in enumerate(cardCombinations):
        #    print("Combinated:", key, combination)

        cardCombinations = adjustCardCombinations(cardCombinations, gameInfo)
        # for key, combination in enumerate(cardCombinations):
        #    print("Adjusted:", key, combination)

        cardCombinations = plusCardCombinations(cardCombinations)
        # for key, combination in enumerate(cardCombinations):
        #     print("Plus:", key, combination)
        # sys.exit()

        # 选出Top N，
        valuedCardCombinations = valuationCardCombinations(cardCombinations, gameInfo)
        for valuedCardCombination in valuedCardCombinations:
            if len(valuedCardCombination[3:]) == 1: # 只有首牌需要判断一手春天 TODO 春天概率判断？
                valuedCardCombination[1] *= 2.0

        # for key, combination in enumerate(cardCombinations):
        #    print("Top:", key+1, combination)
        # sys.exit()

        # 以及对应的出牌序列
        #cardOrders = sortCardCombinations(valuedCardCombinations, gameInfo, quick=False)
        cardOrders = orderCardCombinations(cardCombinations, gameInfo, lead=True)

        # 降序，主关键词为首位Value值降序，次级关键词为牌组长度升序，三级关键词为出牌长度/出牌的keyCardValue升序
        #cardOrders.sort(key=lambda comb: comb[2] * 10000 + 400 - len(comb[3:]) * 20 + (len(comb[0]) / comb[0][0] if len(comb[0]) > 0 else 0),
        #             reverse=True)
        cardOrders.sort(key=lambda comb: self.getFirstRank(comb[0], comb[2], comb[3], comb[4:], gameInfo), reverse=False)

        LogUtil.Log("===========FirstCard===========")
        for key, kind in enumerate(cardOrders):
            #print("Top:", key + 1, cardCombinations[key][1],cardCombinations[key][0], "First:", kind, "->", cardCombinations[key][2:])
            #print("Top:", key + 1, kind[2], kind[1], "First:", kind[0], "->",kind[3:])
            LogUtil.Log("Top:", key + 1, kind[2], "First:", kind[0], "->", kind[3:])

        return cardOrders

    # 引牌决策，三人斗地主，地主出牌
    def __LandlordLeadCard(self, gameInfo):
        #pass
        #return CardDecision2.LeadCard(gameInfo)
        # 合并生成所有明牌
        openCards = gameInfo.getOpenedCards()
        restCards = gameInfo.getRestCards()

        cardsList = []
        cardsList.append(restCards)
        cardCombinations = combinateCardsList(cardsList)
        # for key, combination in enumerate(cardCombinations):
        #    print("Combinated:", key, combination)

        cardCombinations = adjustCardCombinations(cardCombinations, gameInfo)
        # for key, combination in enumerate(cardCombinations):
        #    print("Adjusted:", key, combination)

        cardCombinations = plusCardCombinations(cardCombinations)
        # for key, combination in enumerate(cardCombinations):
        #     print("Plus:", key, combination)
        # sys.exit()

        # 以及对应的出牌序列
        cardOrders = orderCardCombinations(cardCombinations, gameInfo, True)
        # 降序，主关键词为首位Value值逆序，次级关键词为牌组长度顺序，三级关键词为出牌长度/出牌的keyCardValue顺序
        #cardOrders.sort(key=lambda comb: comb[2] * 10000 + 400 - len(comb[3:]) * 20 + (len(comb[0]) / comb[0][0] if len(comb[0]) > 0 else 0),
        #             reverse=True)
        cardOrders.sort(key=lambda comb: self.getLeadRankAsController(gameInfo, comb[0], comb[2], comb[3], comb[4:]), reverse=True)

        for key, kind in enumerate(cardOrders):
            LogUtil.Log("Top:", key + 1, kind[2], "Lead:", kind[0], "->", kind[3:])
            #print("Top:", key + 1, kind[2], "Lead:", kind[0], "->", kind[3:])
        '''
        ret = []
        ret.append(cardOrders[0][0])  # 只返回第一个
        return ret
        '''
        return cardOrders

    # 引牌决策，三人斗地主，农民出牌，农民需要判断是打主力还是打辅助
    def __PeasantDownLeadCard(self, gameInfo):
        #对于农民而言，可以冲牌，即跑到手中只剩1-2张牌
        return self.__LandlordLeadCard(gameInfo)

    # 引牌决策，三人斗地主，农民出牌，农民需要判断是打主力还是打辅助
    def __PeasantUpLeadCard(self, gameInfo):
        #pass
        #return CardDecision2.LeadCard(gameInfo)
        # 合并生成所有明牌
        openCards = gameInfo.getOpenedCards()
        restCards = gameInfo.getRestCards()

        cardsList = []
        cardsList.append(restCards)
        cardCombinations = combinateCardsList(cardsList)
        # for key, combination in enumerate(cardCombinations):
        #    print("Combinated:", key, combination)

        cardCombinations = adjustCardCombinations(cardCombinations, gameInfo)
        # for key, combination in enumerate(cardCombinations):
        #    print("Adjusted:", key, combination)

        cardCombinations = plusCardCombinations(cardCombinations)
        # for key, combination in enumerate(cardCombinations):
        #     print("Plus:", key, combination)
        # sys.exit()

        # 以及对应的出牌序列
        cardOrders = orderCardCombinations(cardCombinations, gameInfo, True)
        # 降序，主关键词为首位Value值逆序，次级关键词为牌组长度顺序，三级关键词为出牌长度/出牌的keyCardValue顺序
        cardOrders.sort(key=lambda comb: self.getLeadRankAsController(gameInfo, comb[0], comb[2], comb[3], comb[4:]), reverse=True)

        for key, kind in enumerate(cardOrders):
            LogUtil.Log("Top:", key + 1, kind[2], "Lead:", kind[0], "->", kind[3:])

        return cardOrders

    # 引牌决策，三人斗地主，分成保守和稳健两种打法，结合猜牌和出牌序列，例如对手如果某牌型小牌没有管则继续出该牌型小牌
    # 另外，如果队友可走牌，则配合送控牌权。例如，如果队友只有一两张牌，则打小单张/小对子
    # AI3Players.leadCard Vs AI2Players.leadCard
    # Result: Total Left Vs Right 50854 : 49146
    # Result: Total Left Vs Right 50804 : 49196
    def LeadCard(self, gameInfo):
        currentRole = gameInfo.getCurrentRole()
        if currentRole == CardRole.LANDLORD:
            return self.__LandlordLeadCard(gameInfo)
        elif currentRole == CardRole.PEASANT_UP:
            return self.__PeasantUpLeadCard(gameInfo)
        else:
            return self.__PeasantDownLeadCard(gameInfo)

    # 跟牌决策，作为地主下家跟地主牌，交给地主上家去管
    # 本着提升牌力的原则，同等牌力的情况下，出最小的牌
    def FollowCard(self, gameInfo):
        #return CardDecision2.CoverCard(gameInfo)
        retList = []
        # 合并生成所有明牌
        lastCardKind = gameInfo.getLastCardArray()
        restCards = gameInfo.getRestCards()
        openCards = gameInfo.getOpenedCards()
        initPower = getCardPowerFromCards([], restCards, gameInfo)
        LogUtil.Log("Follow Card Init:", initPower)

        # 列举出管牌的情况并计算最大牌力
        cardKindList = getCoverableCardKind(lastCardKind, restCards)
        for cardKind in cardKindList:
            kind = getCardKind(cardKind)
            currentCardList = restCards[:]
            for card in cardKind:
                currentCardList.remove(card)

            cardCombinations = combinateCardsList([currentCardList])
            cardCombinations = adjustCardCombinations(cardCombinations, gameInfo)
            cardCombinations = plusCardCombinations(cardCombinations)

            currentRole = gameInfo.getCurrentRole()
            if currentRole == CardRole.PEASANT_UP:
                power = valuationCardCombinations(cardCombinations, gameInfo,lead=False)
                power = power[0]
                value = power[1]
                cardCombination = power[3:]
            else:
                power = getCardPowerFromCards(cardKind, currentCardList, gameInfo)
                value = power[0]
                cardCombination = power[2:]

            #if value > initPower[0] + 1.0 or value >= 90: #TODO 有机会就冲一冲？有待验证
            if value > initPower[0] + 0.0 or value >= 90:  # TODO 有机会就冲一冲？有待验证
                #retList.append([value] + [cardKind] + power[1:])
                retList.append([value] + [cardKind] + cardCombination)

        if len(retList) == 0:
            LogUtil.Log("Followed Card: None")
            #print("Followd Card: None")
            return [[]] # 不管

        # 降序，主关键词为首位Value值，次级关键词为牌组长度逆序，三级关键词为出牌的keyCardValue
        retList.sort(key=lambda comb: comb[0] * 1 - len(comb[2:]) * 2 + (len(comb[1]) - comb[1][0] if len(comb[1]) > 0 else 0),
                     reverse=True)
        retList = retList[0:ConstCard.TOP_BY_COUNT]
        LogUtil.Log("Init:", initPower[0], initPower[1:])
        retArray = []
        for key, value in enumerate(retList):
            LogUtil.Log("Top:", key + 1, retList[key][0], "Follow:", retList[key][1], "->", retList[key][2:])
            ret = []
            ret.append(value[1])
            ret.append(value[0])
            ret += value[2:]
            retArray.append(ret)
        return retArray

    # 顶牌决策，三人斗地主，作为地主上家，顶队友地主下家的牌，不让地主轻易走牌
    # 本着提升牌力的原则，同等牌力的情况下，出最大的牌
    # TODO 如果不能提升牌力，且队友出的是小单张/对子，那么使用管牌？
    # TODO 顶牌只有在单张/对子小牌的情况下才考虑，有中牌用中牌顶，有大牌用大牌管，但是不能转手出小单/对，不行就跟牌了
    def GuardCard(self, gameInfo):
        #print("Guard Card: ", gameInfo.getLastCardKind())
        #return CardDecision3.FollowCard(gameInfo)
        retList = []
        # 合并生成所有明牌
        lastCardKind = gameInfo.getLastCardArray()
        restCards = gameInfo.getRestCards()
        openCards = gameInfo.getOpenedCards()
        initPower = getCardPowerFromCards([], restCards, gameInfo)
        LogUtil.Log("Guard Card Init:", initPower)
        #print("Init:", initPower)

        # 列举出管牌的情况并计算最大牌力
        cardKindList = getCoverableCardKind(lastCardKind, restCards)
        for cardKind in cardKindList:
            kind = getCardKind(cardKind)
            currentCardList = restCards[:]
            for card in cardKind:
                currentCardList.remove(card)
            power = getCardPowerFromCards(cardKind, currentCardList, gameInfo)
            value = power[0]
            if value > initPower[0] * 0.40 or value > initPower[0] - 30: #顶牌需要付出牺牲，暂定60%
                retList.append([value] + [cardKind] + power[1:])

        if len(retList) == 0:
            LogUtil.Log("Guard Card: None")
            #print("Guard Card: None")
            return [[]] # 不管

        # 降序，主关键词为出牌的keyCardValue，次级关键词为首位Value值, TODO 这里需要实现 顶牌的话 单张中牌优先
        #retList.sort(key=lambda comb: comb[0] * 100 + 40 - len(comb[2:]) * 2 + 10 * (len(comb[1]) * comb[1][0]), reverse=True)
        retList.sort(key=lambda comb: self.getGuardRank(comb[1], comb[0], comb[2], comb[3:], gameInfo), reverse=True)
        retList = retList[0:ConstCard.TOP_BY_COUNT]
        retArray = []
        for key, value in enumerate(retList):
            LogUtil.Log("Top:", key + 1, retList[key][0], "Guard:", retList[key][1], "->", retList[key][2:])
            ret = []
            ret.append(value[1])
            ret.append(value[0])
            ret += value[2:]
            retArray.append(ret)
        return retArray

    # 内部私有的 真正的管牌决策函数
    def _CoverCard(self, gameInfo):
        retList = []
        currentRole = gameInfo.getCurrentRole()
        lastCardRole = gameInfo.getLastCardRole()
        lastCardRoleLeadCount = gameInfo.getRoleLeadCount(lastCardRole)
        opponentRestCardslength = gameInfo.getOpponentRestCardsLength()
        nFactor = 0.81 #牺牲系数，降低不管牌的牌权
        if lastCardRoleLeadCount == 2: #争夺第3手
            nParam = 0.6
        elif lastCardRoleLeadCount == 3: #争夺第4手
            nParam = 0.3
        elif lastCardRoleLeadCount > 3: #对手出第5手牌了，必须管
            nParam = 0.0
        else:
            nParam = 1.0
        # 根据引牌次数 和 剩余牌数，做系数调整，去最小值
        if opponentRestCardslength <= 5 and nParam > (opponentRestCardslength / 5 - 0.20):
            if currentRole == CardRole.LANDLORD: # 地主采用相对保守的让牌降权系数
                nParam = (opponentRestCardslength / 5 - 0.20)
            else: #农民采取相对激进的让牌降权系数 废除
                #power[0] = power[0] - max(10, power[0] * (1.20 - opponentRestCardslength / 5))
                nParam = (opponentRestCardslength / 5 - 0.20)
        nFactor = nFactor * nParam

        # 合并生成所有明牌
        lastCardKind = gameInfo.getLastCardArray()
        restCards = gameInfo.getRestCards()
        openCards = gameInfo.getOpenedCards()
        #LogUtil.Log("_CoverCard nFactor:", nFactor, lastCardKind)

        # 列举出管牌的情况并计算最大牌力
        cardKindList = getCoverableCardKind(lastCardKind, restCards)
        for cardKind in cardKindList:
            kind = getCardKind(cardKind)
            currentCardList = restCards[:]
            for card in cardKind:
                currentCardList.remove(card)
            power = getCardPowerFromCards(cardKind, currentCardList, gameInfo)
            value = power[0]
            retList.append([value] + [cardKind] + power[1:])

        # 计算让牌情况下的牌力
        power = getCardPowerFromCards([], restCards, gameInfo)

        # 让牌需要对价值做下调,所以乘以系数；让牌降权系数和对手剩余牌数量有关
        power[0] = min(power[0] * nFactor, power[0] - 5.0)  # 0.9 * 0.9
        if power[0] < 0:
            power[0] = 0

        retList.append([power[0]] + [[]] + power[1:])

        #三级关键词为出牌的keyCardValue 降序 VS 升序 Result: Total Left Vs Right 24024 : 25976  Result: Total Left Vs Right 24055 : 25945
        # 所以改成升序
        # 三级关键词改成降序试试， 结果果然总体不好
        #retList.sort(key=lambda comb: comb[0] * 10000 + 400 - len(comb[2:]) * 20 + (comb[1][0] if len(comb[1]) > 0 else 0),
        #             reverse=True)
        # 主关键词为首位Value值降序，次级关键词为牌组长度升序，三级关键词为出牌的keyCardValue升序
        #retList.sort(key=lambda comb: comb[0] * 10000 + 400 - len(comb[2:]) * 20 + (100/comb[1][0] if len(comb[1]) > 0 else 0),
        #             reverse=True)
        if opponentRestCardslength == 1 and isSingle(lastCardKind):
            if gameInfo.getCurrentRole() == CardRole.PEASANT_DOWN: # 下家还可以适度顺牌
                retList.sort(key=lambda comb: comb[0] * 1000 + 40 - len(comb[3:]) * 2 + (comb[1][0] if len(comb[1]) > 0 else 0),
                             reverse=True)
            else: #地主和顶家必须用最大牌来管了
                retList.sort(key=lambda comb: (comb[1][0] if len(comb[1]) > 0 else 0) * 100 + comb[0], reverse=True)
        else:
            retList.sort(key=lambda comb: self.getCoverRank(comb[1], comb[0], comb[2], comb[3:], gameInfo), reverse=False)

        retList = retList[0:ConstCard.TOP_BY_COUNT]
        retArray = []
        for key, value in enumerate(retList):
            LogUtil.Log("Top:", key + 1, retList[key][0], "Cover:", retList[key][1], "->", retList[key][2:])
            ret = []
            ret.append(value[1])
            ret.append(value[0])
            ret += value[2:]
            retArray.append(ret)
        return retArray

    # AI出牌决策
    def AIPlayCards(self, role, gameInfo):
        # 上一次出牌为空，首牌/引牌
        if gameInfo.getLastCardArray() == []:
            #if len(gameInfo.getRestCards()) == 20:  # 首牌情况
            if len(gameInfo.playedCardsSequence) == 0:  # 首牌情况，一张牌都还没出呢
                ret = self.FirstCard(gameInfo)
            else:  # 引牌情况
                if role == CardRole.LANDLORD:
                    ret = self.LeadCard(gameInfo)
                elif role == CardRole.PEASANT_UP:
                    ret = self.LeadCard(gameInfo)
                elif role == CardRole.PEASANT_DOWN:
                    ret = self.LeadCard(gameInfo)
                elif role == CardRole.PEASANT: #TODO 兼容二人斗地主
                    ret = self.LeadCard(gameInfo)
                else:
                    print("Exception Role Invalid:",role)
        else:
            # 管牌情况
            if role == CardRole.LANDLORD:
                ret = self.CoverCard(gameInfo)
            elif role == CardRole.PEASANT_UP:
                ret = self.CoverCard(gameInfo)
            elif role == CardRole.PEASANT_DOWN:
                ret = self.CoverCard(gameInfo)
            elif role == CardRole.PEASANT: #TODO 兼容二人斗地主
                ret = self.CoverCard(gameInfo)
            else:
                print("Exception Role Invalid:", role)
        if len(ret[0]) > 0 and isinstance(ret[0][0], list):
            return ret[0][0]
        else: # 为空牌的情况
            return ret[0]

    def CoverCard(self, gameInfo):
        currentRole = gameInfo.getCurrentRole()
        if currentRole == CardRole.LANDLORD:
            return self.__LandlordCoverCard(gameInfo)
        elif currentRole == CardRole.PEASANT_DOWN:
            return self.__PeasantDownCoverCard(gameInfo)
        elif currentRole == CardRole.PEASANT_UP:
            return self.__PeasantUpCoverCard(gameInfo)
        elif currentRole == CardRole.PEASANT: #兼容二人斗地主
            return self._CoverCard(gameInfo)
        else:
            raise BaseException("Exception Invalid CardRole:", currentRole)

    # 管牌入口，地主的牌，下家尽可能顺，上家尽可能管；队友的牌，对自己特别有利则管
    # 三人斗地主，地主管农民的牌；地主上家管地主的牌(下家空牌或者顺牌的情况下)；
    # 地主上家的牌，如果地主不管，则地主下家也不会管
    # 地主下家的牌，地主上家需要顶牌
    #TODO 管牌的时候什么时候选择管死策略，什么时候选择消耗策略？目前优选管死策略
    def __LandlordCoverCard(self, gameInfo):
        lastCardRole = gameInfo.getLastCardRole()
        lastCardRoleLeadCount = gameInfo.getRoleLeadCount(lastCardRole)
        currentRole = gameInfo.getCurrentRole()
        lastCardKind = gameInfo.getLastCardArray()
        kind = getCardKind(lastCardKind)
        lastCardWeight = getCardWeight(gameInfo, lastCardKind, kind, quick=False)
        keyCardValue = lastCardKind[0]
        keyCardClass = getCardClass(keyCardValue)
        opponentRestCardsLength = gameInfo.getOpponentRestCardsLength()
        if lastCardRole == CardRole.PEASANT_DOWN: #重点打击对象
            return self._CoverCard(gameInfo)
        elif lastCardRole == CardRole.PEASANT_UP:
            return self._CoverCard(gameInfo)
        else:
            raise BaseException("Exception CardRole Invalid:", lastCardRole)

    # 顶家管牌入口
    def __PeasantUpCoverCard(self, gameInfo):
        lastCardRole = gameInfo.getLastCardRole()
        lastCardRoleLeadCount = gameInfo.getRoleLeadCount(lastCardRole)
        currentRole = gameInfo.getCurrentRole()
        lastCardKind = gameInfo.getLastCardArray()
        kind = getCardKind(lastCardKind)
        lastCardWeight = getCardWeight(gameInfo, lastCardKind, kind, quick=False)
        keyCardValue = lastCardKind[0]
        keyCardClass = getCardClass(keyCardValue)
        opponentRestCardsLength = gameInfo.getOpponentRestCardsLength()
        restCards = gameInfo.getRestCards()
        restCardsLength = len(restCards)
        if lastCardRole == CardRole.LANDLORD:
            # 地主下家没有管,那么地主上家要管了
            if keyCardClass == CardClass.SMALL and len(lastCardKind) == 1 and lastCardWeight <= 0.6 and restCardsLength > 2:  # 小单张必须顶
                return self.GuardCard(gameInfo)
            else:
                return self._CoverCard(gameInfo)
        else:  # 地主下家出的牌，地主上家需要顶牌
            partnerRestCardsLength = gameInfo.getRestCardsLengthByRole(CardRole.PEASANT_DOWN)
            if opponentRestCardsLength <= 2 and len(lastCardKind) == opponentRestCardsLength:  # 地主只剩一两张牌的情况，必须兜住
                return self._CoverCard(gameInfo)
            elif partnerRestCardsLength <= 2:  # 如果队友手中只剩下1-2张牌，那么不管
                LogUtil.Log("Direct PASS, Welcome Partner, GO!")
                return [[]]
            elif keyCardClass == CardClass.SMALL and len(lastCardKind) == 1 and lastCardWeight <= 0.6 and restCardsLength > 2:  # 小牌的单张
                return self.GuardCard(gameInfo)
            elif keyCardClass == CardClass.SMALL and len(lastCardKind) == 2 and lastCardWeight <= 0.6:  # 小牌的对子
                return self.FollowCard(gameInfo) #TODO 对不过6怎么实现？
            elif gameInfo.getRoleLeadCount(CardRole.LANDLORD) >= 4 and lastCardWeight <= 0.9:  # 地主已经出到第4手牌了
                return self._CoverCard(gameInfo)
            # elif keyCardClass == CardClass.LARGE: #友方的大牌,直接PASS
            elif lastCardWeight >= 0.9:
                LogUtil.Log("Direct PASS, Power Cards")
                return [[]]
            else:  # 其他情况，上家可选择顺牌，TODO 如果有能力收牌则Cover之
                partnerRestCardsLength = gameInfo.getRestCardsLengthByRole(CardRole.PEASANT_DOWN)
                if partnerRestCardsLength <= 2:  # 如果队友手中只剩下1-2张牌，那么不管
                    LogUtil.Log("Direct PASS, Welcome Partner, GO!")
                    return [[]]

                coverCardArrayList = self._CoverCard(gameInfo)
                if len(coverCardArrayList[0]) > 0 and coverCardArrayList[0][1] > 90:  # 有能力收牌
                    return coverCardArrayList
                else:
                    return self.FollowCard(gameInfo)

    # 下家管牌入口
    def __PeasantDownCoverCard(self, gameInfo):
        lastCardRole = gameInfo.getLastCardRole()
        lastCardRoleLeadCount = gameInfo.getRoleLeadCount(lastCardRole)
        currentRole = gameInfo.getCurrentRole()
        lastCardKind = gameInfo.getLastCardArray()
        kind = getCardKind(lastCardKind)
        lastCardWeight = getCardWeight(gameInfo, lastCardKind, kind, quick=False)
        keyCardValue = lastCardKind[0]
        keyCardClass = getCardClass(keyCardValue)
        opponentRestCardsLength = gameInfo.getOpponentRestCardsLength()
        if lastCardRole == CardRole.LANDLORD: # TODO 中牌是不是应该尽可能管上？
            if keyCardClass == CardClass.SMALL and len(lastCardKind) <= 2 and opponentRestCardsLength > 2:  # 小单张、对子
                return self.FollowCard(gameInfo)
            elif lastCardRoleLeadCount >= 2:  # 地主第2次掌握牌权了
                return self._CoverCard(gameInfo)
            else:
                #return self.FollowCard(gameInfo)
                return self._CoverCard(gameInfo)
        else:  # 地主上家出的牌，地主没有管，那么地主下家一般选择让牌
            partnerRestCardsLength = gameInfo.getRestCardsLengthByRole(CardRole.PEASANT_UP)
            if partnerRestCardsLength <= 2:  # 如果队友手中只剩下1-2张牌，那么不管
                LogUtil.Log("Direct PASS, Welcome Partner, GO!")
                return [[]]

            # 判断队友在顶牌，所以管上
            if isSingle(lastCardKind) and getCardClass(lastCardKind[0]) == CardClass.MIDDLE:
                return self._CoverCard(gameInfo)

            followCardArrayList = self.FollowCard(gameInfo)
            followCardArray = followCardArrayList[0]
            '''
            if keyCardValue >= CardValue.Card_2:
                LogUtil.Log("Direct PASS, Large Cards")
                return [[]]  # 让牌
            '''
            if len(followCardArray) > 0:
                cardCombination = followCardArray[3:]
                cardArray = followCardArray[0]
                bCanControl = canControl(cardCombination, gameInfo)
                bCanRush = canRush(cardCombination, gameInfo)
                if len(cardArray) <=2 and cardArray[0] <= CardValue.Card_10: # 小单张对子可顺走
                    return followCardArrayList
                elif bCanControl == True:
                    LogUtil.Log("Direct PASS, Can Control, So Let Partner GO!")
                    return [[]]
                elif bCanRush == True:
                    return followCardArrayList
                elif followCardArray[1] > 80: #80%以上的胜率
                    return followCardArrayList
                else:
                    LogUtil.Log("Direct PASS, Need NOT Follow")
                    return [[]]  # 让牌
            else:
                LogUtil.Log("Direct PASS, Can NOT Follow")
                return [[]]  # 让牌