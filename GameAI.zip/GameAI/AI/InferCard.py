# -*- coding: utf-8 -*-
#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2017-05-14

# 算牌猜牌模块，即根据已有信息推算对手/队友手中剩余的暗牌
from Util.CardUtil import *

# 算单牌、对子、三带、四炸等概率
def InferCardKindByRole(gameInfo, cardRole, kind, keyCardValue):
    if kind == CardKind.SINGLE:
        pass

# 猜测牌组，例如 4个单张，2单+1对，2个对子，三代1，四炸
def InferCardCombination(gameInfo, cardRole, length, kindList):
    pass