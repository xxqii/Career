# -*- coding: utf-8 -*- 
import os
import datetime
import random

L = [10,20,30]
L.remove(20)
for i in L:
	print(i)

dict = {'Name': 'Zara', 'Age': 7, 'Class': 'First'};
print(dict.get('Default'))
#for i in range(1,100):
#	print(i)

for k,v in enumerate(L):
	print(k,v)
	L.remove(L[k])
	L.append(40)

for i in range(10, 1, -2):
	print(i)

ret = [2]
ret += []
print(ret)

#for i in range(1,10):
#	print(i)

ret = [[1,1],[2,2]]
ret += []
print("+=", ret)

ret = []
#ret = [[]]
#ret.append([])
ret += [1]
print("+=", ret)

ret = [1,2,3,4]
print(ret[0:1],ret[1:4])
print(ret[0])

for i in range(10,-1,-1):
	print(i)

a = [1,3,4,5,7]
maxValue = max(a, key = lambda value:abs(value-4))
print("Max:", maxValue)

ret = a.pop(0)
print(ret)
print(a)

b = [a]
print(b)

a = [1,3,4,5,7]
c = [1,2,3,4,5,6,7,7]
d = [item for item in c if item not in a]
print("Minus:", d)

list1 = [1,2,3,4,5]
str1 = str(list1)
list1 = int(str1)
print(list1)