# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-12-17

# 三人斗地主的牌局信息

from DouDiZhu2 import *

class DouDiZhu3(DouDiZhu2):
    def __init__(self, landlordCards, downPeasantCards, upPeasantCards):
        self.initLandlordCards = landlordCards[:] # 初始的地主手牌
        self.initUpPeasantCards = upPeasantCards[:] # 初始的地主上家农民手牌
        self.initDownPeasantCards = downPeasantCards[:]  # 初始的地主下家农民手牌

        self.landlordCards = landlordCards[:] #当前的地主手牌，总是排好序的
        self.landlordCards.sort()
        self.upPeasantCards = upPeasantCards[:] # 当前的地主上家农民手牌，总是排好序的
        self.upPeasantCards.sort()
        self.downPeasantCards = downPeasantCards[:] # 当前的地主上家农民手牌，总是排好序的
        self.downPeasantCards.sort()

        self.lastCardArray = [] # 当前轮上一家出的牌型，对于首牌，为空；
        self.lastCardRole = None #上一家的角色

        self.landlordCardSequence = []  # 地主出牌序列
        self.upPeasantCardSequence = []  # 地主上家农民出牌序列
        self.downPeasantCardSequence = []  # 地主下家农民出牌序列
        self.playedCardsSequence = []  # [角色，出牌]二元组组成的列表

        self.topCardKindForPeasant = {} #农民方的大牌 规则：地主出的，农民管不起的牌，用炸弹火箭管不算管了
        self.topCardKindForLandlord = {} #地主方的大牌 规则：农民出的，地主管不起的牌，用炸弹火箭管不算管了

        self.currentRole = CardRole.LANDLORD # 三人斗地主当前轮到出牌的角色

        self.landlordOpenedCards = self.landlordCards[:] # 地主方的公开的牌，总是排好序的
        self.upPeasantOpenedCards = self.upPeasantCards[:] # 地主上家农民方的公开的牌，总是排好序的
        self.downPeasantOpenedCards = self.downPeasantCards[:]  # 地主下家农民方的公开的牌，总是排好序的

        self.playedTotalTurns = 0 #当前轮数，出到争夺控牌权结束称之一轮
        self.roleGotLeads = {CardRole.LANDLORD : 0, CardRole.PEASANT_DOWN : 0, CardRole.PEASANT_UP : 0} # 每个角色引牌次数，首牌也计入引牌

    @staticmethod
    def getPlayers():
        return 3

    def getRestCardsByRole(self, role):
        if role == CardRole.LANDLORD:
            return self.landlordCards
        elif role == CardRole.PEASANT_UP:
            return self.upPeasantCards
        elif role == CardRole.PEASANT_DOWN:
            return self.downPeasantCards
        else:
            print("Exception Role Invalid:", role)
            return []

    def getRestCards(self):
        if self.currentRole == CardRole.LANDLORD:
            return self.landlordCards
        elif self.currentRole == CardRole.PEASANT_UP:
            return self.upPeasantCards
        elif self.currentRole == CardRole.PEASANT_DOWN:
            return self.downPeasantCards
        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return []

    def getOtherRestCards(self):
        if self.currentRole == CardRole.LANDLORD:
            ret = self.upPeasantCards + self.downPeasantCards
            ret.sort()
            return ret

        elif self.currentRole == CardRole.PEASANT_UP:
            ret = self.landlordCards + self.downPeasantCards
            ret.sort()
            return ret

        elif self.currentRole == CardRole.PEASANT_DOWN:
            ret = self.landlordCards + self.upPeasantCards
            ret.sort()
            return ret

        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return []

    def getOpenedCards(self):
        if self.currentRole == CardRole.LANDLORD:
            return self.landlordOpenedCards
        elif self.currentRole == CardRole.PEASANT_UP:
            return self.upPeasantOpenedCards
        elif self.currentRole == CardRole.PEASANT_DOWN:
            return self.downPeasantOpenedCards
        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return []

    # 获得农民某一牌型 最近没有管的牌， 那么大于该牌的牌型，对手很大可能没法管
    def __getPeasantLastDuckedCardKind(self, kind):
        pass

    # 获得地主某一牌型 最近没法管的牌(用炸弹火箭管除外)， 那么大于该牌的牌型，对手很大可能没法管
    def __getLandlordLastDuckedCardKind(self, kind):
        #return super(DouDiZhu3, self)._getLastDuckedCardKindByRole(role, kind)
        #逆序查找
        length = len(self.playedCardsSequence)
        if length < self.getPlayers(): # 一轮都没打
            return []

        start = -1
        while(self.playedCardsSequence[start][0] != CardRole.LANDLORD):
            start = start - 1

        end = 2 - len(self.playedCardsSequence) # self.playedCardsSequence[2]
        index = start
        topCardKindKeyCardValue = CardValue.Card_Min
        while(index >= end):
            element = self.playedCardsSequence[index]
            playedRole = element[0]
            #if playedRole != CardRole.LANDLORD:
            #    raise BaseException("playedCardsSequence INVALID!")

            playedCards = element[1]

            upElement = self.playedCardsSequence[index-1]
            downElement = self.playedCardsSequence[index-2]
            keyCardValue = CardValue.Card_Min
            prevElement = None
            if upElement[1] != []:
                prevElement = upElement
            elif downElement[1] != []:
                prevElement = downElement
            else: # up peasant and down peasant both ducked!
                index = index - self.getPlayers()
                continue

            keyCardValue = prevElement[1][0]
            prevElementKind = getCardKind(prevElement[1])
            passed = False
            if prevElementKind == kind:
            #if prevElementKind == kind and playedRole == CardRole.LANDLORD:
                if playedCards == []:
                    passed = True
                else:
                    elementKind = getCardKind(playedCards)
                    if elementKind == CardKind.BOMB or elementKind == CardKind.ROCKET:
                        passed = True

                if passed == False:#找出管了的最大牌
                    if keyCardValue > topCardKindKeyCardValue:
                        topCardKindKeyCardValue = keyCardValue
                else:
                    if keyCardValue > topCardKindKeyCardValue:
                        #LogUtil.Log(role, kind, prevElement[1])
                        return prevElement[1]
            index = index - self.getPlayers()
        return []

    # 获得对手某一牌型 最近没法管的牌(用炸弹火箭管除外)， 那么大于该牌的牌型，对手很大可能没法管
    def getOpponentLastDuckedCardKind(self, kind):
        if self.currentRole == CardRole.LANDLORD:
            #TODO 类型如三带系列是否可以归并？
            if kind in self.topCardKindForPeasant:
                return self.topCardKindForPeasant[kind]
            else:
                return []
        else:
            if kind in self.topCardKindForLandlord:
                return self.topCardKindForLandlord[kind]
            else:
                return []

    def getRestCardsLengthByRole(self, role):
        if role == CardRole.LANDLORD:
            return len(self.landlordCards)
        elif role == CardRole.PEASANT_DOWN:
            return len(self.downPeasantCards)
        else:
            return len(self.upPeasantCards)

    def getOpponentRestCardsLength(self):
        if self.currentRole == CardRole.LANDLORD: #TODO:返回地主下家，还是地主上家和下家的最小值？
            #return len(self.downPeasantCards)
            return min(len(self.upPeasantCards),len(self.downPeasantCards))
        elif self.currentRole == CardRole.PEASANT_UP:
            return len(self.landlordCards)
        elif self.currentRole == CardRole.PEASANT_DOWN:
            return len(self.landlordCards)
        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return 0

    def getAllOpponentsRestCardsLength(self):
        if self.currentRole == CardRole.LANDLORD:
            return [len(self.downPeasantCards),len(self.upPeasantCards)]
        elif self.currentRole == CardRole.PEASANT_UP:
            return [len(self.landlordCards)]
        elif self.currentRole == CardRole.PEASANT_DOWN:
            return [len(self.landlordCards)]
        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return [0]

    def getLastCardArray(self):
        return self.lastCardArray

    def getLastCardRole(self):
        return self.lastCardRole

    def getCurrentRole(self):
        return self.currentRole

    # 出牌，更新数据
    def playedCards(self, role, cardKind):
        # 上一次出牌为空，首牌/引牌
        if self.getLastCardArray() == []:
            self.playedTotalTurns += 1
            self.roleGotLeads[self.currentRole] += 1
            #LogUtil.Log("roleGotLeads:", self.roleGotLeads[self.currentRole], "playedTotalTurns:", self.playedTotalTurns)

        kind = getCardKind(self.lastCardArray)
        if cardKind != []: #出了牌，所以控牌权变更
            kindLast = getCardKind(cardKind)
            if kindLast != CardKind.BOMB and kindLast != CardKind.ROCKET: #用炸弹火箭管牌不计
                #TODO 这里头可能有个顺子、连对的长短对应问题
                if self.lastCardRole == CardRole.LANDLORD: # 地主的牌被(农民)管了
                    topCardArray = self.topCardKindForPeasant.get(kind)
                    if topCardArray and (cardKind[0] >= topCardArray[0]):
                        self.topCardKindForPeasant.pop(kind)
                elif self.currentRole == CardRole.LANDLORD: # 农民的牌被地主管了
                    topCardArray = self.topCardKindForLandlord.get(kind)
                    if topCardArray and (cardKind[0] >= topCardArray[0]):
                        self.topCardKindForLandlord.pop(kind)
            # 当前控牌角色转变
            self.lastCardArray = cardKind[:]
            self.lastCardRole = role

        elif self.lastCardRole == CardRole.LANDLORD and role == CardRole.PEASANT_UP: # 地主的牌地主上家让了,地主控牌
            self.topCardKindForPeasant[kind] = self.lastCardArray[:]
            self.lastCardArray = []

        elif self.lastCardRole == CardRole.PEASANT_UP and role == CardRole.PEASANT_DOWN: # 地主上家的牌，地主下家都让了,地主上家控牌
            self.lastCardArray = []

        elif self.lastCardRole == CardRole.PEASANT_UP and role == CardRole.LANDLORD: # 地主上家的牌，地主让了,地主上家控牌
            self.topCardKindForLandlord[kind] = self.lastCardArray[:]

        elif self.lastCardRole == CardRole.PEASANT_DOWN and role == CardRole.LANDLORD: # 地主下家的牌，地主都让了,地主下家控牌
            self.topCardKindForLandlord[kind] = self.lastCardArray[:]
            self.lastCardArray = []

        if role == CardRole.LANDLORD:
            self.landlordCardSequence.append(self.lastCardArray)
            self.playedCardsSequence.append([CardRole.LANDLORD, self.lastCardArray])
            for card in cardKind:
                self.landlordCards.remove(card)
            self.landlordCards.sort()

            self.currentRole = CardRole.PEASANT_DOWN
            self.upPeasantOpenedCards += cardKind
            self.upPeasantOpenedCards.sort()
            self.downPeasantOpenedCards += cardKind
            self.downPeasantOpenedCards.sort()

        elif role == CardRole.PEASANT_UP:
            self.upPeasantCardSequence.append(self.lastCardArray)
            self.playedCardsSequence.append([CardRole.PEASANT_UP, self.lastCardArray])
            for card in cardKind:
                self.upPeasantCards.remove(card)
            self.upPeasantCards.sort()

            self.currentRole = CardRole.LANDLORD
            self.landlordOpenedCards += cardKind
            self.landlordOpenedCards.sort()
            self.downPeasantOpenedCards += cardKind
            self.downPeasantOpenedCards.sort()

        elif role == CardRole.PEASANT_DOWN:
            self.downPeasantCardSequence.append(self.lastCardArray)
            self.playedCardsSequence.append([CardRole.PEASANT_DOWN, self.lastCardArray])
            for card in cardKind:
                self.downPeasantCards.remove(card)
            self.downPeasantCards.sort()

            self.currentRole = CardRole.PEASANT_UP
            self.landlordOpenedCards += cardKind
            self.landlordOpenedCards.sort()
            self.upPeasantOpenedCards += cardKind
            self.upPeasantOpenedCards.sort()

        else:
            print("Exception Role Invalid:", role)
            return []

        if self.lastCardArray == []: #控牌权转移
            self.currentRole = self.lastCardRole

    def isOver(self):
        if self.landlordCards == []:
            return CardRole.LANDLORD
        elif self.upPeasantCards == []:
            return CardRole.PEASANT_UP
        elif self.downPeasantCards == []:
            return CardRole.PEASANT_DOWN
        else:
            return CardRole.INVALID

    '''
    def AIPlayCards(self, role, cardDecision):
        # 上一次出牌为空，首牌/引牌
        #cardDecison = CardDecision3()
        if self.getLastCardKind() == []:
            if len(self.getRestCards()) == 20:  # 首牌情况
                ret = cardDecision.FirstCard(self)
            else:  # 引牌情况
                if role == CardRole.LANDLORD:
                    ret = cardDecision.LeadCard(self)
                elif role == CardRole.PEASANT_UP:
                    ret = cardDecision.LeadCard(self)
                elif role == CardRole.PEASANT_DOWN:
                    ret = cardDecision.LeadCard(self)
                else:
                    print("Exception Role Invalid:",role)
        else:
            # 管牌情况
            if role == CardRole.LANDLORD:
                ret = cardDecision.CoverCard(self)
            elif role == CardRole.PEASANT_UP:
                ret = cardDecision.CoverCard(self)
            elif role == CardRole.PEASANT_DOWN:
                ret = cardDecision.CoverCard(self)
            else:
                print("Exception Role Invalid:", role)
        return ret[0]
    '''