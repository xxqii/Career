# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2017-03-30

# 叫牌AI，根据17张牌，选择不叫，叫1分，2分，3分
# 判定结果：叫牌之后，随机打100局？
import random
import sys
import os

from Strategy import *
from Value import *
from Util.CardUtil import *

def correctNormalValuesForBit(normalValues, correctValues):
    correctCount = 0
    for k, v in enumerate(normalValues): # 优先匹配最佳牌型来校正(提升)
        maxKey = None
        maxRatio = 0.0
        for key, value in enumerate(correctValues):
            if value[0] > v[0] and v[0] < 1.0:
                kind = getCardKind(value[1])
                if kind in (CardKind.BOMB, CardKind.ROCKET): #炸弹肯定能夺回牌权
                    ratio = 1.0
                elif kind == getCardKind(v[1]): #correct和normal类型相同
                    ratio = 1.01 # 校正，即调高之，牌型相同所以损失小
                elif len(value[1]) < len(v[1]): # 短牌型 控 长牌型，可能性比较小
                    ratio = 0.95 # 校正，即调高之，原有的指标要打折，因为控牌权不一定能抢回来
                else: # 长牌型 控 短牌型，可能性相对较大
                    ratio = 0.98
                if ratio > maxRatio:
                    maxRatio = ratio
                    maxKey = key
        if maxKey != None:
            if maxRatio > 1.0 : #同牌型取值为1.01，之所以先定义为1.01又调整为0.99，是为了优先使用同牌型来校准
                maxRatio = 0.99

            maxValue = correctValues[maxKey]
            if normalValues[k][0] < maxValue[0] * maxRatio:
                normalValues[k][0] = maxValue[0] * maxRatio
                correctValues.pop(maxKey)  # 删除保存用来校准的大牌价值
                if maxRatio not in (0.99,1.0): # 同类型自然校正或者炸弹校正，不计校正次数
                    correctCount += 1
        # 考虑以下情况，容易忽略有大牌照应的拆散情况。调高打折系数为0.9
        #cards = [3, 3, 3, 4, 4, 5, 6, 7, 7, 7, 8, 8, 9, 11, 11, 13, 13, 14, 20, 40]
        #Top: 1 [0.0488, [3, 3], [3, 4, 5, 6, 7, 8, 9], [4], [7, 7], [8], [11, 11], [13, 13], [14], [20], [40]]
        #Top: 2 [0.04800000000000001, [3, 3, 3, 8], [4, 4], [5, 6, 7, 8, 9], [7, 7], [11, 11], [13, 13], [14], [20], [40]]

    # DEBUG info
    #if quick == False:
    #    print("Corrected NormalValues:", normalValues, correctValues)

    totalValue = 1.0 #百分数
    for value in normalValues:
        totalValue = totalValue * value[0]

    # 多出来的大牌需要加权重，最多乘两次，1.15 * 1.15 = 1.3225
    #count = min(len(correctValues), 2)
    improveCount = 0
    if totalValue < 0.8: # 对不足的加权，最多牌力加满到0.8即可
        for key, value in enumerate(correctValues):
            if key > 3 or totalValue > 0.8:
                break
            totalValue = totalValue * (1 + max(value[0] - 0.80, 0))
            improveCount += 1
    totalValue = min(totalValue, 1.0)
    #totalValue -= totalValue * 0.02 * correctCount
    #totalValue += (len(correctValues) - improveCount) * 0.01
    return totalValue

def valuationCardCombinationsForBit(cardCombinations, gameInfo, lead=False):
    quickRet = []
    for cardCombination in cardCombinations:
        valuedComb = valuationCardCombinationForBit(cardCombination, gameInfo, True, lead)
        quickRet.append(valuedComb)
    #quickRet.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    quickRet.sort(key= lambda comb : comb[0], reverse=True) #降序，只对次位Value值排序
    quickRet = quickRet[0:ConstCard.TOP_BY_COUNT] #粗选N个
    #return quickRet

    ret = []
    for valuedComb in quickRet:
        cardCombination = valuedComb[3:]
        tempValuedComb = valuationCardCombinationForBit(cardCombination, gameInfo, False, lead)
        ret.append(tempValuedComb)
    # ret.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    # 降序，只对次位Value值排序,次级关键词为牌组长度
    #ret.sort(key= lambda comb : comb[0] * 100 + 20 - len(comb[3:]), reverse=True)
    ret.sort(key=lambda comb: comb[0] * comb[2] + comb[1] + 20 - len(comb[3:]), reverse=True)
    ret = ret[0:ConstCard.TOP_BY_COUNT]
    return ret

def valuationCardCombinationForBit(cardCombination, gameInfo, quick = True, lead = False):
    ret = []
    cardKindsArray = {}
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        if cardKindsArray.get(kind):
            cardKindsArray[kind].append(cardKind)
        else:
            cardKindsArray[kind] = []
            cardKindsArray[kind].append(cardKind)

    normalValues = [] #每轮出牌的大牌指数，即被管概率, cardArray, value 牌型牌权的二元组
    correctValues = [] #校正，多出来的大牌可以抢夺发牌权，所以可以替换掉一个最小的normalValue，cardArray, value 牌型牌权的二元组
    param = 1.0 # 春天/炸弹指数， 暂时忽略春天
    # 之前已经排好序了，按分类 单双三带一 连对顺子组队, 飞机暂时认为无敌
    kindValues = []
    for kind, cardKindArray in cardKindsArray.items():
        param, kindValue = autoBoxing(kind, cardKindArray, gameInfo, normalValues, correctValues, param, quick)
        kindValues += kindValue
    '''
    if quick == False:
        LogUtil.logOutEnabled()
        LogUtil.Log(cardCombination)
        LogUtil.Log(kindValues)
        LogUtil.logOutDisabled()
    '''
    # 移除中牌,认为中牌中牌权小于阈值的可以跟着偷跑
    # 限制为单张+对子最多2个
    followedCount = 0
    for key,value in enumerate(normalValues[:]):
        kind = getCardKind(value[1])
        cardClass = getCardClass(value[1][0])
        if cardClass == CardClass.MIDDLE and followedCount < 3 and \
            kind in (CardKind.SINGLE, CardKind.PAIR):
            normalValues.remove(value)
            followedCount += 1
        elif cardClass == CardClass.MIDDLE and \
            kind in (CardKind.THREE, CardKind.THREE_PLUS1, CardKind.THREE_PLUS2):
            normalValues.remove(value)

    normalValues.sort(key=lambda value : value[0])
    '''
    if quick == False:
        LogUtil.logOutEnabled()
        LogUtil.Log("normalValues:", normalValues)
        LogUtil.Log("correctValues:", correctValues)
        LogUtil.logOutDisabled()
    '''

    if len(normalValues) > 0 and lead == True:
        normalValues.pop(0) #因为是地主，有优先出牌权，所以可以去掉一轮
    correctValues.sort(key=lambda value : value[0], reverse=True) #先用最大值校对，避免重复校对同一项，后来的覆盖前面的

    #correctCount = len(correctValues)
    rawValue = 1.0
    for value in normalValues:
        rawValue *= value[0]

    totalValue = correctNormalValuesForBit(normalValues, correctValues)
    if totalValue < 0.0:
        totalValue = 0.0

    correctCount = len(correctValues)
    carriedCount = 0
    for cardArray in cardCombination:
        kind = getCardKind(cardArray)
        if kind == CardKind.THREE:
            carriedCount += 1
        elif kind ==  CardKind.PLANE_EMPTY:
            carriedCount += len(cardArray) / 3

    for cardValue in correctValues:
        kind = getCardKind(cardValue[1])
        if kind == CardKind.BOMB: #四带二，所以carry+1
            carriedCount += 1
        #elif kind == CardKind.ROCKET: #拆开成双王?
        #    carriedCount += 1

    totalValue *= 100 #转为百分数
    ret.append(totalValue)
    ret.append(rawValue * 100)
    ret.append(correctCount + carriedCount)
    ret += cardCombination
    return ret

# 测试发牌程序，计算火箭的概率
def testInitCards(total):
    # print(cardsLib)
    count = 0
    matched = 0
    while count < total:
        count = count + 1
        slice = initCards()
        # print(slice)

        found = 0
        for card in slice:
            if card == CardValue.Card_B:
                found = found + 1
            if card == CardValue.Card_R:
                found = found + 1
        if found == 2:
            matched = matched + 1
    print(matched)
    return matched

_cardsLib_for_3players = (3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10,
                          11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14,
                          20, 20, 20, 20, 30, 40)

def initCardsFor3PlayersBit(cards = []):
    retList = []
    length = len(cards)
    if length == 17:
        retList.append(cards) #手里拿到的牌
        cardsLib = list(_cardsLib_for_3players)
        for card in cards:
            cardsLib.remove(card)
        initCardsList = random.sample(cardsLib, 34)
        retList.append(initCardsList[0:17]) #三人斗地主
        retList.append(initCardsList[17:])  # 三人斗地主
        for card in initCardsList:
            cardsLib.remove(card)
        retList.append(cardsLib)  # 剩下的牌为底牌
    elif length == 0:
        initCardsList = random.sample(_cardsLib_for_3players, 51)
        retList.append(initCardsList[0:17])
        retList.append(initCardsList[17:34])
        retList.append(initCardsList[34:])

        cardsLib = list(_cardsLib_for_3players)
        for card in initCardsList:
            cardsLib.remove(card)
        retList.append(cardsLib) # 剩下的牌为底牌
    else:
        raise BaseException("Cards Length Invalid", len(cards), cards)

    for ret in retList: #排序
        ret.sort()
    return retList

cards = []
#以下《我是地主我怕谁》牌例
#cards = [3,4,5,6,6,7,10,11,12,13,14,14,20,20,20,30,40] # 牌例3-4 3分
#cards = [3,3,4,4,6,6,8,8,9,10,11,12,20,20,20,20,40] # 牌例3-5 2分？
#cards = [4,4,4,4,5,6,6,7,8,9,10,11,12,14,14,14,30] # 牌例3-6
#cards = [3,4,5,6,7,7,8,9,11,12,13,14,14,20,20,20,40] #牌例3-7
#cards = [3,4,5,6,7,7,8,9,11,12,13,14,14,20,20,20,40] #牌例3-8
#cards = [3,4,4,4,5,6,7,10,11,12,12,13,14,14,14,20,40] #牌例3-9 2分？
#cards = [3,4,5,7,8,8,8,12,12,12,13,13,13,14,14,20,40] #牌例3-10
#cards = [4,5,7,8,9,11,11,11,11,12,13,13,14,20,20,20,40] #牌例 3-11 点睛之博 1分？
#cards = [3,4,5,5,6,7,7,8,9,9,9,9,12,12,13,20,40] # 3-12 2分？
#cards = [3,3,4,4,4,5,7,8,11,11,12,12,13,20,20,20,30] # 3-13 强将弱兵 1分？
#cards = [3,3,4,5,6,7,8,8,10,11,11,11,13,14,20,20,40] # 3-14 1分？
#以上《我是地主我怕谁》 3分案例

#cards = [3,4,5,5,6,7,8,8,9,10,11,11,13,13,14,20,40] # 3-15
#cards = [4,4,6,6,8,9,9,10,10,12,12,13,13,14,14,20,20] # 3-16
#cards = [3,4,4,6,6,6,8,9,9,9,11,12,12,14,20,20,30] # 3-17 1分？
#cards = [3,3,4,7,7,7,7,10,11,12,12,13,13,13,14,20,20] # 3-18 3分？
#cards = [3,3,3,4,6,7,7,8,9,10,11,13,13,14,14,14,14] # 3-19 0分？
#cards = [5,6,7,7,8,9,9,10,11,11,12,13,13,13,13,20,40] # 3-20 3分？
#以上《我是地主我怕谁》 2分案例

#cards = [3,5,6,7,7,7,8,9,10,11,11,13,13,13,13,14,30] # 3-21 3分? 有问题
#cards = [3,3,3,4,5,5,6,7,7,7,8,8,11,12,12,20,30] # 3-22 0分？
#cards = [3,3,3,3,4,4,4,5,7,8,10,10,11,12,13,13,20] # 3-23
#cards = [3,5,5,6,7,7,7,8,9,10,11,11,11,12,12,13,40] # 3-24 0分？
#以上《我是地主我怕谁》 1分案例

#cards = [3,4,5,6,7,7,8,8,9,9,10,10,11,11,12,13,14] # 3-25 0分
#cards = [4,5,5,5,5,6,6,6,7,8,8,8,10,12,13,20,20] # 3-26 2分？
#cards = [3,4,5,5,6,7,7,8,9,10,11,11,13,14,14,14,40] # 3-27 3分？
#cards = [3,3,3,4,5,6,7,8,9,10,10,11,12,13,14,20,30] # 3-28 3分？
#cards = [3,3,3,3,4,5,7,7,8,11,11,13,14,14,14,20,20] # 3-29 3分?
#cards = [3,7,7,8,8,9,9,10,11,11,13,13,13,14,14,14,20] # 3-30 3分？
#以上《我是地主我怕谁》 其他案例

#随机案例
#cards = [3, 3, 3, 4, 4, 6, 8, 9, 10, 11, 11, 12, 12, 13, 13, 13, 20] # 2分？
#cards = [3, 3, 3, 4, 4, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 20] # 3分！

cards.sort()
init = initCardsFor3PlayersBit(cards)
#cards = init[0]
cards = init[0]
peasantCards = init[1]
peasantCards.sort()

# print("Init:", cards)
cards = sortCards(cards)
print("Sorted:", cards)
sortedCards = cards

from DouDiZhu3 import *
gameInfo = DouDiZhu3(sortedCards, init[1], init[2])

#cards = mergeCards(cards)
#print("Merged:", cards)

natureCards = getNatureCardCombination(cards)
print("Nature:", natureCards)
#nature = cards[:]  # 保存自然牌组

cardsList = []
cardsList.append(cards)
cardCombinations = combinateCardsList(cardsList)
LogUtil.logOutDisabled()
for key, valuedCombination in enumerate(cardCombinations):
    LogUtil.Log("Combinated:", key, valuedCombination)

cardCombinations = adjustCardCombinations(cardCombinations)
for key, valuedCombination in enumerate(cardCombinations):
    LogUtil.Log("Adjusted:", key, valuedCombination)

cardCombinations = plusCardCombinations(cardCombinations)
for key, valuedCombination in enumerate(cardCombinations):
     LogUtil.Log("Plus:", key, valuedCombination)
#sys.exit()

# 选出Top N， 额外有大牌，应该加分
valuedCombinations = valuationCardCombinationsForBit(cardCombinations, gameInfo, lead=True)
topValuedCardCombination = valuedCombinations[0]
print("Top Rate:", topValuedCardCombination[1])
#print(sortedCards)

score = 0
ownedCards = sortedCards[:]
bFound = True
while(bFound == True):
    bFound = False
    for key in range(0, len(ownedCards) - 4):
        if ownedCards[key] == ownedCards[key + 3]:  # 已经排好序，所以只需要比较一头一尾即可
            bFound = True
            break
    if bFound == True:
        score += 5
        card = ownedCards[key]
        if card == CardValue.Card_2:
            score += 3
        elif card == CardValue.Card_A:
            score += 1
        elif card == CardValue.Card_K:
            score += 1

        for index in range(0,4):
            ownedCards.remove(card)

for card in ownedCards:
    if card == CardValue.Card_R:
        score += 3.5
    elif card == CardValue.Card_B:
        score += 2.5
    elif card == CardValue.Card_2:
        score += 2
    elif card == CardValue.Card_A:
        score += 1
    elif card == CardValue.Card_K:
        score += 0.5

print("Score:", score)
for key, valuedCombination in enumerate(valuedCombinations):
    cardCombination = valuedCombination[3:]
    print("Top:", key + 1, valuedCombination[0], valuedCombination[1], "Correct&Carry:", valuedCombination[2], cardCombination)
#sy# s.exit()

'''
cardOrders = orderCardCombinations(cardCombinations, gameInfo)
for key, kind in enumerate(cardOrders):
    print("Top:", key + 1, kind[2], kind[1], "First:", kind[0], "->", kind[3:])
'''
