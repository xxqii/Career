#!/usr/bin/python
# -*-coding:utf-8-*-

import math
import random


def best_move_time(state, iteration_times):
    """returns the best move and number of mcts iterations computed"""
    root = mcts_node(None, state)
    iterations = 0

    while iterations < iteration_times:
        child = root.select()
        won = child.simulate()
        child.propogate(won)
        iterations += 1

    return root.play(), iterations


# exploration_parameter是可变参数，初始化为根号2
def uct(parent_wins, parent_playouts, child_wins, child_playouts, exploration_parameter=math.sqrt(2)):
    return child_wins / child_playouts + exploration_parameter * math.sqrt(math.log(parent_playouts) / child_playouts)


class mcts_node(object):
    def __init__(self, parent, state):
        self.parent = parent
        # 这里的state就是局面的意思
        self.state = state
        self.wins = 0
        self.playouts = 0
        self.children = {}

    def select(self, selection_function=uct):
        # 如果有一方获胜
        if self.state.is_terminal():
            return self
        else:
            cards = self.state.canPlayCard()
            if len(self.children) < len(cards):
                length = list(range(len(cards)))
                random.shuffle(length)
                for l in length:
                    if l not in self.children:
                        self.children[l] = mcts_node(self, self.state.get_successor(cards[l]))
                        return self.children[l]
            # 如果已经建立了可以应对的所有结点，就选择一个UCT最大的
            else:
                return max(self.children.values(),
                           key=lambda child: selection_function(self.wins, self.playouts, child.wins,
                                                                child.playouts)).select(selection_function)

    def simulate(self):
        return self.state.playouts()

    # 递归更新playouts和wins的值
    def propogate(self, won):
        # playouts代表模拟数值
        self.playouts += 1
        # 如果获胜了而max等于false 或者 没有获胜而max为true
        if won:
            self.wins += 1
        if self.parent is not None:
            self.parent.propogate(won)

    def play(self):
        for move in self.children:
            print('%d:    %5.2f%%    %4d/%d' % (
                move + 1, 100 * self.children[move].wins / self.children[move].playouts, self.children[move].wins,
                self.children[move].playouts))
        print("        %4d/%d total" % (self.wins, self.playouts))
        result = {}
        for move in self.children:
            result[move] = float(self.children[move].wins) / float(self.children[move].playouts)
        return max(result, key=lambda x: result[x])