# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-11-22

# 二人斗地主决策AI
from Util.CardUtil import *
from Util.LogUtil import *
from Value import *
from Strategy import *

class AI2Players(object):
    def __init__(self):
        pass

    # 首牌决策
    # 输入gameInfo,包含现在的所有牌局信息，参见DouDiZhu2的类定义
    # 输入 initCards，地主初始20张手牌，例如[6, 6, 6, 7, 7, 7, 8, 8, 8, 10, 10, 10, 11, 11, 12, 12, 13, 14, 16, 17]
    # 输出 可能的出牌 牌型List，例如[[5]] 或者 [[3,3],[5,5,5,4]]
    def FirstCard(self, gameInfo):
        #sortedCards = sorted(initCards)
        sortedCards = gameInfo.getRestCards()

        cardsList = []
        cardsList.append(sortedCards)
        cardCombinations = combinateCardsList(cardsList)
        # for key, combination in enumerate(cardCombinations):
        #    print("Combinated:", key, combination)

        cardCombinations = adjustCardCombinations(cardCombinations, gameInfo)
        # for key, combination in enumerate(cardCombinations):
        #    print("Adjusted:", key, combination)

        cardCombinations = plusCardCombinations(cardCombinations)
        # for key, combination in enumerate(cardCombinations):
        #     print("Plus:", key, combination)
        # sys.exit()

        # 选出Top N，
        cardCombinations = valuationCardCombinations(cardCombinations, gameInfo)
        for cardCombination in cardCombinations:
            if len(cardCombination[2:]) == 1: # 只有首牌需要判断一手春天 TODO 春天概率判断？
                cardCombination[1] *= 2.0

        # for key, combination in enumerate(cardCombinations):
        #    print("Top:", key+1, combination)
        # sys.exit()

        # 以及对应的出牌序列
        #cardOrders = sortCardCombinations(sortedCards, cardCombinations, True, CardRole.LANDLORD, [], [])
        cardOrders = sortCardCombinations(cardCombinations, gameInfo, quick=False)

        # 降序，主关键词为首位Value值降序，次级关键词为牌组长度升序，三级关键词为出牌长度/出牌的keyCardValue升序
        cardOrders.sort(key=lambda comb: comb[2] * 100 + 40 - len(comb[4:]) * 2 + (len(comb[0]) / comb[0][0] if len(comb[0]) > 0 else 0),
                     reverse=True)

        LogUtil.Log("===========FirstCard===========")
        for key, kind in enumerate(cardOrders):
            #print("Top:", key + 1, cardCombinations[key][1],cardCombinations[key][0], "First:", kind, "->", cardCombinations[key][2:])
            #print("Top:", key + 1, kind[2], kind[1], "First:", kind[0], "->",kind[3:])
            LogUtil.Log("Top:", key + 1, kind[2], "First:", kind[0], "->", kind[3:])

        ret = []
        ret.append(cardOrders[0][0]) # 只返回第一个
        return ret

    # 引牌决策
    # 以下几个包含在gameInfo中
    # 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
    # 输入 restCards, 玩家当前的手牌，例如[8, 8, 8, 10, 10, 10, 11, 11, 12, 12, 13, 14, 16, 17]
    # 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
    # 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
    # 输出 可能的出牌 牌型List，例如[[5]] 或者 [[3,3],[5,5,5,4]]
    def LeadCard(self, gameInfo):
        # 合并生成所有明牌
        openCards = gameInfo.getOpenedCards()
        restCards = gameInfo.getRestCards()

        cardsList = []
        cardsList.append(restCards)
        cardCombinations = combinateCardsList(cardsList)
        # for key, combination in enumerate(cardCombinations):
        #    print("Combinated:", key, combination)

        cardCombinations = adjustCardCombinations(cardCombinations)
        # for key, combination in enumerate(cardCombinations):
        #    print("Adjusted:", key, combination)

        cardCombinations = plusCardCombinations(cardCombinations)
        # for key, combination in enumerate(cardCombinations):
        #     print("Plus:", key, combination)
        # sys.exit()

        # 选出Top N，
        #cardCombinations = valuationCardCombinations(cardCombinations, gameInfo, lead=True) #容易犯二 先出2
        lead = False
        if gameInfo.getOpponentRestCardsLength() <= 1: #对手牌小于2张，先出大牌，留小牌在最后
            lead = True
        cardCombinations = valuationCardCombinations(cardCombinations, gameInfo, lead)
        # for key, combination in enumerate(cardCombinations):
        #    print("Top:", key+1, combination)
        # sys.exit()

        # 以及对应的出牌序列
        cardOrders = sortCardCombinations(cardCombinations, gameInfo, quick=False)
        # 降序，主关键词为首位Value值降序，次级关键词为牌组长度升序，三级关键词为出牌长度/出牌的keyCardValue升序
        cardOrders.sort(key=lambda comb: comb[2] * 100 + 40 - len(comb[4:]) * 2 + (len(comb[0]) / comb[0][0] if len(comb[0]) > 0 else 0),
                     reverse=True)

        for key, kind in enumerate(cardOrders):
            #print("Top:", key + 1, cardCombinations[key][1], "Lead:", kind, "->", cardCombinations[key][2:])
            #print("Top:", key + 1, kind[2], kind[1], "Lead:", kind[0], "->", kind[3:])
            LogUtil.Log("Top:", key + 1, kind[2], "Lead:", kind[0], "->", kind[3:])

        ret = []
        ret.append(cardOrders[0][0])  # 只返回第一个
        return ret

    # AI出牌决策
    def AIPlayCards(self, role, gameInfo):
        # 上一次出牌为空，首牌/引牌
        if gameInfo.getLastCardArray() == []:
            if len(gameInfo.getRestCards()) == 20:  # 首牌情况
                ret = self.FirstCard(gameInfo)
            else:  # 引牌情况
                if role == CardRole.LANDLORD:
                    #ret = LeadCard(role, self.landlordCards, self.landlordCardSequence, self.peasantCardSequence)
                    ret = self.LeadCard(gameInfo)
                elif role == CardRole.PEASANT:
                    #ret = LeadCard(role, self.peasantCards, self.landlordCardSequence, self.peasantCardSequence)
                    ret = self.LeadCard(gameInfo)
                else:
                    print("Exception Role Invalid:",role)
        else:
            # 管牌情况
            if role == CardRole.LANDLORD:
                #ret = CoverCard(role, self.lastCardKind, self.landlordCards, self.landlordCardSequence, self.peasantCardSequence)
                ret = self.CoverCard(gameInfo)
            elif role == CardRole.PEASANT:
                #ret = CoverCard(role, self.lastCardKind, self.peasantCards, self.landlordCardSequence, self.peasantCardSequence)
                ret = self.CoverCard(gameInfo)
            else:
                print("Exception Role Invalid:", role)
        return ret[0]

    # 管牌决策
    # 以下全部包含在gameInfo中
    # 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
    # 输入 lastCardKind, 上一轮的牌型，例如[3,3]
    # 输入 restCards, 玩家当前的手牌，例如[8, 8, 8, 10, 10, 10, 11, 11, 12, 12, 13, 14, 16, 17]
    # 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
    # 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
    # 输出 可能的出牌 牌型List，例如 Duck让牌[[]] 或者 [[3,3],
    #def CoverCard(role, lastCardKind, restCards, landlordCardSequence, peasantCardSequence):
    def CoverCard(self, gameInfo):
        retList = []
        # 合并生成所有明牌
        lastCardKind = gameInfo.getLastCardArray()
        restCards = gameInfo.getRestCards()
        openCards = gameInfo.getOpenedCards()

        # 列举出管牌的情况并计算最大牌力
        cardKindList = getCoverableCardKind(lastCardKind, restCards)
        for cardKind in cardKindList:
            kind = getCardKind(cardKind)
            currentCardList = restCards[:]
            for card in cardKind:
                currentCardList.remove(card)
            power = getCardPowerFromCards(cardKind, currentCardList, gameInfo)
            value = power[0]
            retList.append([value] + [cardKind] + power[1:])

        # 计算让牌情况下的牌力
        power = getCardPowerFromCards([], restCards, gameInfo)
        # 让牌需要对价值做下调,所以乘以系数；让牌降权系数和对手剩余牌数量有关
        opponentRestCardslength = gameInfo.getOpponentRestCardsLength()
        power[0] = power[0] * 0.81  # 0.9 * 0.9
        if opponentRestCardslength <= 5:
            power[0] = power[0] * (opponentRestCardslength / 5 - 0.20)
        retList.append([power[0]] + [[]] + power[1:])

        # 降序，主关键词为首位Value值降序，次级关键词为牌组长度升序，三级关键词为出牌的keyCardValue升序
        #retList.sort(key=lambda comb: comb[0] * 100 + (comb[1][0] if (len(comb[1]) > 0) else 0), reverse=True)
        #retList.sort(key=lambda comb: comb[0] * 100 + 400 - len(comb[2:]) * 20 + comb[1][0] if (len(comb[1]) > 0) else 0 , reverse=True)
        retList.sort(key=lambda comb: comb[0] * 10000 + 400 - len(comb[2:]) * 20 + (len(comb[1]) / comb[1][0] if len(comb[1]) > 0 else 0),
                     reverse=True)
        #retList.sort(key=lambda comb: comb[0] * 10000 + 400 - len(comb[2:]) * 20 + (comb[1][0] if len(comb[1]) > 0 else 0),
        #             reverse=True)

        for key, value in enumerate(retList[0:10]):
            LogUtil.Log("Top:", key + 1, retList[key][0], "Cover:", retList[key][1], "->", retList[key][2:])
            #print("Top:", key + 1, retList[key][0], "Cover:", retList[key][1], "->", retList[key][2:])
        return [retList[0][1]]

# 为管牌从牌面计算牌力，即最大价值
# 输入 coverCardKind是出牌，如果是[]，表示不出
# 输入 restCards是除出牌外剩余的牌面

# 以下几个全部包含在gameInfo中
# 输入 openCards是已经公开的牌面，已经排序
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
# 返回为列表，列表元素0为价值,[1:]为牌组，示例：
# <class 'list'>: [99.00000000000001, [7, 7, 7, 8, 8, 8, 10, 13], [9, 10, 11, 12, 13, 14], [20], [40], [10, 10]]
#管牌不一定是一轮的结束，需要管牌+同牌型大牌作为一轮
#连对顺子飞机四带炸弹火箭管牌即结束这一轮，单双三带则可回收
#单张：只有大牌能带小牌，中牌自己顾自己
#对子：中大牌可带小牌，中牌自己顾自己
#三带：中大牌可带小牌，大牌带中牌
#管牌但是需要同牌型大牌来控牌，则降权系数例如 * 0.9
def getCardPowerFromCards(coverCardKind, restCards, gameInfo):
    opponentRestCardslength = gameInfo.getOpponentRestCardsLength() # 对手目前剩余的手牌数量

    if coverCardKind != []:
        coverCardKind = generateCardKindFromCards(coverCardKind)
    restCards = sorted(restCards)

    cardsList = []
    cardsList.append(restCards)
    cardCombinations = combinateCardsList(cardsList)
    cardCombinations = adjustCardCombinations(cardCombinations, gameInfo)
    cardCombinations = plusCardCombinations(cardCombinations)

    #for key, combination in enumerate(cardCombinations):
    #    combination.append(coverCardKind)

    if coverCardKind != []:
        retList = valuationCoverCardCombinations(coverCardKind, cardCombinations, gameInfo)
        # for key, ret in enumerate(retList):
        #    print("Top:", key+1, ret)
        return retList[0] #return top value and card combination
    else: # 让牌，则估算牌力的时候需要去掉一个最大的控牌牌型(单双炸弹三带)，没有控牌牌型则牌力为0？
        # 无法估算让牌的后果，所以按照最坏的结果即来估算
        valuedList = valuationCardCombinations(cardCombinations, gameInfo, False)
        cardCombinations = valuedList[0:ConstCard.TOP_BY_COUNT]
        duckList = [] #同一牌组，不同的控牌方法
        criticalRate = 0.90 #临界值设定为0.90
        retList = []
        for element in cardCombinations:
            cardCombination = element[3:]
            duckList.clear()
            for key,cardKind in enumerate(cardCombination):
                kind = getCardKind(cardKind)
                if kind == CardKind.BOMB:
                    coverCardKind = cardKind
                    tempCardCombination = cardCombination[:]
                    tempCardCombination.remove(coverCardKind)
                    valuedList = valuationCoverCardCombinations(coverCardKind, [tempCardCombination], gameInfo)
                    duckList.append(valuedList[0])

                elif kind == CardKind.ROCKET:
                    coverCardKind = cardKind
                    tempCardCombination = cardCombination[:]
                    tempCardCombination.remove(coverCardKind)
                    valuedList = valuationCoverCardCombinations(coverCardKind, [tempCardCombination], gameInfo)
                    duckList.append(valuedList[0])

                elif kind == CardKind.SINGLE or kind == CardKind.PAIR :
                    #or kind == CardKind.THREE or kind == CardKind.THREE_PLUS1 or kind == CardKind.THREE_PLUS2:
                    rate = getCardWeight(gameInfo, cardKind, kind, quick=False)
                    if rate >= criticalRate:
                        coverCardKind = cardKind
                        tempCardCombination = cardCombination[:]
                        tempCardCombination.remove(coverCardKind)
                        #valuedList = valuationCardCombinations([tempCardCombination], gameInfo, lead=True)
                        # valuedList[0][0] = maxRate * valuedList[0][1] #不一定能抢回控牌权，所以需要乘以系数0.9的平方，包含在降权系数0.58了
                        valuedList = valuationCoverCardCombinations(coverCardKind, [tempCardCombination], gameInfo)
                        duckList.append(valuedList[0])
            duckList.sort(key = lambda comb: comb[0], reverse=False) #按照价值升序排列，返回最小的情况。组合里面最不利的夺回控牌权情况
            if len(duckList) > 0:
                retList.append(duckList[0])
        retList.sort(key=lambda comb: comb[0], reverse=True)  # 按照价值降序排列，返回最大的情况。最强的组合
        if len(retList) > 0:
            return retList[0]
        else: #不管，但是也没有大牌能争夺牌权
            return valuedList[0][1:]

# 通过输入的乱序牌型，生成能识别的有效型
# 例如输入 3 4 4 4 5 5 5 6，输出 4 4 4 5 5 5 3 6
def generateCardKindFromCards(cards):
    cards = sorted(cards)
    # 分组合并
    length = len(cards)
    cardsDict = {}
    for index in range(1,5):
        cardsDict[index] = []

    # 分组，按照单张对子三张四张分组
    key = 0
    while key < length:
        count = 1
        for index in range(key+1,length):
            if cards[key] != cards[index]:
                break
            else:
                count += 1
        for i in range(0, count):
            cardsDict[count].append(cards[key])
        key = key + count

    # 合并, 依次是4张3张2张1张
    ret = []
    for index in range(4,0,-1):
        ret += cardsDict[index]

    # 校验一下
    #if CardKind.INVALID == getCardKind(ret):
    #    print("INVALID", cards)
    return ret