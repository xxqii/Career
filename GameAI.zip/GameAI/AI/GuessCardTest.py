# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-11-19

import random
import sys
import os

from Util.CardUtil import *
from Value2 import *
from Strategy import *

# 判断相似度，提供给对外调用
# 输入：
# firstCards：首牌牌值列表，不允许为空； 例如[4, 4, 4, 12]
# openCards：含首牌的明牌列表； 例如[3, 4, 4, 4, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 12，13, 30, 40]
# hiddenCardsList：备选的暗牌列表，为二维列表,例如[[14, 14],[13, 14],[12, 13]
# 返回：
# additionCardsList中的最相似的暗牌，一维列表，例如返回[14,14]
def getTopSimularity(firstCards, openCards, hiddenCardsList):
    #TODO 输入数据有效性检查
    restCards = openCards[:] # restCards 是 openCards 和 firstCards的差集
    if len(firstCards) > 0:
        for card in firstCards:
            if card not in restCards:
                print("Exception, Invalid Input:", firstCards, openCards, hiddenCardsList)
                return hiddenCardsList[0] #猜第一个
            restCards.remove(card)
    else:
        print("Exception, Invalid Input:", firstCards, openCards, hiddenCardsList)
        return hiddenCardsList[0]  # 猜第一个

    retList = []
    for hiddenCards in hiddenCardsList:
        otherCards = restCards + hiddenCards
        maxValue = getCardPowerFromCards(firstCards, otherCards) # 指定首牌的牌力
        topValue = getCardPowerFromCards([],otherCards + firstCards) #  不指定首牌的牌力
        percent = (topValue - maxValue) * 100 / topValue #差值，差值越小越接近

        ret = []
        ret.append(percent)
        ret.append(maxValue)
        ret.append(topValue)
        ret.append(hiddenCards)
        ret.append(sorted(otherCards + firstCards))
        retList.append(ret)

    retList.sort(key=lambda comb: comb[0], reverse=False)  # 升序，只对首位Value值排序；
    #return retList #返回详细信息
    return retList[0][3]

# 通过输入的乱序牌型，生成能识别的有效型
# 例如输入 3 4 4 4 5 5 5 6，输出 4 4 4 5 5 5 3 6
def generateCardKindFromCards(cards):
    cards = sorted(cards)
    # 分组合并
    length = len(cards)
    cardsDict = {}
    for index in range(1,5):
        cardsDict[index] = []

    # 分组，按照单张对子三张四张分组
    key = 0
    while key < length:
        count = 1
        for index in range(key+1,length):
            if cards[key] != cards[index]:
                break
            else:
                count += 1
        for i in range(0, count):
            cardsDict[count].append(cards[key])
        key = key + count

    # 合并, 依次是4张3张2张1张
    ret = []
    for index in range(4,0,-1):
        ret += cardsDict[index]

    # 校验一下
    #if CardKind.INVALID == getCardKind(ret):
    #    print("INVALID", cards)
    return ret

# 从牌面计算牌力，即最大价值
# firstCards是首牌
# otherCards是除掉首牌剩下的牌面
def getCardPowerFromCards(firstCards, otherCards):
    #TODO 可能需要对牌型做处理
    sortedCards = []
    sortedCards += firstCards
    sortedCards += otherCards

    if len(firstCards) > 0:
        firstCards = generateCardKindFromCards(firstCards)
        firstCards = [firstCards]
    otherCards = sorted(otherCards)

    cardsList = []
    cardsList.append(otherCards)
    cardCombinations = combinateCardsList(cardsList)
    cardCombinations = adjustCardCombinations(cardCombinations)
    cardCombinations = plusCardCombinations(cardCombinations)

    for key, combination in enumerate(cardCombinations):
        cardCombinations[key] = firstCards + combination

    retList = valuationCardCombinations(sortedCards, cardCombinations)
    #for key, ret in enumerate(retList):
    #    print("Top:", key+1, ret)
    return retList[0][1] #return top value

#cards = initCards()
#cards = [3, 4, 4, 4, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 12, 13, 14, 14, 30, 40]
#firstCards = [3, 4, 5, 6, 7]
#otherCards = [4, 4, 4, 8, 8, 9, 9, 10, 10, 12, 13, 14, 14, 30, 40]

#cards = [4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11]
#firstCards = cards[:]
#otherCards = []

#ret = getCardPowerFromCards(firstCards, otherCards)
#cards = initCards()
#ret = generateCardKindFromCards(cards)

#测试用例
'''
firstCards = [4, 4, 4, 12]
openCards = [3, 4, 4, 4, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 12, 13, 30, 40]
hiddenCardsList = [[12,12],[13,13],[14,14]]
ret = getTopSimularity(firstCards, openCards, hiddenCardsList)
print(ret)
'''
