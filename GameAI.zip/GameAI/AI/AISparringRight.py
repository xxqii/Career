# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2017-1-26

# 三人斗地主决策AI，用来做陪练的
from Util.CardUtil import *

from Strategy import *
from Value import *

from AI2Players import *
from AI3Players import *

class AISparringRight(AI3Players):
    def __init__(self):
        super(AISparringRight, self).__init__()
        pass

    def FirstCard(self, gameInfo):
        return super(AI3Players, self).FirstCard(gameInfo)

    # 引牌决策，三人斗地主，分成保守和稳健两种打法，结合猜牌和出牌序列，例如对手如果某牌型小牌没有管则继续出该牌型小牌
    # 另外，如果队友可走牌，则配合送控牌权。例如，如果队友只有一两张牌，则打小单张/小对子
    def LeadCard(self, gameInfo):
        #return super(AISparringRight, self).LeadCard(gameInfo) #AI3Players
        return super(AI3Players, self).LeadCard(gameInfo)

    def CoverCard(self, gameInfo):
        #return super(AISparringRight, self).CoverCard(gameInfo) #AI3Players
        return super(AI3Players, self).CoverCard(gameInfo)