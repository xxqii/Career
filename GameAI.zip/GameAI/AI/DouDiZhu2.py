# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-11-23

# 二人斗地主的牌局信息
# 目的：以后三人斗地主的时候，继承这个类即可

from Util.CardUtil import *
from Util.LogUtil import *

class DouDiZhu2(object):
    def __init__(self, landlordCards, peasantCards):
        self.initLandlordCards = landlordCards[:] # 初始的地主手牌
        self.initpeasantCards = peasantCards[:] # 初始的农民手牌

        self.landlordCards = landlordCards[:] #当前的地主手牌，总是排好序的
        self.landlordCards.sort()
        self.peasantCards = peasantCards[:] # 当前的农民手牌，总是排好序的
        self.peasantCards.sort()

        self.lastCardArray = [] # 当前轮上一家出的牌型，对于首牌，为空；

        self.landlordCardSequence = []  # 地主出牌序列
        self.peasantCardSequence = []  # 农民出牌序列
        self.playedCardsSequence = [] # [角色，出牌]二元组组成的列表

        self.topCardKindForPeasant = {} #农民方的大牌 规则：地主出的，农民管不起的牌，用炸弹火箭管不算管了
        self.topCardKindForLandlord = {} #地主方的大牌 规则：农民出的，地主管不起的牌，用炸弹火箭管不算管了

        self.currentRole = CardRole.LANDLORD # 二人斗地主当前轮到出牌的角色

        self.landlordOpenedCards = self.landlordCards[:] # 地主方的公开的牌，总是排好序的
        self.peasantOpenedCards = self.peasantCards[:] # 农民方的公开的牌，总是排好序的

        self.playedTotalTurns = 0  # 当前轮数，出到争夺控牌权结束称之一轮
        self.roleGotLeads = {CardRole.LANDLORD: 0, CardRole.PEASANT: 0}  # 每个角色引牌次数，首牌也计入引牌

    @staticmethod
    def getPlayers():
        return 2

    def getRestCardsByRole(self, role):
        if role == CardRole.LANDLORD:
            return self.landlordCards
        elif role == CardRole.PEASANT:
            return self.peasantCards
        else:
            print("Exception Role Invalid:", role)
            return []

    def getOtherRestCards(self):
        if self.currentRole == CardRole.LANDLORD:
            return self.peasantCards
        elif self.currentRole == CardRole.PEASANT:
            return self.landlordCards
        else:
            raise BaseException("Exception Invalid CardRole:", currentRole)
            return []

    def getRestCards(self):
        if self.currentRole == CardRole.LANDLORD:
            return self.landlordCards
        elif self.currentRole == CardRole.PEASANT:
            return self.peasantCards
        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return []

    def getOpenedCards(self):
        if self.currentRole == CardRole.LANDLORD:
            return self.landlordOpenedCards
        elif self.currentRole == CardRole.PEASANT:
            return self.peasantOpenedCards
        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return []

    def getRestCardsLengthByRole(self, role):
        if role == CardRole.LANDLORD:
            return len(self.landlordCards)
        else:
            return len(self.peasantCards)

    def getOpponentRestCardsLength(self):
        if self.currentRole == CardRole.LANDLORD:
            return len(self.peasantCards)
        elif self.currentRole == CardRole.PEASANT:
            return len(self.landlordCards)
        else:
            raise BaseException("Exception Invalid CardRole:", self.currentRole)
            return 0

    # 获得对手某一牌型 最近没法管的牌(用炸弹火箭管除外)， 那么大于该牌的牌型，对手很大可能没法管
    def getOpponentLastDuckedCardKind(self, kind):
        '''
        opponentRole = None
        if self.currentRole == CardRole.LANDLORD:
            opponentRole = CardRole.PEASANT
        else:
            opponentRole = CardRole.LANDLORD
        return self._getLastDuckedCardKindByRole(opponentRole, kind)
        '''
        if self.currentRole == CardRole.LANDLORD:
           if kind in self.topCardKindForPeasant:
               return self.topCardKindForPeasant[kind]
           else:
               return []
        else:
            if kind in self.topCardKindForLandlord:
                return self.topCardKindForLandlord[kind]
            else:
                return []

    # 获得某角色某一牌型CardArray 最近没法管的牌(用炸弹火箭管除外)， 那么大于该牌的牌型，对手很大可能没法管
    def _getLastDuckedCardArrayByRole(self, role, kind):
        #逆序查找
        index = -1
        end = 0 - len(self.playedCardsSequence) # self.playedCardsSequence[1]

        topCardKindKeyCardValue = CardValue.Card_Min
        while(index > end):
            element = self.playedCardsSequence[index]
            playedRole = element[0]
            playedCards = element[1]

            prevElement = self.playedCardsSequence[index-1]
            keyCardValue = CardValue.Card_Min
            if prevElement[1] != []:
                keyCardValue = prevElement[1][0]
            prevElementKind = getCardKind(prevElement[1])

            passed = False
            if playedRole == role and prevElementKind == kind:
                if playedCards == []:
                    passed = True
                else:
                    elementKind = getCardKind(playedCards)
                    if elementKind == CardKind.BOMB or elementKind == CardKind.ROCKET:
                        passed = True

                if passed == False:#找出管了的最大牌
                    if keyCardValue > topCardKindKeyCardValue:
                        topCardKindKeyCardValue = keyCardValue
                else:
                    if keyCardValue > topCardKindKeyCardValue:
                        #LogUtil.Log(role, kind, prevElement[1])
                        return prevElement[1]
            index = index - 1
        return []

    def getLastCardArray(self):
        return self.lastCardArray

    def getCurrentRole(self):
        return self.currentRole

    def getRoleLeadCount(self, role):
        return self.roleGotLeads[role]

    def getPlayedTotalTurns(self):
        return self.playedTotalTurns

    # 出牌
    def playedCards(self, role, cardKind):
        # 上一次出牌为空，首牌/引牌
        if self.getLastCardArray() == []:
            self.playedTotalTurns += 1
            self.roleGotLeads[self.currentRole] += 1
            #print(self.playedTotalTurns)
            #print(self.roleGotLeads)

        kind = getCardKind(self.lastCardArray)
        # TODO 需要细化，先不管了 2017-3-24
        if role == CardRole.LANDLORD:
            if cardKind == []:  # 管不起
                self.topCardKindForLandlord[kind] = self.lastCardArray[:]
            else:
                self.topCardKindForLandlord[kind] = []
        else:
            if cardKind == []:  # 管不起
                self.topCardKindForPeasant[kind] = self.lastCardArray[:]
            else:
                self.topCardKindForPeasant[kind] = []

        if isinstance(cardKind, list) == False:
            print("CardKind == ", cardKind)
        self.lastCardArray = cardKind[:]
        if role == CardRole.LANDLORD:
            self.landlordCardSequence.append(self.lastCardArray)
            self.playedCardsSequence.append([CardRole.LANDLORD, self.lastCardArray])
            for card in self.lastCardArray:
                self.landlordCards.remove(card)
            self.landlordCards.sort()
            self.currentRole = CardRole.PEASANT
            self.peasantOpenedCards += cardKind
            self.peasantOpenedCards.sort()

        elif role == CardRole.PEASANT:
            self.peasantCardSequence.append(self.lastCardArray)
            self.playedCardsSequence.append([CardRole.PEASANT, self.lastCardArray])
            for card in self.lastCardArray:
                self.peasantCards.remove(card)
            self.peasantCards.sort()
            self.currentRole = CardRole.LANDLORD
            self.landlordOpenedCards += cardKind
            self.landlordOpenedCards.sort()

        else:
            print("Exception Role Invalid:", role)
            return []

    def isOver(self):
        if self.landlordCards == []:
            return CardRole.LANDLORD
        elif self.peasantCards == []:
            return CardRole.PEASANT
        else:
            return CardRole.INVALID

    '''
    def AIPlayCards(self, role, cardDecision):
        # 上一次出牌为空，首牌/引牌
        if self.getLastCardKind() == []:
            if len(self.getRestCards()) == 20:  # 首牌情况
                ret = cardDecision.FirstCard(self)
            else:  # 引牌情况
                if role == CardRole.LANDLORD:
                    #ret = LeadCard(role, self.landlordCards, self.landlordCardSequence, self.peasantCardSequence)
                    ret = cardDecision.LeadCard(self)
                elif role == CardRole.PEASANT:
                    #ret = LeadCard(role, self.peasantCards, self.landlordCardSequence, self.peasantCardSequence)
                    ret = cardDecision.LeadCard(self)
                else:
                    print("Exception Role Invalid:",role)
        else:
            # 管牌情况
            if role == CardRole.LANDLORD:
                #ret = CoverCard(role, self.lastCardKind, self.landlordCards, self.landlordCardSequence, self.peasantCardSequence)
                ret = cardDecision.CoverCard(self)
            elif role == CardRole.PEASANT:
                #ret = CoverCard(role, self.lastCardKind, self.peasantCards, self.landlordCardSequence, self.peasantCardSequence)
                ret = cardDecision.CoverCard(self)
            else:
                print("Exception Role Invalid:", role)
        return ret[0]
    '''