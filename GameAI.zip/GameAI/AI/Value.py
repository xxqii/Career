# -*- coding: utf-8 -*-
#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-09-29

# 二人斗地主价值体系
import random
from Util.CardUtil import *
from Util.LogUtil import *

# TODO 价值框架优化思路
# 炸弹/反炸/春天
# 最后一手牌尤其是为单双报时，考虑被截杀的可能
# 大牌博弈
# 结合出牌顺序考虑
# 大牌不动，留着动态调整？
# 3张地主牌需要标识？
# 价值和排序不应分离

def getWeightForSingle(gameInfo, card, quick = True):
    if gameInfo.getPlayers() == 2:
        return getWeightForSingle_2Players(gameInfo, card, quick)
    else:
        return getWeightForSingle_3Players(gameInfo, card, quick)

def getWeightForSingle_2Players(gameInfo, card, quick = True):
    ret = 1.0
    sortedCards = gameInfo.getOpenedCards()
    cardClass = getCardClass(card[0])
    if cardClass == CardClass.SMALL:
        ret = 0.05 + (card[0] - CardValue.Card_3) * 0.05 # 0.05-0.40
    elif cardClass == CardClass.MIDDLE:
        ret = 0.45 + (card[0] - CardValue.Card_10) * 0.05 # 0.45-0.60
    elif card[0] == CardValue.Card_2:
        # 两个王
        if sortedCards[-1] == CardValue.Card_R and sortedCards[-2] == CardValue.Card_B:
            ret = 1.0
        elif sortedCards[-1] >= CardValue.Card_B: # 1个王
            ret = 0.95
        else: # 没有王
            ret = 0.90
    elif card[0] == CardValue.Card_B: #小王
        if sortedCards[-1] == CardValue.Card_R:
            ret = 1.01 #王只有单张，不会被2拦住，加权
        else:
            ret = 0.95
    elif card[0] == CardValue.Card_R: #大王
        ret = 1.02 #王只有单张，不会被2拦住，加权
    return ret

def getWeightForSingle_3Players(gameInfo, card, quick = True):
    ret = 0.0
    otherRestCards = gameInfo.getOtherRestCards()
    if len(otherRestCards) <= 6:
        ret = 1.0
    cardClass = getCardClass(card[0])
    if card[0] == CardValue.Card_R: #大王
        ret = 1.02 #王只有单张，不会被2拦住，加权
    elif card[0] == CardValue.Card_B: #小王
        if otherRestCards[-1] == CardValue.Card_R:
            ret = 0.98
        else:
            ret = 1.01 #王只有单张，不会被2拦住，加权
    elif card[0] == CardValue.Card_2:
        # 剩余两个王
        if otherRestCards[-1] == CardValue.Card_R and otherRestCards[-2] == CardValue.Card_B:
            ret = 0.90
        elif otherRestCards[-1] >= CardValue.Card_B: # 1个王
            ret = 0.95
        elif otherRestCards[-1] < CardValue.Card_2:
            ret = 1.01 #比所有对手的牌都大
        else: # 没有王
            ret = 1.00
    elif card[0] > otherRestCards[-1]:
        ret = 1.01
    elif card[0] == otherRestCards[-1]:
        ret = 1.00
    elif card[0] > otherRestCards[-2]: #只要游戏还没完，那么对于任何一个玩家起码有1张牌未公开
        ret = 0.95
    elif card[0] == otherRestCards[-2]:
        ret = 0.90
    elif cardClass == CardClass.SMALL:
        ret = 0.05 + (card[0] - CardValue.Card_3) * 0.05 # 0.05-0.40
    elif cardClass == CardClass.MIDDLE:
        ret = 0.50 + (card[0] - CardValue.Card_10) * 0.05 # 0.50-0.70
    return ret

# 输入 gameInfo,包含现在的所有牌局信息，参见DouDiZhu2的类定义
def getWeightForPair(gameInfo, card, quick = True):
    ''' 对子随机 1 算出来牌权很小，2 计算量增大，所以废弃
    # 随机N次，看看有没有对能管上
    if quick == False:
        rate = 0
        cardKeyValue = card[0]
        for i in range(0, ConstCard.RANDCOM_COUNT, 1):
            opponentCards = getRandomOpponentCards(gameInfo)
            bFound = False
            for cards in opponentCards:
                for index in range(0, len(cards) - 1):
                    if cards[index] > cardKeyValue and cards[index + 1] == cards[index]:
                        rate += 1
                        bFound = True
                        break
                if bFound == True:
                    break
        return (ConstCard.RANDCOM_COUNT - rate) / ConstCard.RANDCOM_COUNT
    '''
    '''
    ret = 1.0
    keyCardValue = card[0]
    cardClass = getCardClass(keyCardValue)
    sortedCards = gameInfo.getOpenedCards()
    if cardClass == CardClass.SMALL:
        ret = 0.1 + (keyCardValue - CardValue.Card_3) * 0.05
    elif card[0] == CardValue.Card_A:
        if sortedCards.count(CardValue.Card_2) > 2:
            ret = 1.0
        else:
            ret = 0.9
    elif cardClass == CardClass.MIDDLE:
        ret = 0.55 + (keyCardValue - CardValue.Card_10) * 0.1
    elif card[0] == CardValue.Card_2:
        if sortedCards.count(CardValue.Card_2) > 2:
            ret = 1.01
        else:
            ret = 1.0
    return ret
    '''
    ret = 1.0
    keyCardValue = card[0]
    cardClass = getCardClass(keyCardValue)
    restCards = gameInfo.getOtherRestCards()
    restCards = restCards[::-1]
    maxPair = CardValue.Card_Min
    for index in range(0, len(restCards)-1):
        if restCards[index] == restCards[index+1]:
            maxPair = restCards[index]
            break

    if keyCardValue > maxPair:
        ret = 1.01
    elif keyCardValue == maxPair:
        ret = 1.0
    elif cardClass == CardClass.SMALL:
        ret = 0.1 + (keyCardValue - CardValue.Card_3) * 0.05
    elif card[0] == CardValue.Card_A:
        if restCards.count(CardValue.Card_2) > 2:
            ret = 0.9
        else:
            ret = 1.0
    elif cardClass == CardClass.MIDDLE:
        ret = 0.55 + (keyCardValue - CardValue.Card_10) * 0.1 #0.55-0.85
    elif card[0] == CardValue.Card_2:
        if restCards.count(CardValue.Card_2) >= 2:
            ret = 1.0
        else:
            ret = 1.01
    return ret

def getWeightForThree(gameInfo, card, quick = True):
    cardKeyValue = card[0]
    # 认为这个AAA 222是100%大牌
    if cardKeyValue == CardValue.Card_A:
        return 1.00
    elif cardKeyValue == CardValue.Card_2:
        return 1.01

    if quick == True:
        cardClass = getCardClass(cardKeyValue)
        if cardClass == CardClass.SMALL:
            ret = 0.35 + (cardKeyValue - CardValue.Card_3) * 0.05
        elif cardClass == CardClass.MIDDLE:
            ret = 0.75 + (cardKeyValue - CardValue.Card_10) * 0.05
        elif cardClass == CardClass.LARGE:
            ret = 1
        return ret

    #随机N次，看看有没有3带1能管上
    rate = 0
    for i in range(0,ConstCard.RANDCOM_COUNT,1):
        opponentCards = getRandomOpponentCards(gameInfo)
        bFound = False
        for cards in opponentCards:
            for index in range(0,len(cards)-2):
                if cards[index] > cardKeyValue and cards[index] < CardValue.Card_2 \
                        and cards[index+1] == cards[index] and cards[index+2] == cards[index]:
                    rate += 1
                    bFound = True
                    break
            if bFound == True:
                break
    #print(rate)
    ret = (ConstCard.RANDCOM_COUNT - rate) / ConstCard.RANDCOM_COUNT
    ret = min(1.0, max(ret * (1.0 + cardKeyValue * 0.03), 0.31))
    #ret = max(ret, 0.31)
    return ret

def getWeightForPairs(gameInfo, card, quick = True):
    length = math.floor(len(card) / 2)
    start = card[0]
    end = card[-1]
    if end == CardValue.Card_A: #最后一个元素等于A
        return 1.0

    if quick == True:
        ret = (length + start - CardValue.Card_3) / 10
        if ret > 1.0:
            ret = 1.0
        return ret

    # 随机N次，看看有没有连对能管上
    rate = 0
    for i in range(0,ConstCard.RANDCOM_COUNT,1):
        opponentCards = getRandomOpponentCards(gameInfo)
        for cards in opponentCards:
            index = 1
            while(end + index <= CardValue.Card_A):
                bFound = True
                for value in range(start+index, end+index+1):
                    if cards.count(value) < 2:
                        bFound = False
                        break
                index += 1
                if bFound == True: # 找到任意一个大的连对，即可完成任务
                    break
            if bFound == True:
                rate += 1
                break
    ret = (ConstCard.RANDCOM_COUNT - rate) / ConstCard.RANDCOM_COUNT
    ret = min(1.0, max(ret * (start+length/4), 0.51))
    #ret = max(ret, 0.51)
    return ret

def getWeightForStraight(gameInfo, card, quick = True):
    length = len(card)
    start = card[0]
    end = card[-1]
    if end == CardValue.Card_A: #最后一个元素等于A
        return 1.0
    if quick == True:
        ret = (length + start - CardValue.Card_3 - 2) / 10
        if ret > 1.0:
            ret = 1.0
        return ret

    #随机N次，看看有没有顺子能管上
    rate = 0
    for i in range(0,ConstCard.RANDCOM_COUNT,1):
        opponentCards = getRandomOpponentCards(gameInfo)
        for cards in opponentCards:
            index = 0
            while(end + index <= CardValue.Card_A):
                bFound = True
                for value in range(start+index, end+index):
                    if value not in cards:
                        bFound = False
                        break
                index += 1
                if bFound == True: # 找到任意一个大的顺子，即可完成任务
                    break
            if bFound == True:
                rate += 1
                break
    ret = (ConstCard.RANDCOM_COUNT - rate) / ConstCard.RANDCOM_COUNT
    #ret = min(1.0, max(ret*(start+length)/10, 0.41))
    ret = min(1.0, max(ret * (start + end) / 10, 0.41))
    #ret = max(ret, 0.41)
    return ret

# 计算大牌概率，简称牌权
# 简版实现，固定公式计算quick=True；精细版实现需要抽牌N次，来计算quick=False
# 输入 gameInfo,包含现在的所有牌局信息，参见DouDiZhu2的类定义
# 输入 sortedCards, 已经公开的明牌列表，已经排好序
# 输入 quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)
# 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
# TODO 根据出牌数据和自己手中的牌 评估 对手或者对手能管 某牌型 的概率，为此定义个名词：牌权
#def getMaxProbability(sortedCards, card, kind, quick = True, role, landlordCardSequence, peasantCardSequence):
def getCardWeight(gameInfo, card, kind, quick=True, absolute=False):
    opponentRestCardLength = gameInfo.getOpponentRestCardsLength()
    if opponentRestCardLength < len(card): # 对手牌长度小于我方出牌长度，所以肯定管不起
        return 1.00 + card[0]/1000

    if absolute == False: #绝对情况下是不考虑 对手不管牌的推导情况的
        lastDuckedCardKind = gameInfo.getOpponentLastDuckedCardKind(kind)
        if len(lastDuckedCardKind) > 0 and len(lastDuckedCardKind) == len(card) and lastDuckedCardKind[0] <= card[0]:
            if isSingle(card):
                weight = getWeightForSingle(gameInfo, card, quick)
                if lastDuckedCardKind[0] == card[0]:
                    return max(weight, 0.99)
                else:
                    return max(weight, 1.0)
            elif isPair(card):
                weight = getWeightForPair(gameInfo, card, quick)
                if lastDuckedCardKind[0] == card[0]:
                    return max(weight, 0.99)
                else:
                    return max(weight, 1.0)
            else:
                if lastDuckedCardKind[0] == card[0]:
                    return 0.99
                else:
                    return 1.0
        #以上调整为1.00，是为了避免炸弹/双王先出

    if kind == CardKind.ROCKET:
        return 1.02
    elif kind == CardKind.BOMB:
        return 1.01

    elif kind == CardKind.FOUR_PLUS1 or kind == CardKind.FOUR_PLUS2:
        return 1.0
    elif kind == CardKind.PLANE_PLUS1 or kind == CardKind.PLANE_PLUS2:
        return 1.0
    elif kind == CardKind.PLANE_EMPTY:
        return 1.0

    elif kind == CardKind.STRAIGHT:
        return getWeightForStraight(gameInfo, card, quick)
    elif kind == CardKind.SINGLE:
        return getWeightForSingle(gameInfo, card, quick)
    elif kind == CardKind.PAIR:
        return getWeightForPair(gameInfo, card, quick=True) # 对子随机 1 算出来牌权很小，2 计算量增大，所以废弃
    elif kind == CardKind.PAIRS:
        return getWeightForPairs(gameInfo, card, quick)
    elif kind == CardKind.THREE or kind == CardKind.THREE_PLUS1 or kind == CardKind.THREE_PLUS2:
        return getWeightForThree(gameInfo, card, quick=True) # 三带一 随机发牌算出牌权不准确

    else: # 异常情况
        print("getMaxProbability", kind, card)
        raise BaseException("Exception getMaxProbability kind:",kind,"Card:",card)

    return 0

# 获取炸弹包括火箭的概率
# 输入 cardCombination, 牌组，即玩家当前手牌，其中牌组是排好序了的，小的牌型在前，大的在后
# 输入 minBombKeyCardValue,   需要比这个炸弹要大

# 以下输入包含在gameInfo中
# 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
# 输入 sortedCards, 已经公开的明牌列表，已经排好序
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
def getOpponentRateForBombRocket(gameInfo, minBombKeyCardValue = CardValue.Card_Min):
    # 随机N次，看看炸弹的概率
    size = gameInfo.getOpponentRestCardsLength()
    if size < 4:
        return 0.0

    rate = 0
    for i in range(0, ConstCard.RANDCOM_COUNT, 1):
        opponentCards = getRandomOpponentCards(gameInfo)
        bFound = False
        for roleCards in opponentCards:
            if roleCards[-1] == CardValue.Card_R and roleCards[-2] == CardValue.Card_B:
                bFound = True # Found Rocket
                break
            else:
                for index in range(0,len(roleCards)-3):
                    if roleCards[index+3] == roleCards[index] and roleCards[index] > minBombKeyCardValue:
                        bFound = True # Found Bomb
                        break
            if bFound == True: # 已经在这个roleCards里面找到了，那么下一个就不用找了
                break
        if bFound == True: #已经找到了，那么rate+1
            rate += 1
    ret = rate / ConstCard.RANDCOM_COUNT
    return ret


# 获取对手火箭的概率
# 以下输入包含在gameInfo中
# 输入 sortedCards, 已经公开的明牌列表，已经排好序
# 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
def getOpponentRateForRocket(gameInfo):
    opendedCards = gameInfo.getOpenedCards()
    if len(opendedCards) > 0 and (opendedCards[-1] == CardValue.Card_R or opendedCards[-1] == CardValue.Card_B):
        return 0.0
    else:
        # 随机N次，看看火箭的概率
        size = gameInfo.getOpponentRestCardsLength()
        if size < 2:
            return 0.0

        rate = 0
        for i in range(0, ConstCard.RANDCOM_COUNT, 1):
            opponentCards = getRandomOpponentCards(gameInfo)
            for roleCards in opponentCards:
                if roleCards[-1] == CardValue.Card_B and roleCards[-2] == CardValue.Card_R:
                    rate += 1
                    break
        ret = (ConstCard.RANDCOM_COUNT - rate) / ConstCard.RANDCOM_COUNT
        return ret

def correctNormalValues(normalValues, correctValues):
    correctCount = 0
    for k, v in enumerate(normalValues): # 优先匹配最佳牌型来校正(提升)
        maxKey = None
        maxRatio = 0.0
        for key, value in enumerate(correctValues):
            if value[0] > v[0] and v[0] < 1.0:
                kind = getCardKind(value[1])
                if kind in (CardKind.BOMB, CardKind.ROCKET): #炸弹肯定能夺回牌权
                    ratio = 1.0
                elif kind == getCardKind(v[1]): #correct和normal类型相同
                    ratio = 1.01 # 校正，即调高之，牌型相同所以损失小
                elif len(value[1]) < len(v[1]): # 短牌型 控 长牌型，可能性比较小
                    ratio = 0.85 # 校正，即调高之，原有的指标要打折，因为控牌权不一定能抢回来
                else: # 长牌型 控 短牌型，可能性相对较大
                    ratio = 0.95
                if ratio > maxRatio:
                    maxRatio = ratio
                    maxKey = key
        if maxKey != None:
            if maxRatio > 1.0 : #同牌型取值为1.01，之所以先定义为1.01又调整为0.99，是为了优先使用同牌型来校准
                maxRatio = 0.99

            maxValue = correctValues[maxKey]
            if normalValues[k][0] < maxValue[0] * maxRatio:
                normalValues[k][0] = maxValue[0] * maxRatio
                correctValues.pop(maxKey)  # 删除保存用来校准的大牌价值
                if maxRatio not in (0.99,1.0): # 同类型自然校正或者炸弹校正，不计校正次数
                    correctCount += 1
        # 考虑以下情况，容易忽略有大牌照应的拆散情况。调高打折系数为0.9
        #cards = [3, 3, 3, 4, 4, 5, 6, 7, 7, 7, 8, 8, 9, 11, 11, 13, 13, 14, 20, 40]
        #Top: 1 [0.0488, [3, 3], [3, 4, 5, 6, 7, 8, 9], [4], [7, 7], [8], [11, 11], [13, 13], [14], [20], [40]]
        #Top: 2 [0.04800000000000001, [3, 3, 3, 8], [4, 4], [5, 6, 7, 8, 9], [7, 7], [11, 11], [13, 13], [14], [20], [40]]

    # DEBUG info
    #if quick == False:
    #    print("Corrected NormalValues:", normalValues, correctValues)

    totalValue = 1.0 #百分数
    for value in normalValues:
        totalValue = totalValue * value[0]

    # 多出来的大牌需要加权重，最多乘两次，1.15 * 1.15 = 1.3225
    #count = min(len(correctValues), 2)
    improveCount = 0
    if totalValue < 1.0: # 对不足的加权，最多牌力加满到1.0
        for key, value in enumerate(correctValues):
            if key > 3:
                break
            totalValue = totalValue * (1 + max(value[0] - 0.80, 0))
            improveCount += 1
    totalValue = min(totalValue, 1.0)
    totalValue -= totalValue * 0.02 * correctCount
    totalValue += (len(correctValues) - improveCount) * 0.01
    return totalValue

# 对牌组估值（首牌、引牌）
# 输入gameInfo,包含现在的所有牌局信息，参见DouDiZhu2的类定义
# 输入sortedCards, 已经公开的明牌列表，已经排好序
# cardCombination, 牌组列表，其中牌组是排好序了的，小的牌型在前，大的在后
# quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)
# lead, True代表已经掌握控牌权，会带出一个控牌权最小的牌型
# 返回列表，0位置为原始牌力，1 位置为估值 2 位置为奖励参数， 3:为牌组，示例：
#<class 'list'>: [1.26, 125.99999999999999, 2.0, [6, 6, 6, 5], [7, 7, 8, 8, 9, 9], [10, 10, 10, 10, 11, 14], [12, 12], [30, 40]]
def valuationCardCombination(cardCombination, gameInfo, quick = True, lead = False):
    ret = []
    cardKindsArray = {}
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        if cardKindsArray.get(kind):
            cardKindsArray[kind].append(cardKind)
        else:
            cardKindsArray[kind] = []
            cardKindsArray[kind].append(cardKind)

    #if quick == False:
    #    normalValues = []

    normalValues = [] #每轮出牌的大牌指数，即被管概率, cardArray, value 牌型牌权的二元组
    correctValues = [] #校正，多出来的大牌可以抢夺发牌权，所以可以替换掉一个最小的normalValue，cardArray, value 牌型牌权的二元组
    param = 1.0 # 春天/炸弹指数， 暂时忽略春天
    # 之前已经排好序了，按分类 单双三带一 连对顺子组队, 飞机暂时认为无敌
    kindValues = []
    for kind, cardKindArray in cardKindsArray.items():
        param, kindValue = autoBoxing(kind, cardKindArray, gameInfo, normalValues, correctValues, param, quick)
        kindValues += kindValue

    normalValues.sort(key=lambda value : value[0])
    if len(normalValues) > 0 and lead == True:
        normalValues.pop(0) #因为是地主，有优先出牌权，所以可以去掉一轮
    correctValues.sort(key=lambda value : value[0], reverse=True) #先用最大值校对，避免重复校对同一项，后来的覆盖前面的

    bakNormalValues = normalValues[:]
    bakCorrectValues = correctValues[:]
    leadValue = 0.0
    totalValue = correctNormalValues(normalValues, correctValues)
    leadValue = totalValue

    # TODO 粗选春天或者直接收牌的激进打法
    rawValue = 1.0
    if leadValue > 0.80:  # 减少计算量
        rawValues = []
        for kind, cardKindArray in cardKindsArray.items():
            cardArray = cardKindArray[:]
            for cardKind in cardArray:
                value = getCardWeight(gameInfo, cardKind, kind, quick=False, absolute=True)
                rawValues.append(value)
        rawValues.sort()
        #if len(rawValues) > 0 and lead == False: #如果lead == True, 则实际上已经去掉了
        if len(rawValues) > 0:  # 如果lead == True, 则实际上已经去掉了
            rawValues.pop(0) # 去掉最小的一个，然后再判断是否适合激进打法

        for value in rawValues:
            rawValue *= value
    else:
        rawValue = 0.0

    if rawValue > 0.95 and len(cardCombination) > 1:
        # ret.append(False) # 激进打法
        ret.append(rawValue)
        if False == judgeStratey(cardCombination, quick, gameInfo) and lead == False: #重算价值即 重算TotalValue
            if len(bakNormalValues) > 0:
                bakNormalValues.pop(0)
            #print("Prev TotalValue:", totalValue, cardCombination)
            #TODO 激进打法是否需要加权值，例如乘以101%？ 这样同在100%胜率的时候能够脱颖而出
            totalValue = correctNormalValues(bakNormalValues, bakCorrectValues)
    else:
        # ret.append(True) # 保守打法
        ret.append(rawValue)
    if totalValue < 0.0:
        totalValue = 0.0

    totalValue *= 100 #转为百分数
    #for element in kindValues:
    #    totalValue -= (1.0 - element[1]) * 30
    ret.append(totalValue * param) #加大牌组权重，减轻炸弹春天权重
    #ret.append(totalValue) #TODO 暂时忽略炸弹春天影响
    ret.append(param)
    ret += cardCombination
    return ret

# 对管牌的牌组估值
# 输入 coverCardKind, 用来管牌的牌型，不包含在cardCombination里面
# 输入 cardCombinations, 牌组列表，其中牌组是排好序了的，小的牌型在前，大的在后
# 输入gameInfo,包含以下信息：
# 输入 sortedCards, 已经公开的明牌列表，已经排好序
# 管牌不一定是一轮的结束，需要管牌+同牌型大牌作为一轮
#连对顺子飞机四带炸弹火箭管牌即结束这一轮，单双三带则可回收
#单张：只有大牌能带小牌，中牌自己顾自己
#对子：中大牌可带小牌，中牌自己顾自己
#三带：中大牌可带小牌，大牌带中牌
#管牌但是需要同牌型大牌来控牌，则降权系数例如 * 0.9
# 返回列表，0位置为原始牌力，1 位置为估值 2位置为奖励参数 3:为牌组，示例：
#<class 'list'>: [1.26, 125.99999999999999, 2.0, [6, 6, 6, 5], [7, 7, 8, 8, 9, 9], [10, 10, 10, 10, 11, 14], [12, 12], [30, 40]]
def valuationCoverCardCombination(coverCardKind, cardCombination, gameInfo, quick = True):
    ret = []
    cardKindsArray = {}
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        if cardKindsArray.get(kind):
            cardKindsArray[kind].append(cardKind)
        else:
            cardKindsArray[kind] = []
            cardKindsArray[kind].append(cardKind)

    coverCardKindValue = 1.0
    normalValues = [] #每轮出牌的大牌指数，即被管概率
    correctValues = [] #校正，多出来的大牌可以抢夺发牌权，所以可以替换掉一个最小的normalValue
    param = 1.0 # 春天/炸弹指数， 暂时忽略春天

    kind = getCardKind(coverCardKind)
    keyCardValue = coverCardKind[0]
    keyCardClass = getCardClass(keyCardValue)
    maxCardKind = None
    if cardKindsArray.get(kind):
        maxCardKind = getCardKindController(kind, coverCardKind, cardKindsArray[kind], gameInfo)
    else:
        maxCardKind = None

    '''
    if maxCardKind != None:
        # 单张：只有大牌能带小牌中牌
        if kind == CardKind.SINGLE \
            and keyCardClass != CardClass.LARGE and getCardClass(maxCardKind[0]) == CardClass.LARGE:
            rate = getCardWeight(gameInfo, maxCardKind, kind, quick)
            normalValues.append(rate * 0.9)
            cardKindsArray[kind].pop() # delete the last one

            # 对子：中大牌可带小牌,大对也可带小对
        elif kind == CardKind.PAIR \
            and keyCardClass != getCardClass(maxCardKind[0]):
            rate = getCardWeight(gameInfo, maxCardKind, kind, quick)
            normalValues.append(rate * 0.9)
            cardKindsArray[kind].pop()  # delete the last one

        # 三带：中大牌可带小牌，大牌带中牌
        elif (kind == CardKind.THREE or kind == CardKind.THREE_PLUS1 or kind == CardKind.THREE_PLUS2) \
            and getCardClass(maxCardKind[0]) > keyCardClass:
            rate = getCardWeight(gameInfo, maxCardKind, kind, quick=True) # TODO 三带一用这种随机方法算出的概率不准确，不如公式
            normalValues.append(rate * 0.9)
            cardKindsArray[kind].pop()  # delete the last one

        else: #其他牌型或者情况则认为本轮结束，将coverCardKind放入normalValues计算即可
            if kind == CardKind.BOMB:
                param = param * 1.2 #先只求赢牌，降低管牌的时候炸弹的翻倍收益
                #normalValues.append(1.01)
                coverCardKindValue = 1.01
            elif kind == CardKind.ROCKET:
                param = param * 1.1 #先只求赢牌，降低管牌的时候炸弹的翻倍收益
                #normalValues.append(1.02)
                coverCardKindValue = 1.02
            else:
                rate = getCardWeight(gameInfo, coverCardKind, kind, quick)
                #if getCardClass(keyCardValue) == CardClass.LARGE:
                #normalValues.append(rate)
                coverCardKindValue = rate
    '''
    coverNormalValues = []
    coverCorrectValues = []
    kindValues = []
    if maxCardKind != None:
        coverCardArrays = [coverCardKind, maxCardKind]
        param, kindValue = autoBoxing(kind, coverCardArrays, gameInfo, coverNormalValues, coverCorrectValues, param, quick)
        cardKindsArray[kind].remove(maxCardKind)
        kindValues += kindValue
    else: #该coverCardKind同牌型没有其他牌了, 或者同牌型没有大牌了
        if kind == CardKind.BOMB:
            param = param * 1.2 #先只求赢牌，降低管牌的时候炸弹的翻倍收益
            coverCardKindValue = 1.01
        elif kind == CardKind.ROCKET:
            param = param * 1.1 #先只求赢牌，降低管牌的时候炸弹的翻倍收益
            coverCardKindValue = 1.02
        else:
            coverCardKindValue = getCardWeight(gameInfo, coverCardKind, kind, quick)

    # 之前已经排好序了，按分类 单双三带一 连对顺子组队, 飞机暂时认为无敌
    # TODO 顺子还需要按照长度来配对，或许还要考虑拆顺子？
    for kind, cardKindArray in cardKindsArray.items():
        param, kindValue = autoBoxing(kind, cardKindArray, gameInfo, normalValues, correctValues, param, quick)
        kindValues += kindValue
    '''
    for kind, cardKindArray in cardKindsArray.items():
        if kind == CardKind.SINGLE:
            cardArray = cardKindArray[:]
            while(len(cardArray) > 0):
                keyCardValue = cardArray[0][0]
                # 只有大牌能带小牌，中牌自己顾自己
                minValue = getCardWeight(gameInfo, cardArray[0], kind, quick)
                maxValue = getCardWeight(gameInfo, cardArray[-1], kind, quick)
                if minValue < 0.90 and maxValue >= 0.90:
                #if getCardClass(keyCardValue) <= CardClass.MIDDLE \
                        # and getCardClass(cardArray[-1][0]) == CardClass.LARGE:
                    normalValues.append(maxValue * 0.99) # 带出去的可能需要降权,不然三带一带不带有可能无所谓
                    cardArray.pop() # delete the last one
                    cardArray.pop(0) # delete the first one
                else:
                    #value = getCardWeight(gameInfo, cardArray[0], kind, quick)
                    # 不带小牌的 大单张对子三带 可用来争夺控牌权，从而校准价值
                    if getCardClass(keyCardValue) == CardClass.LARGE:
                        correctValues.append(minValue)
                    else:
                        normalValues.append(minValue)
                    cardArray.pop(0)

        elif kind == CardKind.PAIR or kind == CardKind.THREE \
            or kind == CardKind.THREE_PLUS1 or kind == CardKind.THREE_PLUS2:
            cardArray = cardKindArray[:]
            while (len(cardArray) > 0):
                keyCardValue = cardArray[0][0]
                # 中大牌可带小牌
                if getCardClass(keyCardValue) == CardClass.SMALL \
                    and getCardClass(cardArray[-1][0]) > CardClass.SMALL:
                    value = getCardWeight(gameInfo, cardArray[-1], kind, quick)
                    normalValues.append(value * 1)  # 带出去的可能需要降权,不然三带一带不带有可能无所谓
                    cardArray.pop()  # delete the last one
                    cardArray.pop(0)  # delete the first one
                else:
                    value = getCardWeight(gameInfo, cardArray[0], kind, quick)
                    # 不带小牌的 大单张对子三带 可用来争夺控牌权，从而校准价值
                    if getCardClass(keyCardValue) == CardClass.LARGE:
                        correctValues.append(value)
                    else:
                        normalValues.append(value)
                    cardArray.pop(0)

        elif kind == CardKind.STRAIGHT or kind == CardKind.PAIRS:
            dictValues = {}
            for element in cardKindArray:
                value = getCardWeight(gameInfo, element, kind, quick)
                size = len(element)
                if dictValues.get(size) == None:
                    dictValues[size] = value
                elif dictValues[size] < 0.99 * value:  # 同长度大的覆盖小的，如果同长度有3个，最大的带小的2个
                    dictValues[size] = value * 0.99 # 覆盖的话需要稍稍降权，避免将到顶的长链子拆开

            for key in dictValues:
                normalValues.append(dictValues[key])

        elif kind == CardKind.BOMB:
            #param = param * math.pow(2, len(cardKindArray))
            param = param * 2 ** len(cardKindArray) # ** 比 pow效率更高
            correctValues.append(1.01)
            #normalValues.append(1.0)
        elif kind == CardKind.ROCKET:
            param = param * 2.5 # 火箭，你值得持有
            correctValues.append(1.02)
            #normalValues.append(1.0)
        #假定飞机无牌能管
        elif kind == CardKind.PLANE_EMPTY or kind == CardKind.PLANE_PLUS1 or kind == CardKind.PLANE_PLUS2:
            normalValues.append(1.0)
        elif kind == CardKind.FOUR_PLUS1 or kind == CardKind.FOUR_PLUS2:
            normalValues.append(1.0)
    '''
    '''
    if quick == False:
        LogUtil.Log("valuationCardCombination:", "Quick=", quick, "coverCardKind=", coverCardKind, cardCombination)
        LogUtil.Log("kindValues:", kindValues)
        LogUtil.Log("normalValues:", normalValues, "correctValues:", correctValues)
    '''

    #Debug info
    '''
    if gameInfo.getOpponentRestCardsLength() == 2:
        print("CardCombination:", cardCombination)
        print("NormalValues:", normalValues)
        print("CorrectValues:", correctValues)
    '''

    normalValues.sort(key=lambda  value: value[0])
    if len(normalValues) > 0:
        normalValues.pop(0) #假定是地主，有优先出牌权，所以可以去掉一轮
    if maxCardKind == None:
        normalValues.append([coverCardKindValue, coverCardKind])  # coverCardKind单独计算
    else:
        normalValues += coverNormalValues
        correctValues += coverCorrectValues
    normalValues.sort(key=lambda value: value[0])
    correctValues.sort(key=lambda  value: value[0], reverse=True) #先用最大值校对，避免重复校对同一项，后来的覆盖前面的
    correctCount = 0

                # 考虑以下情况，容易忽略有大牌照应的拆散情况。调高打折系数为0.9
                #cards = [3, 3, 3, 4, 4, 5, 6, 7, 7, 7, 8, 8, 9, 11, 11, 13, 13, 14, 20, 40]
                #Top: 1 [0.0488, [3, 3], [3, 4, 5, 6, 7, 8, 9], [4], [7, 7], [8], [11, 11], [13, 13], [14], [20], [40]]
                #Top: 2 [0.04800000000000001, [3, 3, 3, 8], [4, 4], [5, 6, 7, 8, 9], [7, 7], [11, 11], [13, 13], [14], [20], [40]]

    # DEBUG info
    #if quick == False:
    #    print("Corrected NormalValues:", normalValues, correctValues)

    totalValue = correctNormalValues(normalValues, correctValues)
    if totalValue < 0:
        totalValue = 0

    totalValue *= 100 #转为百分数
    #for element in kindValues:
    #    totalValue -= (1.0 - element[1]) * 10
    ret.append(totalValue * param)
    #ret.append(totalValue)  # TODO 暂时忽略炸弹春天影响
    ret.append(param)
    ret += cardCombination
    return ret

# 对牌组估值（管牌）
# 输入 coverCardKind，出牌
# 输入 openedCards，已经公开的牌面（玩家手里的牌和所有人已经出的牌），已经排序
# 输入 cardCombinations，除掉出牌后剩余手牌的可能组合
# 返回二级列表，即列表元素为一个列表，0位置为估值，1位置为奖励系数，2:为牌组，元素示例：
#<class 'list'>: [125.99999999999999, 2.0, [6, 6, 6, 5], [7, 7, 8, 8, 9, 9], [10, 10, 10, 10, 11, 14], [12, 12], [30, 40]]
def valuationCoverCardCombinations(coverCardKind, cardCombinations, gameInfo):
    quickRet = []
    for cardCombination in cardCombinations:
        valuedComb = valuationCoverCardCombination(coverCardKind, cardCombination, gameInfo, quick=True)
        runComb = valuationCardCombination(cardCombination, gameInfo, quick=True, lead=False)
        if valuedComb[0] > runComb[1]:
            quickRet.append(valuedComb)
        else:
            quickRet.append(runComb[1:])
    #quickRet.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    quickRet.sort(key= lambda comb : comb[0], reverse=True) #降序，只对首位Value值排序
    quickRet = quickRet[0:ConstCard.TOP_BY_COUNT] #粗选N个
    #return quickRet

    ret = []
    for valuedComb in quickRet:
        cardCombination = valuedComb[2:]
        # 按照控牌计算牌力
        tempValuedComb = valuationCoverCardCombination(coverCardKind, cardCombination, gameInfo, quick=False)
        # 按照跑牌计算牌力 TODO 现在不管，后来管，计算牌力是否需要下调数值？
        runComb = valuationCardCombination(cardCombination, gameInfo, quick=False, lead=False)
        runComb[1] = runComb[1] * 0.90
        if tempValuedComb[0] > runComb[1]:
            ret.append(tempValuedComb)
        else:
            ret.append(runComb[1:])
    # ret.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    ret.sort(key= lambda comb : comb[0] * 100 + 20 - len(comb[2:]), reverse=True) #降序，对首位Value值排序(逆序)，次关键字为牌组长度(顺序)
    ret = ret[0:ConstCard.TOP_BY_COUNT]
    return ret

# 对牌组估值（首牌、引牌）
# 输入sortedCards, 已经公开的明牌列表，已经排好序
# 输入gameInfo,包含现在的所有牌局信息，参见DouDiZhu2的类定义
# cardCombinations, 牌组列表，其中牌组是排好序了的，小的牌型在前，大的在后
# lead, True代表已经掌握控牌权，会带出一个控牌权最小的牌型
# 返回二级列表，即列表元素为一个列表，0位置为原始牌力，1 位置为综合牌力 2位置为奖励系数，3:为牌组，元素示例：
#<class 'list'>: [0.90, 125.99999999999999, [6, 6, 6, 5], [7, 7, 8, 8, 9, 9], [10, 10, 10, 10, 11, 14], [12, 12], [30, 40]]
def valuationCardCombinations(cardCombinations, gameInfo, lead=False):
    quickRet = []
    for cardCombination in cardCombinations:
        valuedComb = valuationCardCombination(cardCombination, gameInfo, True, lead)
        quickRet.append(valuedComb)
    #quickRet.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    quickRet.sort(key= lambda comb : comb[1], reverse=True) #降序，只对次位Value值排序
    quickRet = quickRet[0:ConstCard.TOP_BY_COUNT] #粗选N个
    #return quickRet

    ret = []
    for valuedComb in quickRet:
        cardCombination = valuedComb[3:]
        tempValuedComb = valuationCardCombination(cardCombination, gameInfo, False, lead)
        ret.append(tempValuedComb)
    # ret.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    # 降序，只对次位Value值排序,次级关键词为牌组长度
    ret.sort(key= lambda comb : comb[1] * 100 + 20 - len(comb[3:]), reverse=True)
    ret = ret[0:ConstCard.TOP_BY_COUNT]
    return ret

""" #初始版本，强调控牌，忽略了跑牌
def sortCardCombination(sortedCards, cardCombination, quick):
    controlledCardRet = [] #控牌先出 TODO 大牌越多的牌型越好
    smallCardRet = [] # 小牌其次
    topRet = [] #最后出大牌
    cardKindsArray = {}
    # 之前cardCombination已经排好序了，所以此处不再排序
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        if cardKindsArray.get(kind):
            cardKindsArray[kind].append(cardKind)
        else:
            cardKindsArray[kind] = []
            cardKindsArray[kind].append(cardKind)

    #优先出能控牌(>95%概率?)的牌型中的最小牌
    for kind, cardKindArray in cardKindsArray.items():
        if kind == CardKind.ROCKET:
            topRet.append([1.01, cardKindArray[0]])
        elif kind == CardKind.BOMB:
            topRet.append([1.00, cardKindArray[0]])
        elif kind == CardKind.PLANE_EMPTY or kind == CardKind.PLANE_PLUS1 or kind == CardKind.PLANE_PLUS2:
            topRet.append([0.99, cardKindArray[0]])
        else:
            if len(cardKindArray) == 1:
                bottomValue = getMaxProbability(sortedCards, cardKindArray[0], kind, quick)
                if bottomValue >= 0.9:
                    topRet.append([bottomValue, cardKindArray[0]])
                else:
                    smallCardRet.append([bottomValue, cardKindArray[0]])
            else:
                topValue = getMaxProbability(sortedCards, cardKindArray[-1], kind, quick)
                bottomValue = getMaxProbability(sortedCards, cardKindArray[0], kind, quick)
                if topValue >= 0.95 and bottomValue < 0.9:
                    controlledCardRet.append([bottomValue, cardKindArray[0]])
                elif bottomValue > 0.9:
                    topRet.append([bottomValue, cardKindArray[0]])
                else:
                    smallCardRet.append([bottomValue, cardKindArray[0]])


    if controlledCardRet: # not empty
        controlledCardRet.sort(key=lambda comb: comb[0] * 10000 + comb[1][0])  # 升序，只对首位Value值排序；相同则比较KeyCardValue
        return controlledCardRet[0][1]
    #如果不能控牌，则出控牌概率最小的牌
    elif smallCardRet:
        smallCardRet.sort(key=lambda comb: comb[0] * 10000 + comb[1][0])  # 升序，只对首位Value值排序；相同则比较KeyCardValue
        return smallCardRet[0][1]
    else:
        topRet.sort(key=lambda comb: comb[0] * 10000 + comb[1][0])  # 升序，只对首位Value值排序；相同则比较KeyCardValue
        return topRet[0][1]
"""

# 控牌牌型：单张、对子、三带 先出
CardKindOrder = {
    CardKind.SINGLE : 2.00, #单张
    CardKind.PAIR : 2.00, #对子
    CardKind.THREE : 2.30, #三张
    CardKind.THREE_PLUS1 : 2.31,  # 三带单
    CardKind.THREE_PLUS2 : 2.32, # 三带对
    CardKind.BOMB : 0.20, # 炸弹
    CardKind.FOUR_PLUS1 : 1.41, # 四带2单
    CardKind.FOUR_PLUS2 : 1.42, # 四带2对
    CardKind.STRAIGHT : 1.50, # 顺子
    CardKind.PAIRS : 1.60, # 连对
    CardKind.PLANE_EMPTY : 1.80, # 飞机空载
    CardKind.PLANE_PLUS1 : 1.81, # 飞机带单
    CardKind.PLANE_PLUS2 : 1.82, # 飞机带双
    CardKind.ROCKET : 0.10 # 火箭
}

CardValueOrder = {
    CardValue.Card_3 : 1.20,
    CardValue.Card_4 : 1.19,
    CardValue.Card_5 : 1.18,
    CardValue.Card_6 : 1.17,
    CardValue.Card_7 : 1.16,
    CardValue.Card_8 : 1.15,
    CardValue.Card_9 : 1.14,
    CardValue.Card_10 : 1.13,
    CardValue.Card_J : 1.0,
    CardValue.Card_Q : 0.9,
    CardValue.Card_K : 0.7,
    CardValue.Card_A : 0.5,
    CardValue.Card_2 : 0.3,
    CardValue.Card_B : 0.2, #小王
    CardValue.Card_R : 0.1, #大王
}
# coverCardKind: 要出的牌型
# cardKindsArray：牌型列表
# 返回：同牌型能管回来的牌
def getCardKindController(kind, coverCardKind, cardKindsArray, gameInfo):
    ret = None
    coverWeight = getCardWeight(gameInfo, coverCardKind, kind, quick=False)
    if isCarrier(coverWeight): # coverCardKind 已经是大牌
        return None

    maxCardKind = cardKindsArray[-1]
    coverIndex = 0
    controllerCount = 0
    for cardArray in cardKindsArray:
        if coverCardKind[0] > cardArray[0]:
            coverIndex += coverIndex

        kindWeight = getCardWeight(gameInfo, cardArray, kind, quick=False)
        if kindWeight >= 0.9:
            controllerCount += 1

    maxWeight = getCardWeight(gameInfo, maxCardKind, kind, quick=False)
    if coverIndex > controllerCount:
        ret = None
    elif maxWeight >= coverWeight + 0.2:#牌权有间隔，才可能再管回来
        ret = maxCardKind
    else:
        ret = None
    return ret

def getWeakPoints(cardCombination, gameInfo):
    weakPoints = 0.0
    for element in cardCombination:
        kind = getCardKind(element)
        weight = getCardWeight(gameInfo, element, kind, quick=False, absolute=True)
        weakPoints = weakPoints + (1.0 - weight)
    return weakPoints

# 输入 cardCombination，牌组
# 输出 True Flase， 该牌组是否还有可能冲牌
#TODO 是否需要考虑带牌的情况？
def canRush(cardCombination, gameInfo):
    currentRole = gameInfo.getCurrentRole()
    restCards = gameInfo.getRestCards()
    restCardsLength = len(restCards)
    kindValues = []
    if currentRole == CardRole.LANDLORD:
        for cardArray in cardCombination:
            kind = getCardKind(cardArray)
            weight = getCardWeight(gameInfo, cardArray, kind, quick=False, absolute=True)
            if weight < 0.99:
                kindValues.append([cardArray, weight, kind])
            else:
                restCardsLength -= len(cardArray)
        for element in kindValues:
            if restCardsLength - len(element[0]) <= 2:
                restKindValues = kindValues[:]
                restKindValues.remove(element)
                for value in restKindValues: #有大牌
                    if value[1] > 1.0:
                        return True
                for value in restKindValues: #没有大牌带，还有小牌
                    if value[1] < 0.7: # A以下
                        return False
    else:
        for cardArray in cardCombination:
            kind = getCardKind(cardArray)
            weight = getCardWeight(gameInfo, cardArray, kind, quick=False, absolute=False)
            if weight < 0.95:
                kindValues.append([cardArray, weight, kind])
            else:
                restCardsLength -= len(cardArray)
        for element in kindValues:
                if restCardsLength - len(element[0]) <= 2:
                    return True
    return False

# 输入 cardCombination，牌组
# 输出 True Flase， 该牌组是否还有可能控牌
def canControl(cardCombination, gameInfo):
    controllerCount = 0
    for cardArray in cardCombination:
        kind = getCardKind(cardArray)
        if kind == CardKind.BOMB or kind == CardKind.ROCKET: # 有炸弹、火箭，肯定能控牌
            return True
        if kind in (CardKind.SINGLE, CardKind.PAIR, CardKind.THREE, CardKind.THREE_PLUS1, CardKind.THREE_PLUS2):
            weight = getCardWeight(gameInfo, cardArray, kind, quick=False, absolute=True)
            if weight > 1.0:
                controllerCount += 2
            elif weight >= 0.9:
                controllerCount += 1
            elif kind in (CardKind.PAIR, CardKind.THREE, CardKind.THREE_PLUS1, CardKind.THREE_PLUS2) \
                and getCardClass(cardArray[0]) == CardClass.MIDDLE:
                controllerCount += 0.7

    if controllerCount >= 2:
        return True
    else:
        return False

# 即同牌型分组带牌，装箱
def autoBoxing(kind, cardKindList, gameInfo, normalValues, correctValues, param, quick):
    opponentLength = gameInfo.getOpponentRestCardsLength()
    cardArrayList = cardKindList[:]
    kindValues = []
    if kind in (CardKind.SINGLE, CardKind.PAIR, CardKind.THREE, CardKind.THREE_PLUS1, CardKind.THREE_PLUS2):
        while (len(cardArrayList) > 0):
            keyCardValue = cardArrayList[0][0]
            # 只有大牌能带小牌，中牌自己顾自己
            minValue = getCardWeight(gameInfo, cardArrayList[0], kind, quick)
            maxValue = getCardWeight(gameInfo, cardArrayList[-1], kind, quick)
            #if opponentLength != len(cardArrayList[0]) and len(cardArrayList) >=2 and minValue <= 0.50 and maxValue >= 0.90:
            #TODO 按照牌权来挑选的不利之处是 对不同牌型，可能权重阈值不一样
            if kind == CardKind.SINGLE:
                thresholdValue = 0.9
            elif kind == CardKind.PAIR:
                thresholdValue = 0.8
            else:
                thresholdValue = 0.7
            if opponentLength != len(cardArrayList[0]) and len(cardArrayList) >= 2 and minValue <= 0.50 and maxValue >= thresholdValue:
            #if getCardClass(keyCardValue) <= CardClass.MIDDLE \
            # and getCardClass(cardArray[-1][0]) == CardClass.LARGE:
                if maxValue > 1.0: #绝对控牌，不怕阻拦，所以不需要降权1%
                    normalValues.append([maxValue, cardArrayList[0]]) # 带出去的可能需要降权,不然三带一带不带有可能无所谓
                else:
                    normalValues.append([maxValue * 0.99, cardArrayList[0]])  # 带出去的可能需要降权,不然三带一带不带有可能无所谓
                kindValues.append([kind, minValue, cardArrayList[0]])
                kindValues.append([kind, maxValue, cardArrayList[-1]])
                cardArrayList.pop() # delete the last one
                cardArrayList.pop(0) # delete the first one
            else:
                #value = getCardWeight(gameInfo, cardArray[0], kind, quick)
                # 不带小牌的 大单张对子三带 可用来争夺控牌权，从而校准价值
                #if getCardClass(keyCardValue) == CardClass.LARGE:
                if minValue >= 0.90:
                    correctValues.append([minValue, cardArrayList[0]])
                else:
                    normalValues.append([minValue, cardArrayList[0]])
                kindValues.append([kind, minValue, cardArrayList[0]])
                cardArrayList.pop(0)

    elif kind == CardKind.STRAIGHT or kind == CardKind.PAIRS:
        dictValues = {}
        for element in cardArrayList:
            value = getCardWeight(gameInfo, element, kind, quick)
            kindValues.append([kind, value, element])
            size = len(element)
            if dictValues.get(size) == None:
                dictValues[size] = [value, element]
            elif dictValues[size][0] < 0.99 * value:  # 同长度大的覆盖小的，如果同长度有3个，最大的带小的2个
                dictValues[size] = [value * 0.99, element]  # 覆盖的话需要稍稍降权，避免将到顶的长链子拆开

        for key in dictValues:
            normalValues.append(dictValues[key])

    elif kind == CardKind.BOMB:
        param = param * 2 ** len(cardArrayList)  # ** 比 pow效率更高 炸弹，你值得拥有
        for element in cardArrayList:
            kindValues.append([kind, 1.01, element])
            correctValues.append([1.01, element])

    elif kind == CardKind.ROCKET:
        param = param * 2.01  # 火箭，你值得持有
        correctValues.append([1.02, cardArrayList[0]])
        kindValues.append([kind, 1.02, cardArrayList[0]])

    # 假定飞机无牌能管
    elif kind == CardKind.PLANE_EMPTY or kind == CardKind.PLANE_PLUS1 or kind == CardKind.PLANE_PLUS2:
        normalValues.append([1.0, cardArrayList[-1]])
        for element in cardArrayList:
            kindValues.append([kind, 1.0, element])

    # 假定四代二无牌能管
    elif kind == CardKind.FOUR_PLUS1 or kind == CardKind.FOUR_PLUS2:
        normalValues.append([1.0, cardArrayList[-1]])
        for element in cardArrayList:
            kindValues.append([kind, 1.0, element])

    return param, kindValues

#  判断出牌策略，保守 还是 激进
# 不考虑春天，只有收益即赢牌可能： 激进 > 保守，才会选择激进
# Bug：Radical Strategy Choosen! 0.09 [[5, 5], [7, 8, 9, 10, 11, 12], [12], [20], [30], [40]]
# 输入 cardCombination, 牌组，即玩家当前手牌，其中牌组是排好序了的，小的牌型在前，大的在后
# 输入 quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)
# 输入 gameInfo, 包含以下内容
# 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
# 输入 sortedCards, 已经公开的明牌列表，已经排好序
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
# 返回：True 保守；False 激进
def judgeStratey(cardCombination, quick, gameInfo):
    #视对手剩余手牌数量调整策略？
    if gameInfo.getOpponentRestCardsLength() <= 1:
        LogUtil.Log("Radical Strategy Choosen By getOpponentRestCardsLength", gameInfo.getOpponentRestCardsLength(), cardCombination)
        #print("Radical Strategy Choosen By getOpponentRestCardsLength", gameInfo.getOpponentRestCardsLength(), cardCombination)
        return False

    minBombCardKeyValue = CardValue.Card_Min
    for cardKind in cardCombination:
        if cardKind == [CardValue.Card_B, CardValue.Card_R]:
            return False # 有火箭保驾，当然激进

        # TODO 考虑我方或者对手有多个炸弹的情况？
        if len(cardKind) == 4 and cardKind[0] == cardKind[1] and cardKind[0] == cardKind[2] and cardKind[0] == cardKind[3]:
            # Found Bomb
            minBombCardKeyValue = cardKind[0]

    # 判断对方是否有炸弹火箭
    opponentBombRate = getOpponentRateForBombRocket(gameInfo, minBombCardKeyValue)
    # TODO 风险收益平衡
    bCanControl = canControl(cardCombination, gameInfo)
    if bCanControl == False or opponentBombRate <= 0.0: # 敌人没有炸弹或者自身没有控牌权了，那么激进
        LogUtil.Log("Radical Strategy Choosen By getOpponentRateForBombRocket", opponentBombRate, cardCombination)
        #print("Radical Strategy Choosen By getOpponentRateForBombRocket", opponentBombRate, cardCombination)
        return False
    elif bCanControl == True and opponentBombRate > 0.2: # 能控牌或者炸弹概率>20%，那么保守
        return True
    else:
        # TODO 只有在唯一的小牌会丧失控牌权的情况下，才会选择激进路线
        cardKindsArray = {}
        minRate = 1.2
        minKind = None
        minCardKind = None
        for cardKind in cardCombination:
            kind = getCardKind(cardKind)
            rate = getCardWeight(gameInfo, cardKind, kind, quick=False)
            if rate < minRate:
                minRate = rate
                minKind = kind
                minCardKind = cardKind

            # TODO 有炸弹的情况下，除非为了春天，否则冒什么险
            if kind == CardKind.BOMB:
                return True

            # 但是有火箭的情况下，就可以冒险了，因为火箭最大
            if kind == CardKind.ROCKET:
                return False

            if cardKindsArray.get(kind):
                cardKindsArray[kind].append(cardKind)
            else:
                cardKindsArray[kind] = []
                cardKindsArray[kind].append(cardKind)

        cardArray = cardKindsArray[minKind]
        if len(cardArray) == 1: # 唯一的小牌没有照应
            LogUtil.Log("Radical Strategy Choosen",opponentBombRate, cardCombination)
            #print("Radical Strategy Choosen",opponentBombRate, cardCombination)
            return False
        else: # 唯一的小牌有照应，那就不必冒险了
            return True

# 评估排序，同牌型出最小值 春天/反春天/收牌的情况暂不考虑, 保守打法
# 春天或者激进打法：除掉一个小牌型(控牌指数<0.99),其他的都是大牌的话（概率连乘>0.6?），需要挑最小的大牌来出
# TODO 残局尤其是只有最后两手牌的时候需要考虑防炸弹
# 例如：<class 'list'>: [[5, 5, 5, 5], [7, 7, 7, 12], [20，20]]
# 这种情况下，考虑到对手可能有大的炸弹，应该先出对2
# 输入 cardCombination, 牌组，即玩家当前手牌，其中牌组是排好序了的，小的牌型在前，大的在后
# 输入 quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)

# 下面几个输入 包含在gameInfo中
# 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
# 输入 sortedCards, 已经公开的明牌列表，已经排好序
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
#def sortCardCombinationRadically(sortedCards, cardCombination, quick, role, landlordCardSequence, peasantCardSequence):
def sortCardCombinationRadically(cardCombination, gameInfo, quick):
    if True == judgeStratey(cardCombination, quick, gameInfo): #保守
        return sortCardCombinationConservatively(cardCombination, gameInfo, quick)
    else:
        # TODO 激进打法的实现
        #return sortCardCombinationConservatively(sortedCards, cardCombination, quick)
        #strategyValues = []
        ret = []
        retList = []
        for cardKind in cardCombination:
            kind = getCardKind(cardKind)
            rate = getCardWeight(gameInfo, cardKind, kind, quick=False)
            ret = []
            ret.append(rate)
            ret.append(cardKind)
            retList.append(ret)
        retList.sort(key=lambda comb: comb[0] * 100000 + 50 - comb[1][0], reverse=False)  # 升序，次小的先出；主关键词 牌权逆序，次关键词 牌值顺序
        if len(retList) > 1:
            return retList[1][1]
        else:
            return retList[0][1]


# 评估排序，同牌型出最小值 春天/反春天/收牌的情况暂不考虑, 保守打法
# 对以下因素加权评估：牌型(控牌/非控牌)、牌值(小牌、大牌)、控牌(同牌型的最大牌)
# 控牌牌型：单张、对子、三带、炸弹、火箭
# TODO 出牌顺序：有照应的控牌牌型小牌->无照应的控牌牌型小牌->非控牌牌型小牌->非控牌牌型大牌->控牌牌型大牌
# TODO 残局的时候需要考虑防炸弹
# TODO 控牌的时候需要考虑敌人先管的情况，如下例应先出9为佳
# Bug1 Top: 1 24.01490025 Lead: [7, 7] -> [[5, 6, 7, 8, 9], [7, 7], [9], [20, 20], [40]]
# Bug2 Top: 1 7.290000000000004 Lead: [20] -> [[5, 5], [7, 7], [20]]
# Bug3:
# Top: 1 7.144929000000002 Lead: [9] -> [[9], [12], [14], [20]]
#Peasant Played: [9]
#Now Your rest Cards are: [30]
# 输入 cardCombination, 牌组，即玩家当前手牌，其中牌组是排好序了的，小的牌型在前，大的在后
# 输入 quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)
# 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民

# 下面三个输入 包含在gameInfo中
# 输入 sortedCards, 已经公开的明牌列表，已经排好序
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
#def sortCardCombinationConservatively(sortedCards, cardCombination, quick, role, landlordCardSequence, peasantCardSequence):
def sortCardCombinationConservatively(cardCombination, gameInfo, quick):
    cardOrderRet = []  # 控牌先出 TODO 大牌越多的牌型越好
    cardKindsArray = {}
    # 之前cardCombination已经排好序了，所以此处不再排序
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        if cardKindsArray.get(kind):
            cardKindsArray[kind].append(cardKind)
        else:
            cardKindsArray[kind] = []
            cardKindsArray[kind].append(cardKind)

    for kind, cardKindArray in cardKindsArray.items():
        minCardKind = cardKindArray[0]
        kindRate = CardKindOrder[kind]
        keyCardValue = minCardKind[0]
        keyCardRate = CardValueOrder[keyCardValue]
        rate = kindRate * keyCardRate
        if kind == CardKind.ROCKET:
            cardOrderRet.append([100 * 1.02 * rate, minCardKind])
        elif kind == CardKind.BOMB:
            cardOrderRet.append([100 * 1.01 * rate, minCardKind])
        elif kind == CardKind.PLANE_EMPTY or kind == CardKind.PLANE_PLUS1 or kind == CardKind.PLANE_PLUS2:
            cardOrderRet.append([100 * 1.00 * rate, minCardKind])
        else:
            if len(cardKindArray) == 1:
                bottomValue = getCardWeight(gameInfo, minCardKind, kind, quick)
                cardOrderRet.append([100 * bottomValue * rate, minCardKind])
            else:
                topValue = getCardWeight(gameInfo, cardKindArray[-1], kind, quick)
                cardOrderRet.append([95 * topValue * rate, minCardKind])

    opponentRestCardslength = gameInfo.getOpponentRestCardsLength()
    cardOrderRet.sort(key=lambda comb: comb[0], reverse=True)  # 降序，值大的先出

    additionOrderRet = []
    if opponentRestCardslength == 1: #单报，则优先出非单张，大单张先出
        start = len(cardOrderRet) - 1
        for key in range(start, -1, -1):  # 逆序遍历
            cardOrder = cardOrderRet[key]
            if isSingle(cardOrder[1]): #单张优先级沉底
                cardOrderRet.pop(key) # remove it
                additionOrderRet.append(cardOrder)

    elif opponentRestCardslength == 2: #双报，则优先出非对子
        start = len(cardOrderRet) - 1
        for key in range(start, -1, -1): #逆序遍历
            cardOrder = cardOrderRet[key]
            if isPair(cardOrder[1]): #对子优先级沉底
                cardOrderRet.pop(key) # remove it
                additionOrderRet.append(cardOrder)

    cardOrderRet += additionOrderRet
    return cardOrderRet[0][1]


# 根据牌组，优化牌型出牌顺序，从而决定出牌牌型
# 输入 cardCombinations, 玩家手牌可能的牌组列表，其中牌组是排好序了的，小的牌型在前，大的在后
# 输入 quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)

# 下面几个输入 包含在gameInfo中
# 输入 role, 玩家角色，对应CardRole枚举：有效值 CardRole.LANDLORD地主，CardRole.PEASANT农民
# 输入 sortedCards, 已经排好序的公开的明牌列表，包括自己的手牌
# 输入 landlordCardSequence， 地主截止到目前各轮的出牌序列，是一个牌型列表，例如[[3,4,5,6,7],[],[9,9,10,10,11,11],[10]]
# 输入 peasantCardSequence， 农民截止到目前各轮的出牌序列，是一个牌型列表，例如[[10,11,12,13,14],[3,3],[]]
# 返回二级列表，即列表的元素为一个列表，0位置为首出牌型，1为原始牌力， 2为综合牌力，3:为牌组：
#[[9], 0.495, 206.48844810000003, [8, 9, 10, 11, 12], [9], [12], [13, 13, 13, 14, 14, 14, 5, 5, 7, 7], [20], [30, 40]]
#def sortCardCombinations(sortedCards, cardCombinations, quick, role, landlordCardSequence, peasantCardSequence):
def sortCardCombinations(cardCombinations, gameInfo, quick):
    ret = []
    for valuedCardCombination in cardCombinations:
        cardCombination = valuedCardCombination[3:]
        # 根据粗选的打法规则，尝试激进打法 对手只有1张牌，必须采取激进打法
        if valuedCardCombination[0] > 0.95 or gameInfo.getOpponentRestCardsLength() <= 1:
            # 去除打法、Value标注
            order = sortCardCombinationRadically(cardCombination, gameInfo, quick)
        else:
            order = sortCardCombinationConservatively(cardCombination, gameInfo, quick) #去除打法、Value标注
        ret.append([order] + valuedCardCombination)
    return ret

def orderCardCombinationConservatively(cardCombination, gameInfo, quick = True, lead = False):
    if gameInfo.getCurrentRole() == CardRole.PEASANT_UP:
        valuedComb = valuationCardCombination(cardCombination, gameInfo, quick, lead)
        if valuedComb[1] >= 90: #有赢牌的可能
            return orderCardCombinationConservativelyAsLandlord(cardCombination, gameInfo, quick, lead)

        # 否则，打辅助，打中牌
        # 之前cardCombination已经排好序了，所以此处不再排序
        cardOrders = []
        for cardArray in cardCombination:
            kind = getCardKind(cardArray)
            weight = getCardWeight(gameInfo, cardArray, kind, quick)
            cardOrders.append([cardArray, kind, weight])

        # 先选择牌型，优先打我方优势牌型，忌出小单张
        cardOrders.sort(key=lambda order: getDefenderOrderRank(order[0], order[1], order[2], cardCombination, gameInfo), reverse=True)  # 降序，值大先出

        orderRet = []
        for value in cardOrders:
            orderRet.append(value[0])
        leadCardArray = adjustOrder(orderRet, gameInfo, bRadical=False)
        valuedComb.insert(0, leadCardArray)
        return valuedComb
    else:
        return orderCardCombinationConservativelyAsLandlord(cardCombination, gameInfo, quick, lead)

# 保守打法计算牌组价值并从牌组出牌，并从最优牌组中选择要出的牌型（首牌、引牌）
# 对以下因素加权评估：牌型(控牌/非控牌)、牌值(小牌、大牌)、控牌(同牌型的最大牌)
# 输入gameInfo,包含现在的所有牌局信息，参见DouDiZhu3的类定义
# 输入sortedCards, 已经公开的明牌列表，已经排好序
# cardCombination, 牌组列表，其中牌组是排好序了的，小的牌型在前，大的在后
# quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)
# lead, True代表已经掌握控牌权，会带出一个控牌权最小的牌型
# 返回列表，0位置为要出的牌型，1位置为原始估值(扣除校正因素)，2位置为估值 3:为牌组，示例：
#<class 'list'>: [[7, 7, 8, 8, 9, 9], 100, 125.99999999999999, [6, 6, 6, 5], [7, 7, 8, 8, 9, 9], [10, 10, 10, 10, 11, 14], [12, 12], [30, 40]]

# TODO 保守打法策略优先级：如有把握则控牌，没有则跑牌；
# TODO 保守打法牌型优先级：按照非控牌牌型关键牌(牌型首牌)，控牌牌型按照牌权，先出小牌，然后再依次出中牌/大牌/炸弹
# TODO 对手最近没有管小牌或者不能管的牌型->绝对把握能控牌(不会被对方大牌挡住，综合实力大者优先)->有把握能控牌
# TODO ->对手没出过的牌型->没人出过的新牌型->综合实力相对大的牌型->包含小牌较多的牌型->最小牌值牌型；
# TODO 对于大牌，非控牌牌型大牌->控牌牌型大牌
# 控牌牌型：单张、对子、三带、炸弹、火箭
# TODO 出牌顺序：有照应的控牌牌型小牌->无照应的控牌牌型小牌->非控牌牌型小牌->非控牌牌型大牌->控牌牌型大牌
# TODO 残局的时候需要考虑防炸弹
# TODO 控牌的时候需要考虑敌人先管的情况，如下例应先出9为佳
# Bug1 Top: 1 24.01490025 Lead: [7, 7] -> [[5, 6, 7, 8, 9], [7, 7], [9], [20, 20], [40]]
# Bug2 Top: 1 7.290000000000004 Lead: [20] -> [[5, 5], [7, 7], [20]]
# Bug3:
# Top: 1 7.144929000000002 Lead: [9] -> [[9], [12], [14], [20]]
#Peasant Played: [9]
#Now Your rest Cards are: [30]
#Bug4: Top: 1 0.06350400000000002 0.0 First: [13, 13] -> [[7], [9], [10], [13, 13], [14, 14]]
def orderCardCombinationConservativelyAsLandlord(cardCombination, gameInfo, quick = True, lead = False):
    valuedComb = valuationCardCombination(cardCombination, gameInfo, quick, lead)

    cardOrderRet = []
    cardKindsArray = {}
    # 之前cardCombination已经排好序了，所以此处不再排序
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        if cardKindsArray.get(kind):
            cardKindsArray[kind].append(cardKind)
        else:
            cardKindsArray[kind] = []
            cardKindsArray[kind].append(cardKind)

    # 先做控牌判断,
    opponentRestCardslength = gameInfo.getOpponentRestCardsLength()
    copyCardKindsArray = cardKindsArray.copy() #浅拷贝
    for kind, cardKindArray in copyCardKindsArray.items():
        minCardKind = cardKindArray[0]
        keyCardValue = minCardKind[0]
        keyCardClass = getCardClass(keyCardValue)

        # 单张只有大牌能带小中牌
        if kind == CardKind.SINGLE and opponentRestCardslength > 1 and keyCardClass <= CardClass.MIDDLE:
            lastDuckedCardKind = gameInfo.getOpponentLastDuckedCardKind(kind)
            if len(lastDuckedCardKind) > 0 and lastDuckedCardKind[0] <= keyCardValue:
                #LogUtil.Log("getOpponentLastDuckedCardKind", minCardKind, lastDuckedCardKind)
                cardOrderRet.append([1.0, minCardKind]) #排名靠前，妥妥的
                cardKindsArray.pop(kind)
            else:
                topValue = getCardWeight(gameInfo, cardKindArray[-1], kind, quick)
                cardOrderRet.append([topValue, minCardKind])
                cardKindsArray.pop(kind)

        # 对子/三代 中大牌可带小牌
        elif kind == CardKind.PAIR or kind == CardKind.THREE or  \
                        kind == CardKind.THREE_PLUS1 or kind == CardKind.THREE_PLUS2:
            lastDuckedCardKind = gameInfo.getOpponentLastDuckedCardKind(kind)
            if keyCardClass == CardClass.SMALL and len(lastDuckedCardKind) > 0 and lastDuckedCardKind[0] <= keyCardValue:
                #LogUtil.Log("getOpponentLastDuckedCardKind", minCardKind, lastDuckedCardKind)
                cardOrderRet.append([1.0, minCardKind]) #排名靠前，妥妥的
                cardKindsArray.pop(kind)

            elif opponentRestCardslength != len(minCardKind) and keyCardClass == CardClass.SMALL \
                    and getCardClass(cardKindArray[-1][0]) > CardClass.SMALL:
                topValue = getCardWeight(gameInfo, cardKindArray[-1], kind, quick)
                cardOrderRet.append([topValue, minCardKind])
                cardKindsArray.pop(kind)

    cardOrderRet.sort(key=lambda comb: comb[0], reverse=True)  # 降序，值大的先出
    # 根据对手剩余的牌张数来做调整
    opponentRestCardslength = gameInfo.getOpponentRestCardsLength()
    additionOrderRet = []
    if opponentRestCardslength == 1 and gameInfo.getCurrentRole() != CardRole.PEASANT_DOWN : #单报，则优先出非单张，大单张先出
        start = len(cardOrderRet) - 1
        for key in range(start, -1, -1):  # 逆序遍历
            cardOrder = cardOrderRet[key]
            if isSingle(cardOrder[1]): #单张优先级沉底
                cardOrderRet.pop(key) # remove it
                additionOrderRet.append(cardOrder)

    elif opponentRestCardslength == 2 and gameInfo.getCurrentRole() != CardRole.PEASANT_DOWN : #双报，则优先出非对子
        start = len(cardOrderRet) - 1
        for key in range(start, -1, -1):  # 逆序遍历
            cardOrder = cardOrderRet[key]
            if isPair(cardOrder[1]): #对子优先级沉底
                cardOrderRet.pop(key) # remove it
                additionOrderRet.append(cardOrder)

    cardOrderRet += additionOrderRet
    #if len(cardOrderRet) > 0 and cardOrderRet[0][0] >= 90: #有牌型有把握控牌
    # 有牌型有绝对把握控牌
    for element in cardOrderRet:
        if element[0] >= 1.0:
            valuedComb.insert(0, element[1])
            return valuedComb

    # 再把其他牌型的最小项加进来
    for kind, cardKindArray in cardKindsArray.items():
        topValue = getCardWeight(gameInfo, cardKindArray[-1], kind, quick)
        additionOrderRet.append([topValue, cardKindArray[0]])

    # TODO 将来需要根据算牌猜牌引擎来调整
    bCanRush = canRush(cardCombination, gameInfo)
    #LogUtil.Log("canRush:", bCanRush, cardCombination)
    if bCanRush == False and canControl(cardCombination, gameInfo) and len(cardOrderRet) > 0: #还能控牌
        cardOrderRet.sort(key=lambda comb: comb[0], reverse=True)  # 降序，牌权大的先出
    else: # 以跑牌为主
        cardOrderRet += additionOrderRet
        # 降序，长牌先出，控牌力量强的牌型先出
        #ret = weight * 1000 - 2 * len(cardArray) + cardArray[0] + 2000 - kind
        cardOrderRet.sort(key=lambda comb: getLandlordOrderRank(comb[0], comb[1]), reverse=False)
        #cardOrderRet.sort(key=lambda comb: comb[0] * (len(comb[1]) + (CardValue.Card_2 - comb[1][0])/10), reverse=True)
        #cardOrderRet.sort(key=lambda comb: getDefenderOrderRank(comb[1], getCardKind(comb[1]), comb[0], cardCombination, gameInfo), reverse=True)

    orderRet = []
    for element in cardOrderRet: #提取出牌型
        orderRet.append(element[1])
    leadCardArray = adjustOrder(orderRet, gameInfo, bRadical=False)
    valuedComb.insert(0, leadCardArray)
    return valuedComb

#值小的先出
def getLandlordOrderRank(weight, cardArray):
    kind = getCardKind(cardArray)
    #ret = weight * 1000 - 2 * len(cardArray) + cardArray[0] + 2000 - kind
    ret = weight * 100 - 0.2 * len(cardArray) + cardArray[0] + 2000 - kind
    LogUtil.Log("getLandlordOrderRank", ret, cardArray, weight, kind)
    return ret

#值小的先出
def getRadicalOrderRank(weight, cardArray, kind):
    ret = weight * 1000 - 2 * len(cardArray) + cardArray[0] + 2000 - kind
    LogUtil.Log("getRadicalOrderRank", ret, cardArray, weight, kind)
    return ret

# 激进打法计算牌组价值从牌组出牌，并从最优牌组中选择要出的牌型（首牌、引牌）
# TODO 激进打法牌型优先级：总是出次小的牌型
# 输入gameInfo,包含现在的所有牌局信息，参见DouDiZhu3的类定义
# 输入sortedCards, 已经公开的明牌列表，已经排好序
# cardCombination, 牌组列表，其中牌组是排好序了的，小的牌型在前，大的在后
# quick TRUE通过公式来估算牌型大小，FALSE随机抽牌的方式估算牌型大小(计算量可能较大)
# lead, True代表已经掌握控牌权，会带出一个控牌权最小的牌型
# 返回列表，0位置为要出的牌型，1位置为原始估值(扣除校正因素)，2位置为估值 3位置为奖励参数, 4:为牌组，示例：
#<class 'list'>: [[7, 7, 8, 8, 9, 9], 100, 125.99999999999999, [6, 6, 6, 5], [7, 7, 8, 8, 9, 9], [10, 10, 10, 10, 11, 14], [12, 12], [30, 40]]
def orderCardCombinationRadically(cardCombination, gameInfo, quick = True, lead = True):
    valuedComb = valuationCardCombination(cardCombination, gameInfo, quick, lead)
    retList = []
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        rate = getCardWeight(gameInfo, cardKind, kind, quick=False, absolute=True)
        retList.append([rate, cardKind, kind])
    # 升序，小的排在前面，大的排在后面；主关键词 牌权顺序，次关键词 牌值顺序，类型顺序
    #retList.sort(key=lambda comb: comb[0] * 1000 - 2 * len(comb[1]) + comb[1][0] + 2000 - kind, reverse=False)
    retList.sort(key=lambda comb: getRadicalOrderRank(comb[0], comb[1], comb[2]), reverse=False)

    cardOrderRet = []
    #LogUtil.Log("orderCardCombinationRadically", cardCombination)
    #LogUtil.Log("orderCardCombinationRadically", retList)
    for value in retList:
        cardOrderRet.append(value[1])
    leadCardArray = adjustOrder(cardOrderRet, gameInfo, bRadical=True)
    valuedComb.insert(0, leadCardArray)
    return valuedComb

# 从牌组列中选择要出的牌型（首牌、引牌）
# 输入sortedCards, 已经公开的明牌列表，已经排好序
# 输入gameInfo,包含现在的所有牌局信息，参见DouDiZhu3的类定义
# cardCombinations, 牌组列表，其中牌组是排好序了的，小的牌型在前，大的在后
# lead, True代表已经掌握控牌权，会带出一个控牌权最小的牌型
# 返回二级列表，0位置为要出的牌型，1位置为原始估值(扣除校正因素)，2位置为估值 3位置为奖励参数，4:为牌组，元素示例：
#<class 'list'>: [[7, 7, 8, 8, 9, 9], 100, 125.99999999999999, 2.01, [6, 6, 6, 5], [7, 7, 8, 8, 9, 9], [10, 10, 10, 10, 11, 14], [12, 12], [30, 40]]
def orderCardCombinations(cardCombinations, gameInfo, lead=False):
    quickRet = []
    '''
    lead = False
    if gameInfo.getOpponentRestCardsLength() == 1:
        lead = True
    '''

    for cardCombination in cardCombinations:
        valuedComb = orderCardCombinationConservatively(cardCombination, gameInfo, quick=True, lead=lead)
        quickRet.append(valuedComb)
    #quickRet.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    quickRet.sort(key= lambda comb : comb[2], reverse=True) #降序，只对次位Value值排序
    quickRet = quickRet[0:ConstCard.TOP_BY_COUNT] #粗选N个
    #return quickRet

    slowRet = []
    for valuedComb in quickRet:
        cardCombination = valuedComb[4:]
        tempValuedComb = orderCardCombinationConservatively(cardCombination, gameInfo, False, lead)
        slowRet.append(tempValuedComb)
    # ret.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    # 降序，只对次位Value值排序,次级关键词为牌组长度
    slowRet.sort(key= lambda comb : comb[2] * 1000 + 20 - len(comb[4:]), reverse=True)
    slowRet = slowRet[0:ConstCard.TOP_BY_COUNT]

    retList = []
    for valuedComb in slowRet:
        # 根据粗选的打法规则，尝试激进打法 对手只有1张牌，必须采取激进打法
        order = []
        if valuedComb[1] > 0.95 or gameInfo.getOpponentRestCardsLength() <= 1:
            # 去除打法、Value标注
            if False == judgeStratey(valuedComb[4:], False, gameInfo): # 保守
                order = orderCardCombinationRadically(valuedComb[4:], gameInfo, quick=False, lead=True)
            else:
                order = valuedComb
        else:
            order = valuedComb
        retList.append(order)
    # ret.sort(reverse=True)  # 降序，排序导致三带1，单张较大的排在前面
    # 降序，只对Value值排序,次级关键词为牌组长度, 三级关键词为出牌的keyCardValue小的先出
    retList.sort(key=lambda comb : comb[2] * 1000 + 20 - 1 * len(comb[4:]) + CardValue.Card_R - comb[0][0], reverse=True)
    ret = retList[0:ConstCard.TOP_BY_COUNT]
    return ret

# 输入 cardOrderRet 列表，元素为cardArray牌型
# 输出 返回调整后的应出的cardArray
def adjustOrder(cardOrderRet, gameInfo, bRadical = True):
    additionRet = []
    opponentRestCardLength = gameInfo.getOpponentRestCardsLength()
    currentRole = gameInfo.getCurrentRole()
    if currentRole != CardRole.PEASANT_DOWN: # 地主和顶家
        if opponentRestCardLength <= 6:
            for cardArray in cardOrderRet[:]:
                kind = getCardKind(cardArray)
                weight = getCardWeight(gameInfo, cardArray, kind, quick=False, absolute=False)
                if len(cardArray) == opponentRestCardLength and weight < 1.0:
                   cardOrderRet.remove(cardArray)
                   additionRet.append(cardArray)
        '''
        if opponentRestCardLength == 1:
            for cardArray in cardOrderRet:
                if isSingle(cardArray):
                   cardOrderRet.remove(cardArray)
                   additionRet.append(cardArray)
        elif opponentRestCardLength == 2:
            for cardArray in cardOrderRet:
                if isPair(cardArray):
                   cardOrderRet.remove(cardArray)
                   additionRet.append(cardArray)
        '''
    # TODO 在队友只剩1-2张牌的时候，打配合
    #if currentRole != CardRole.LANDLORD: # 农民

    if bRadical == False:
        for cardArray in cardOrderRet[:]:
            kind = getCardKind(cardArray)
            weight = getCardWeight(gameInfo, cardArray, kind, quick=False, absolute=True)
            # 绝对控牌大牌,保守打法不应先出
            if weight > 1.0 and kind in (CardKind.SINGLE, CardKind.PAIR, CardKind.THREE, CardKind.THREE_PLUS1, CardKind.THREE_PLUS2):
                cardOrderRet.remove(cardArray)
                additionRet.append(cardArray)

        if len(cardOrderRet) == 0:
            return additionRet[0]
        else:
            return cardOrderRet[0]

    #添加出的牌
    #print(cardOrderRet)
    if len(cardOrderRet) == 0:
        return additionRet[-1]
    elif len(cardOrderRet) == 1:
        return cardOrderRet[0]
    elif len(additionRet) > 0:
        return cardOrderRet[0]
    elif len(cardOrderRet) >= 2:
        return cardOrderRet[1]  # 次小的牌

# 顶家牌型出牌顺序，优先打对子，尽量少放单张, 返回值大优先出
def getDefenderOrderRank(cardArray, kind, weight, cardCombination, gameInfo):
    keyCardValue = cardArray[0]
    keyCardClass = getCardClass(cardArray[0])
    duckedCardArray = gameInfo.getOpponentLastDuckedCardKind(kind)
    kindParam = len(cardArray) #越长越优先
    if kind in (CardKind.BOMB, CardKind.ROCKET):
        kindParam = 0
    #elif duckedCardArray and getCardClass(duckedCardArray):
    #    kindParam = 0.5
    elif kind == CardKind.PAIR:
        kindParam = 19
    #kindParam = kind

    ret = 0
    if weight >= 0.9:
        ret = 0 - weight
    if kind == CardKind.SINGLE:
        ret = OrderCardRank[keyCardValue]
    else:
        ret = kindParam * (CardValue.Card_R - keyCardValue) * (1.2 - weight)
    LogUtil.Log("getDefenderOrderRank:", ret, cardArray, "kindParam=",kindParam, "weight=",weight)
    return ret