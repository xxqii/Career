# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-11-23

#TODO 目前问题1：引牌需要判断我方牌型综合实力 2：农民中对容易Follow队友中对

import random
import datetime
import traceback

from Util.CardUtil import *
from Util.LogUtil import *
from AI3Players import *
from DouDiZhu3 import *

#三人斗地主 人类 VS AI

# 牌局结束
def gameOver(winnerRole):
    if winnerRole == CardRole.LANDLORD:
        print("Landlord won")
    else:
        print("Peasant won")

# 人类出牌
def humanPlayCards(role, game):
    #if game.lastCardKind == []: #引牌
    #else: # 管牌
    ret = []
    print("Now Your rest Cards are:", game.getRestCardsByRole(role))
    while(True):
        rawCardKind = input("Please Input cards you want to play, e.g 3,3,3,4:")
        if rawCardKind:
            #cards = [int(x.strip()) for x in rawCardKind.split(',')]
            cards = []
            for x in rawCardKind.split(','):
                try:
                    cards.append(int(x.strip()))
                except:
                    #traceback.print_exc()
                    continue

            cardKind = generateCardKindFromCards(cards)
            if cardKind != None and isSubList(cardKind, game.getRestCardsByRole(role)):
                kind = getCardKind(cardKind)
                if kind == CardKind.INVALID: #输入牌型不正确
                    print("INVALID CardKind Input Cards:", cards)
                # 还需要判断是否能管牌
                elif game.getLastCardArray() == []: # 首牌引牌
                    if kind == CardKind.DUCK:
                        continue
                    else:
                        ret = cardKind
                        break
                elif canCardKindCover(cardKind, game.getLastCardArray()): #管牌，需要比牌
                    ret = cardKind
                    break
                else:
                    print("INVALID Input Cards:", cards, "NOT Larger than:", game.getLastCardArray())
            else:
                print("INVALID Input Cards:", cards)
        else:
            # 首牌、引牌不允许让牌
            if game.getLastCardArray() == []:
                pass
            else:
                ret = []  # 让牌，出空牌
                break
    return ret


LogUtil.logOutEnabled()

# 发牌
cards = initCardsFor3Players()
landlord_cards = cards[0] # 地主20张牌
down_peasant_cards = cards[1] # 下家农民剩下的17张牌
up_peasant_cards = cards[2] # 上家农民剩下的17张牌

# 选择身份
order = input("Which identity do you want? Down Peasant is 1, Up Peasant is 2, Else for Landlord:")
humanRole = CardRole.INVALID
if order == "1":
    humanRole = CardRole.PEASANT_DOWN
elif order == "2":
    humanRole = CardRole.PEASANT_UP
else:
    humanRole = CardRole.LANDLORD

'''
landlord_cards =  [3, 3, 3, 4, 5, 5, 6, 6, 8, 8, 10, 10, 11, 11, 11, 12, 14, 14, 20, 40]
down_peasant_cards =  [3, 4, 6, 7, 7, 7, 7, 9, 9, 10, 12, 12, 13, 13, 13, 14, 20]
up_peasant_cards =  [4, 4, 5, 5, 6, 8, 8, 9, 9, 10, 11, 12, 13, 14, 20, 20, 30]
'''

''' #测试顶牌
landlord_cards =  [3, 4, 5, 6, 6, 6, 7, 8, 8, 8, 9, 9, 11, 12, 12, 12, 13, 14, 20, 20]
down_peasant_cards =  [4, 6, 7, 8, 9, 9, 11, 11, 11, 13, 13, 13, 14, 14, 20, 20, 30]
up_peasant_cards =  [3, 3, 3, 4, 4, 5, 5, 5, 7, 7, 10, 10, 10, 10, 12, 14, 40]
'''

''' #测试Follow Card
landlord_cards =  [3, 4, 5, 5, 6, 6, 8, 11, 12, 12, 12, 12, 13, 13, 14, 14, 20, 20, 30, 40]
down_peasant_cards =  [3, 4, 4, 6, 7, 7, 9, 9, 9, 10, 10, 10, 10, 11, 11, 13, 20]
up_peasant_cards =  [3, 3, 4, 5, 5, 6, 7, 7, 8, 8, 8, 9, 11, 13, 14, 14, 20]
'''

'''
#测试Follow Card
landlord_cards =  [3, 4, 4, 5, 8, 8, 9, 10, 10, 11, 11, 11, 12, 12, 13, 14, 14, 20, 20, 40]
down_peasant_cards =  [3, 4, 4, 5, 5, 5, 6, 6, 7, 7, 7, 8, 9, 12, 13, 14, 20]
up_peasant_cards =  [3, 3, 6, 6, 7, 8, 9, 9, 10, 10, 11, 12, 13, 13, 14, 20, 30]
'''

'''
# 测试管牌
landlord_cards =  [3, 3, 3, 4, 4, 4, 5, 6, 6, 6, 6, 7, 7, 8, 9, 10, 10, 11, 11, 30]
down_peasant_cards =  [3, 4, 5, 5, 7, 8, 9, 10, 11, 11, 12, 13, 13, 14, 14, 20, 20]
up_peasant_cards =  [5, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 13, 14, 14, 20, 20, 40]
'''

'''
#测试配合，最后应该用王炸炸对2
landlord_cards =  [3, 3, 4, 5, 6, 6, 7, 8, 8, 8, 9, 9, 9, 10, 11, 11, 11, 14, 20, 20]
down_peasant_cards =  [3, 3, 4, 4, 5, 5, 6, 7, 8, 9, 10, 10, 12, 12, 13, 13, 20]
up_peasant_cards =  [4, 5, 6, 7, 7, 10, 11, 12, 12, 13, 13, 14, 14, 14, 20, 30, 40]
'''

'''#测试配合
landlord_cards =  [4, 5, 5, 6, 6, 6, 7, 7, 9, 9, 10, 11, 11, 12, 12, 14, 14, 20, 20, 30]
down_peasant_cards =  [3, 3, 3, 4, 5, 6, 8, 9, 9, 10, 11, 12, 13, 14, 20, 20, 40]
up_peasant_cards =  [3, 4, 4, 5, 7, 7, 8, 8, 8, 10, 10, 11, 12, 13, 13, 13, 14]
'''

'''
#测试地主单张时是否出小牌
landlord_cards =  [3, 3, 4, 4, 5, 5, 6, 7, 7, 7, 8, 8, 9, 10, 12, 12, 13, 14, 20, 20]
down_peasant_cards =  [3, 4, 4, 5, 6, 8, 8, 9, 10, 10, 11, 13, 13, 14, 20, 30, 40]
up_peasant_cards =  [3, 5, 6, 6, 7, 9, 9, 10, 11, 11, 11, 12, 12, 13, 14, 14, 20]
'''

'''
#测试管牌，为什么不用2来顶牌，而是用中牌？
landlord_cards =  [4, 5, 5, 5, 6, 6, 6, 7, 7, 8, 9, 9, 11, 12, 13, 13, 14, 14, 20, 40]
down_peasant_cards =  [3, 3, 4, 4, 7, 8, 9, 10, 10, 11, 11, 12, 14, 20, 20, 20, 30]
up_peasant_cards =  [3, 3, 4, 5, 6, 7, 8, 8, 9, 10, 10, 11, 12, 12, 13, 13, 14]
'''

'''
# 三带一就可以打赢
landlord_cards =  [3, 4, 4, 4, 5, 6, 7, 8, 8, 10, 10, 10, 11, 13, 14, 14, 14, 14, 20, 20]
down_peasant_cards =  [4, 5, 5, 5, 6, 6, 7, 7, 7, 9, 10, 11, 11, 11, 12, 20, 30]
up_peasant_cards =  [3, 3, 3, 6, 8, 8, 9, 9, 9, 12, 12, 12, 13, 13, 13, 20, 40]
'''

'''
#测试打辅助， Follow不出小对
landlord_cards =  [3, 4, 4, 5, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 14, 20, 30, 40]
down_peasant_cards =  [3, 3, 4, 6, 6, 8, 8, 10, 10, 11, 11, 13, 13, 14, 14, 20, 20]
up_peasant_cards =  [3, 4, 5, 5, 5, 6, 6, 7, 7, 7, 9, 9, 12, 12, 13, 14, 20]
'''

'''
#测试配合，王炸不轻拆
landlord_cards =  [3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 9, 11, 11, 11, 11, 12, 12, 14, 20, 20]
down_peasant_cards =  [4, 4, 5, 6, 6, 7, 7, 8, 9, 10, 10, 12, 13, 13, 13, 30, 40]
up_peasant_cards =  [3, 3, 3, 5, 8, 8, 9, 9, 10, 10, 12, 13, 14, 14, 14, 20, 20]
'''

''' #不会配合
landlord_cards =  [4, 4, 5, 6, 6, 8, 9, 9, 10, 10, 11, 12, 12, 12, 13, 13, 14, 14, 20, 20]
down_peasant_cards =  [3, 3, 3, 5, 5, 5, 7, 7, 8, 8, 10, 10, 11, 12, 13, 20, 40]
up_peasant_cards =  [3, 4, 4, 6, 6, 7, 7, 8, 9, 9, 11, 11, 13, 14, 14, 20, 30]
'''

''' #炸弹应该怎么用
landlord_cards =  [3, 3, 4, 6, 7, 8, 11, 11, 11, 12, 12, 12, 12, 13, 14, 14, 14, 14, 20, 20]
down_peasant_cards =  [3, 4, 5, 5, 5, 5, 6, 6, 8, 8, 9, 10, 10, 13, 13, 20, 20]
up_peasant_cards =  [3, 4, 4, 6, 7, 7, 7, 8, 9, 9, 9, 10, 10, 11, 13, 30, 40]
'''

'''
landlord_cards =  [3, 4, 4, 5, 5, 6, 6, 8, 9, 10, 10, 11, 12, 12, 13, 13, 14, 14, 30, 40]
down_peasant_cards =  [3, 4, 5, 6, 6, 7, 7, 8, 9, 9, 9, 10, 11, 11, 11, 14, 20]
up_peasant_cards =  [3, 3, 4, 5, 7, 7, 8, 8, 10, 12, 12, 13, 13, 14, 20, 20, 20]
'''

'''
landlord_cards =  [3, 3, 3, 7, 8, 8, 9, 10, 10, 11, 11, 13, 13, 13, 13, 14, 14, 20, 30, 40]
down_peasant_cards =  [3, 4, 4, 4, 5, 5, 6, 6, 7, 9, 10, 10, 11, 12, 12, 14, 20]
up_peasant_cards =  [4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 11, 12, 12, 14, 20, 20]
'''
'''
#引牌在控牌把握不大时，要以走牌为主，例如先走小的顺子连对三带一
landlord_cards =  [3, 3, 6, 6, 7, 7, 8, 8, 8, 9, 10, 11, 11, 12, 12, 13, 13, 20, 20, 40]
down_peasant_cards =  [4, 5, 5, 5, 6, 7, 8, 9, 10, 10, 11, 12, 13, 14, 14, 20, 30]
up_peasant_cards =  [3, 3, 4, 4, 4, 5, 6, 7, 9, 9, 10, 11, 12, 13, 14, 14, 20]
'''

''' #开始做推理
landlord_cards =  [3, 4, 5, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 11, 12, 13, 14, 20, 20]
down_peasant_cards =  [3, 4, 4, 5, 5, 6, 8, 10, 12, 12, 12, 13, 13, 14, 20, 30, 40]
up_peasant_cards =  [3, 3, 4, 5, 6, 6, 7, 7, 8, 9, 9, 10, 11, 13, 14, 14, 20]
'''

''' #地主AI能否打赢
landlord_cards =  [3, 3, 4, 4, 4, 6, 7, 7, 7, 8, 8, 8, 8, 9, 10, 11, 11, 12, 13, 20]
down_peasant_cards =  [3, 5, 6, 9, 9, 9, 10, 10, 11, 12, 12, 12, 13, 14, 14, 14, 20]
up_peasant_cards =  [3, 4, 5, 5, 5, 6, 6, 7, 10, 11, 13, 13, 14, 20, 20, 30, 40]
'''
'''
#TODO 即使有炸弹概率>20%，但该冲还得冲， 这里头有一个 风险与收益的平衡
landlord_cards =  [3, 3, 4, 5, 5, 5, 6, 8, 8, 9, 9, 11, 11, 12, 12, 13, 14, 20, 20, 30]
down_peasant_cards =  [4, 5, 6, 6, 6, 7, 7, 7, 7, 8, 8, 10, 11, 12, 13, 14, 20]
up_peasant_cards =  [3, 3, 4, 4, 9, 9, 10, 10, 10, 11, 12, 13, 13, 14, 14, 20, 40]
'''
'''
landlord_cards =  [3, 5, 5, 5, 6, 7, 7, 9, 9, 9, 10, 12, 12, 12, 13, 13, 13, 14, 20, 30]
down_peasant_cards =  [3, 3, 4, 4, 4, 6, 7, 8, 8, 9, 10, 10, 10, 11, 13, 20, 40]
up_peasant_cards =  [3, 4, 5, 6, 6, 7, 8, 8, 11, 11, 11, 12, 14, 14, 14, 20, 20]
'''

''' #牌序
landlord_cards =  [3, 3, 4, 4, 5, 5, 6, 7, 9, 9, 9, 10, 10, 11, 11, 11, 13, 13, 20, 30]
down_peasant_cards =  [4, 5, 6, 6, 7, 7, 8, 9, 10, 10, 11, 12, 12, 13, 14, 20, 20]
up_peasant_cards =  [3, 3, 4, 5, 6, 7, 8, 8, 8, 12, 12, 13, 14, 14, 14, 20, 40]
'''

'''
Top: 1 102.0 Guard: [14, 14] -> [[8, 8], [11, 11, 11, 12], [20]]
Top: 2 90.9 Guard: [8, 8] -> [[11, 11, 11, 12], [14, 14], [20]]
Top: 1 101.0 Lead: [8, 8] -> [[8, 8], [11, 11, 11, 12], [20]]
Top: 2 86.64500000000001 Lead: [11, 11, 11, 8, 8] -> [[11, 11, 11, 8, 8], [12], [20]]
landlord_cards =  [3, 3, 3, 4, 5, 6, 6, 7, 7, 8, 9, 9, 10, 10, 12, 13, 13, 20, 20, 30]
down_peasant_cards =  [3, 4, 6, 6, 7, 7, 8, 9, 9, 10, 11, 12, 12, 13, 14, 14, 20]
up_peasant_cards =  [4, 4, 5, 5, 5, 8, 8, 10, 11, 11, 11, 12, 13, 14, 14, 20, 40]
'''

''' #上家农民引牌牌序需要调整
landlord_cards =  [4, 4, 5, 5, 5, 6, 6, 8, 8, 8, 10, 10, 11, 12, 13, 13, 14, 14, 20, 30]
down_peasant_cards =  [3, 3, 4, 4, 5, 6, 9, 9, 10, 10, 11, 12, 12, 13, 14, 20, 20]
up_peasant_cards =  [3, 3, 6, 7, 7, 7, 7, 8, 9, 9, 11, 11, 12, 13, 14, 20, 40]
'''

'''
landlord_cards =  [3, 4, 5, 5, 5, 6, 6, 7, 8, 8, 9, 9, 9, 10, 11, 11, 12, 13, 14, 40]
down_peasant_cards =  [3, 4, 6, 8, 8, 10, 10, 11, 12, 12, 13, 13, 14, 20, 20, 20, 30]
up_peasant_cards =  [3, 3, 4, 4, 5, 6, 7, 7, 7, 9, 10, 11, 12, 13, 14, 14, 20]
'''

'''
# 上家对子不管，单牌不会拆对子来顶
landlord_cards =  [3, 3, 4, 4, 6, 6, 8, 8, 9, 9, 10, 11, 11, 11, 11, 12, 14, 20, 20, 40]
down_peasant_cards =  [4, 4, 5, 5, 6, 7, 8, 8, 10, 10, 12, 13, 13, 14, 20, 20, 30]
up_peasant_cards =  [3, 3, 5, 5, 6, 7, 7, 7, 9, 9, 10, 12, 12, 13, 13, 14, 14]
'''

'''
landlord_cards =  [3, 4, 4, 4, 5, 6, 7, 7, 8, 8, 10, 11, 11, 12, 12, 14, 14, 20, 20, 30]
down_peasant_cards =  [4, 5, 6, 8, 8, 9, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14]
up_peasant_cards =  [3, 3, 3, 5, 5, 6, 6, 7, 7, 9, 10, 13, 13, 14, 20, 20, 40]
'''

'''
landlord_cards =  [3, 5, 5, 5, 6, 6, 6, 6, 7, 8, 9, 10, 10, 11, 12, 13, 13, 14, 14, 20]
down_peasant_cards =  [4, 4, 4, 5, 7, 7, 8, 8, 10, 11, 11, 12, 12, 13, 14, 14, 20]
up_peasant_cards =  [3, 3, 3, 4, 7, 8, 9, 9, 9, 10, 11, 12, 13, 20, 20, 30, 40]
'''
'''
# 上家放单导致地主无忧轰炸1
landlord_cards =  [3, 3, 3, 3, 4, 5, 5, 6, 7, 8, 10, 11, 11, 12, 13, 13, 14, 14, 30, 40]
down_peasant_cards =  [4, 4, 5, 6, 7, 7, 8, 9, 9, 10, 10, 11, 12, 12, 13, 14, 20]
up_peasant_cards =  [4, 5, 6, 6, 7, 8, 8, 9, 9, 10, 11, 12, 13, 14, 20, 20, 20]
'''
'''
# 上家放单导致地主无忧轰炸2，引牌策略需要重新考虑
landlord_cards =  [3, 4, 5, 6, 6, 7, 7, 8, 8, 9, 11, 12, 12, 12, 12, 13, 13, 13, 14, 20]
down_peasant_cards =  [3, 4, 4, 5, 7, 8, 9, 10, 10, 10, 11, 11, 13, 14, 20, 20, 40]
up_peasant_cards =  [3, 3, 4, 5, 5, 6, 6, 7, 8, 9, 9, 10, 11, 14, 14, 20, 30]
'''
'''
# 王炸优先级居然高于对子 Fixed
# 顶家可控盘的情况下，冒险打三代一 Fixed
landlord_cards =  [4, 4, 6, 7, 8, 8, 9, 9, 9, 10, 10, 11, 12, 13, 13, 13, 14, 14, 20, 20]
down_peasant_cards =  [3, 4, 4, 5, 5, 5, 6, 6, 7, 7, 8, 8, 10, 10, 11, 12, 13]
up_peasant_cards =  [3, 3, 3, 5, 6, 7, 9, 11, 11, 12, 12, 14, 14, 20, 20, 30, 40]
'''
'''
landlord_cards =  [3, 4, 4, 5, 6, 7, 7, 8, 9, 9, 9, 9, 10, 10, 12, 13, 13, 14, 20, 20]
down_peasant_cards =  [3, 3, 4, 5, 6, 6, 7, 10, 11, 12, 12, 13, 13, 14, 20, 20, 30]
up_peasant_cards =  [3, 4, 5, 5, 6, 7, 8, 8, 8, 10, 11, 11, 11, 12, 14, 14, 40]
'''
'''
# 看发挥的牌局；三方都可以选; 测试农民配合打法
landlord_cards =  [3, 4, 4, 5, 5, 5, 6, 7, 8, 9, 10, 11, 11, 12, 12, 13, 13, 14, 14, 20]
down_peasant_cards =  [3, 4, 5, 6, 6, 7, 7, 7, 8, 9, 9, 11, 12, 12, 13, 14, 40]
up_peasant_cards =  [3, 3, 4, 6, 8, 8, 9, 10, 10, 10, 11, 13, 14, 20, 20, 20, 30]
'''

'''
# 看发挥的牌局；三方都可以选
landlord_cards =  [3, 3, 5, 5, 5, 6, 9, 9, 10, 10, 11, 11, 12, 12, 12, 14, 14, 20, 20, 20]
down_peasant_cards =  [4, 4, 4, 6, 7, 8, 8, 10, 10, 11, 11, 13, 13, 13, 13, 14, 20]
up_peasant_cards =  [3, 3, 4, 5, 6, 6, 7, 7, 7, 8, 8, 9, 9, 12, 14, 30, 40]
'''
'''
# 王炸轻出, Follow小单张优先出中牌而不是小牌
landlord_cards =  [3, 3, 4, 5, 6, 6, 7, 7, 7, 8, 8, 11, 12, 12, 13, 13, 14, 14, 20, 20]
down_peasant_cards =  [3, 4, 4, 5, 6, 6, 7, 8, 8, 9, 9, 10, 11, 11, 13, 14, 20]
up_peasant_cards =  [3, 4, 5, 5, 9, 9, 10, 10, 10, 11, 12, 12, 13, 14, 20, 30, 40]
'''
'''
#冒险冲小王还是出3小王收回，这是个问题
landlord_cards =  [3, 3, 4, 4, 4, 4, 5, 5, 8, 9, 9, 10, 11, 11, 12, 12, 13, 13, 20, 20]
down_peasant_cards =  [3, 5, 5, 6, 6, 7, 8, 8, 9, 10, 10, 11, 12, 13, 14, 14, 40]
up_peasant_cards =  [3, 6, 6, 7, 7, 7, 8, 9, 10, 11, 12, 13, 14, 14, 20, 20, 30]
'''
'''
# 首牌77AA Vs KKAA, 春天似乎没有考虑进去，首牌出的有点问题
landlord_cards =  [3, 4, 4, 4, 5, 5, 5, 7, 7, 8, 9, 10, 11, 12, 13, 13, 14, 14, 30, 40]
down_peasant_cards =  [3, 5, 6, 6, 7, 8, 9, 11, 11, 12, 12, 12, 14, 14, 20, 20, 20]
up_peasant_cards =  [3, 3, 4, 6, 6, 7, 8, 8, 9, 9, 10, 10, 10, 11, 13, 13, 20]
'''
''' #引牌牌序不当
landlord_cards =  [3, 3, 3, 4, 4, 5, 5, 6, 7, 9, 9, 9, 10, 10, 11, 13, 13, 14, 14, 20]
down_peasant_cards =  [3, 4, 6, 6, 7, 8, 8, 9, 10, 11, 12, 12, 12, 13, 14, 20, 40]
up_peasant_cards =  [4, 5, 5, 6, 7, 7, 8, 8, 10, 11, 11, 12, 13, 14, 20, 20, 30]
'''
'''
landlord_cards =  [4, 4, 4, 5, 5, 5, 6, 8, 8, 9, 9, 10, 10, 11, 11, 13, 13, 20, 20, 30]
down_peasant_cards =  [3, 3, 4, 6, 7, 8, 9, 9, 10, 12, 12, 12, 13, 14, 20, 20, 40]
up_peasant_cards =  [3, 3, 5, 6, 6, 7, 7, 7, 8, 10, 11, 11, 12, 13, 14, 14, 14]
'''
'''
# 残局单张可以控盘，却打了对子
landlord_cards =  [3, 3, 4, 4, 5, 5, 6, 6, 6, 8, 9, 10, 11, 12, 12, 12, 13, 13, 14, 20]
down_peasant_cards =  [3, 4, 6, 7, 7, 7, 8, 8, 9, 9, 10, 12, 13, 13, 14, 30, 40]
up_peasant_cards =  [3, 4, 5, 5, 7, 8, 9, 10, 10, 11, 11, 11, 14, 14, 20, 20, 20]
'''
'''
landlord_cards =  [4, 4, 5, 5, 7, 7, 7, 8, 8, 9, 9, 10, 10, 11, 13, 14, 14, 20, 20, 40]
down_peasant_cards =  [3, 3, 3, 5, 6, 7, 9, 10, 10, 11, 11, 11, 12, 12, 13, 13, 14]
up_peasant_cards =  [3, 4, 4, 5, 6, 6, 6, 8, 8, 9, 12, 12, 13, 14, 20, 20, 30]
'''

'''
#地主引牌决策不当, 好盘单张导致输牌
landlord_cards =  [3, 3, 4, 5, 5, 6, 6, 6, 7, 10, 10, 10, 11, 11, 12, 12, 13, 20, 20, 30]
down_peasant_cards =  [4, 4, 5, 7, 7, 7, 8, 8, 8, 9, 9, 10, 12, 12, 14, 20, 40]
up_peasant_cards =  [3, 3, 4, 5, 6, 8, 9, 9, 11, 11, 13, 13, 13, 14, 14, 14, 20]
'''
'''
#地主拆炸弹管牌
landlord_cards =  [3, 3, 3, 4, 4, 4, 5, 6, 8, 8, 10, 10, 10, 13, 13, 14, 14, 14, 14, 40]
down_peasant_cards =  [3, 6, 6, 7, 7, 8, 8, 9, 9, 10, 11, 11, 12, 13, 20, 20, 20]
up_peasant_cards =  [4, 5, 5, 5, 6, 7, 7, 9, 9, 11, 11, 12, 12, 12, 13, 20, 30]
'''
'''
#地主隐忍后发制人，但是AI似乎学不会这招，靠算牌/猜牌？
landlord_cards =  [3, 3, 3, 4, 4, 5, 5, 5, 5, 6, 6, 8, 9, 9, 9, 10, 11, 12, 13, 20]
down_peasant_cards =  [3, 4, 7, 8, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 20, 20, 40]
up_peasant_cards =  [4, 6, 6, 7, 7, 7, 8, 8, 9, 10, 11, 13, 14, 14, 14, 20, 30]
'''

'''
landlord_cards =  [4, 4, 5, 6, 6, 6, 7, 7, 7, 9, 9, 9, 10, 11, 11, 14, 14, 20, 20, 30]
down_peasant_cards =  [3, 4, 5, 7, 8, 8, 9, 10, 10, 11, 11, 12, 13, 13, 13, 14, 14]
up_peasant_cards =  [3, 3, 3, 4, 5, 5, 6, 8, 8, 10, 12, 12, 12, 13, 20, 20, 40]
'''

''' #残局出对，这种情况下应该考虑猜牌+蒙特卡洛明牌来打牌了
landlord_cards = [6,6,10,10,12,12,30]
down_peasant_cards = [9,9]
up_peasant_cards = [11,11]
'''

''' #农民AI没有算牌，未能一直发挥单张控盘优势；导致地主跑牌。
landlord_cards =  [4, 5, 5, 5, 6, 6, 7, 8, 8, 8, 9, 9, 10, 11, 11, 11, 13, 13, 14, 14]
down_peasant_cards =  [3, 3, 4, 7, 7, 9, 9, 10, 10, 11, 12, 13, 14, 20, 20, 30, 40]
up_peasant_cards =  [3, 3, 4, 4, 5, 6, 6, 7, 8, 10, 12, 12, 12, 13, 14, 20, 20]
'''

game = DouDiZhu3(landlord_cards, down_peasant_cards, up_peasant_cards)
print("Now:", datetime.datetime.now())
print("landlord_cards = ",landlord_cards)
print("down_peasant_cards = ", down_peasant_cards)
print("up_peasant_cards = ", up_peasant_cards)

# 出牌
currentRole = CardRole.LANDLORD
cardDecision = AI3Players()
while(True):
    winnerRole = game.isOver()
    if winnerRole == CardRole.INVALID: # 无人胜利
        pass
    else: # 地主或者农民胜利
        gameOver(winnerRole)
        break

    if currentRole == humanRole: # Human
        cardKind = humanPlayCards(currentRole, game)
    else: # AI
        try:
            #cardKind = game.AIPlayCards(currentRole, cardDecision)
            cardKind = cardDecision.AIPlayCards(currentRole, game)
        except:
            traceback.print_exc()

    if currentRole == CardRole.LANDLORD:
        print("Landlord Played:", cardKind)
    elif currentRole == CardRole.PEASANT_DOWN:
        print("Down Peasant Played:", cardKind)
    elif currentRole == CardRole.PEASANT_UP:
        print("Up Peasant Played:", cardKind)
    else:
        print("Exception Role Invallid:",currentRole)
        raise BaseException("Exception Invalid CardRole:", currentRole)

    game.playedCards(currentRole, cardKind)
    currentRole = getNextRole3Players(currentRole)