# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-11-23

import random
import datetime
import traceback

from Util.CardUtil import *
from DouDiZhu2 import *
from AI2Players import *
from AISparringLeft import *

#二人斗地主 人类 VS AI

# 牌局结束
def gameOver(winnerRole):
    if winnerRole == CardRole.LANDLORD:
        print("Landlord won")
    else:
        print("Peasant won")

# 人类出牌
def humanPlayCards(role, game):
    #if game.lastCardKind == []: #引牌
    #else: # 管牌
    ret = []
    print("Now Your rest Cards are:", game.getRestCardsByRole(role))
    while(True):
        rawCardKind = input("Please Input cards you want to play, e.g 3,3,3,4:")
        if rawCardKind:
            #cards = [int(x.strip()) for x in rawCardKind.split(',')]
            cards = []
            for x in rawCardKind.split(','):
                try:
                    cards.append(int(x.strip()))
                except:
                    #traceback.print_exc()
                    continue

            cardKind = generateCardKindFromCards(cards)
            if cardKind != None and isSubList(cardKind, game.getRestCardsByRole(role)):
                if getCardKind(cardKind) == CardKind.INVALID: #输入牌型不正确
                    print("INVALID CardKind Input Cards:", cards)
                # 还需要判断是否能管牌
                elif game.getLastCardArray() == []: # 首牌引牌
                    ret = cardKind
                    break
                elif canCardKindCover(cardKind, game.getLastCardArray()): #管牌，需要比牌
                    ret = cardKind
                    break
                else:
                    print("INVALID Input Cards:", cards, "NOT Larger than:", game.getLastCardArray())
            else:
                print("INVALID Input Cards:", cards)
        else:
            # 首牌、引牌不允许让牌
            if game.getLastCardArray() == []:
                pass
            else:
                ret = []  # 让牌，出空牌
                break
    return ret

# 发牌
cards = initCardsFor2Players()
landlord_cards = cards[0] # 地主20张牌
peasant_cards = cards[1] # 农民剩下的17张牌，之前20:-1有BUG，少了一张牌

#peasant_cards =  [5, 5, 5, 6, 6, 6, 7, 8, 9, 10, 11, 11, 11, 12, 12, 12, 20]
#landlord_cards = [5, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 13, 13, 13, 14, 14, 14]

# 轻率出2
#landlord_cards = [5, 5, 6, 6, 7, 7, 8, 9, 9, 10, 10, 10, 11, 12, 13, 14, 14, 14, 20, 40]
#peasant_cards =  [5, 5, 6, 8, 9, 10, 11, 11, 12, 12, 13, 13, 13, 14, 20, 20, 30]

# 轻出大王虽然赢了 Bug not fixed
#landlord_cards = [5, 5, 6, 6, 7, 8, 8, 9, 9, 10, 11, 11, 12, 14, 14, 14, 20, 20, 20, 40]
#peasant_cards = [5, 6, 6, 7, 8, 9, 11, 11, 12, 12, 12, 13, 13, 13, 14, 20, 30]

# 最后一手火箭的BUG
#landlord_cards =  [5, 5, 5, 6, 6, 7, 8, 9, 9, 9, 10, 12, 12, 13, 13, 14, 14, 20, 30, 40]
#peasant_cards = [6, 8, 8, 8, 9, 10, 10, 11, 11, 11, 12, 12, 13, 14, 14, 20, 20]

# 炸弹+对2，结果被火箭反制, 地主农民两个角色打都有问题， 怎么样做到让火箭忍忍？
#landlord_cards = [5, 5, 5, 5, 7, 7, 7, 8, 9, 10, 10, 11, 11, 12, 12, 12, 13, 14, 20, 20]
#peasant_cards = [6, 6, 6, 7, 8, 9, 9, 10, 11, 13, 13, 13, 14, 20, 20, 30, 40]

# 火箭出早了
#landlord_cards = [5, 5, 7, 7, 8, 9, 9, 10, 11, 12, 12, 13, 13, 13, 14, 14, 14, 20, 30, 40]
#peasant_cards = [5, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 12, 13, 14, 20, 20, 20]

# 四代二导致输了 not yet?
#landlord_cards =  [5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 10, 10, 10, 11, 11, 13, 13, 14, 20, 20]
#peasant_cards = [5, 5, 5, 8, 9, 9, 9, 9, 10, 11, 11, 12, 13, 13, 14, 30, 40]

# 农民两个炸弹出早了 Not Fixed
#landlord_cards = [6, 7, 7, 8, 10, 10, 10, 10, 11, 11, 11, 12, 12, 13, 13, 14, 14, 14, 20, 30]
#peasant_cards = [5, 5, 5, 5, 6, 6, 7, 7, 9, 9, 9, 9, 11, 12, 12, 14, 20]

# 农民 火箭炸早了
#landlord_cards = [5, 6, 6, 6, 7, 7, 9, 10, 11, 11, 11, 12, 12, 12, 12, 13, 13, 14, 14, 20]
#peasant_cards = [5, 5, 6, 7, 7, 8, 8, 8, 9, 10, 13, 14, 14, 20, 20, 30, 40]

# 农民不会让牌导致输
#landlord_cards = [5, 5, 6, 6, 7, 8, 8, 8, 10, 10, 11, 12, 13, 13, 14, 14, 20, 20, 20, 30]
#peasant_cards = [5, 6, 7, 7, 7, 9, 9, 9, 9, 10, 11, 11, 12, 12, 14, 14, 40]

# 农民 火箭炸早了
#landlord_cards = [5, 5, 5, 6, 6, 7, 7, 7, 8, 8, 10, 10, 10, 12, 12, 13, 13, 20, 20, 20]
#peasant_cards = [5, 6, 6, 7, 8, 9, 9, 10, 11, 12, 12, 13, 13, 14, 20, 30, 40]

# 88_人类只剩一张牌，电脑出小单张导致输
#landlord_cards =  [6, 7, 7, 8, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 12, 13, 13, 13, 14, 20]
#peasant_cards = [5, 5, 6, 6, 7, 7, 8, 9, 10, 10, 11, 11, 14, 14, 20, 20, 30]

#65_火箭炸早了 Fixed
#landlord_cards = [5, 5, 6, 6, 6, 6, 7, 8, 8, 8, 9, 9, 9, 10, 11, 11, 13, 13, 14, 20]
#peasant_cards = [5, 7, 7, 8, 10, 10, 10, 11, 12, 12, 13, 14, 20, 20, 20, 30, 40]

# 激进打法测试1
#landlord_cards =  [5, 5, 6, 6, 6, 7, 8, 10, 10, 11, 12, 12, 12, 13, 13, 14, 14, 20, 20, 30]
#peasant_cards =  [5, 7, 7, 8, 8, 9, 9, 9, 9, 10, 11, 11, 12, 13, 14, 20, 20]

# 激进打法测试2 地主激进结果出2被管
#landlord_cards = [5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 11, 11, 11, 13, 13, 14, 14, 14, 20]
#peasant_cards = [5, 7, 8, 8, 9, 10, 11, 12, 12, 12, 13, 13, 14, 20, 20, 20, 30]

# 激进打法测试3 地主
#landlord_cards = [5, 5, 7, 7, 8, 9, 9, 10, 11, 12, 12, 13, 13, 13, 14, 14, 14, 20, 30, 40]
#peasant_cards = [5, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 12, 13, 14, 20, 20, 20]

# 农民 火箭炸早了或者拆早了 Fixed
#landlord_cards = [5, 5, 5, 6, 7, 8, 9, 9, 10, 11, 11, 12, 12, 13, 13, 13, 13, 14, 14, 20]
#peasant_cards = [5, 6, 7, 8, 9, 9, 10, 10, 10, 11, 12, 14, 14, 20, 20, 30, 40]

# 农民，该赢却输, 关键时刻应出单却出对 TODO 需要对出牌算法细调 Fixed
#landlord_cards = [5, 6, 6, 6, 7, 8, 9, 10, 11, 11, 11, 12, 12, 13, 13, 14, 14, 20, 20, 30]
#peasant_cards = [5, 6, 7, 7, 7, 8, 9, 9, 9, 10, 11, 12, 13, 14, 20, 20, 40]

# 农民，可以收牌却不管 Fixed
#Landlord Played: [13, 13]
#Top: 1 112.00365000000002 Cover: [] -> [146.41000000000003, [11, 11, 11, 5], [20], [20]]
#Top: 2 100.0 Cover: [20, 20] -> [[11, 11, 11, 12, 12, 12, 5, 14]]
#landlord_cards =  [5, 5, 5, 6, 7, 7, 8, 8, 8, 9, 11, 12, 13, 13, 14, 14, 14, 20, 30, 40]
#peasant_cards =  [5, 6, 7, 8, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 14, 20, 20]

# Bug Fixed
#landlord_cards = [5, 5, 6, 6, 6, 6, 7, 8, 9, 9, 10, 11, 11, 11, 12, 12, 14, 14, 20, 30]
#peasant_cards = [5, 7, 7, 8, 8, 9, 9, 10, 11, 12, 13, 13, 14, 14, 20, 20, 20]

# 连出两个炸弹 Bug Fixed
#landlord_cards =  [6, 6, 6, 8, 9, 9, 9, 9, 11, 11, 11, 11, 12, 12, 13, 13, 13, 14, 20, 20]
#peasant_cards = [5, 5, 6, 7, 7, 7, 8, 8, 10, 10, 10, 10, 13, 14, 14, 30, 40]

# 地主两个炸弹还输了,炸弹轻出
#landlord_cards =  [5, 6, 6, 7, 9, 9, 10, 10, 10, 10, 12, 12, 12, 12, 13, 13, 14, 20, 20, 30]
#peasant_cards =  [5, 5, 6, 6, 7, 7, 8, 8, 8, 8, 9, 11, 13, 14, 14, 20, 40]

# 农民炸弹轻出，结果错失良机
#landlord_cards =  [5, 5, 7, 7, 8, 9, 9, 9, 10, 10, 10, 11, 11, 12, 12, 14, 14, 20, 30, 40]
#peasant_cards =  [6, 6, 6, 6, 7, 8, 8, 8, 10, 11, 11, 12, 13, 14, 14, 20, 20]

# 地主出牌顺序不当，导致输牌, 激进打法没有影响到价值计算 Fixed
# Radical Strategy Choosen By getOpponentRateForBombRocket 0.0 [[6, 7, 8, 9, 10], [10], [20, 20]]
# Top: 1 100.0 Lead: [10] -> [[6, 7, 8, 9, 10], [10], [20], [20]]
# Top: 2 81.0 Lead: [6, 7, 8, 9, 10] -> [[6, 7, 8, 9, 10], [10], [20, 20]]
#landlord_cards = [6, 6, 7, 8, 8, 9, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 20, 20, 40]
#peasant_cards = [5, 5, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 11, 14, 20, 20, 30]

#22_出牌顺序问题导致输牌 Fixed
#我是地主，电脑是农民，最后残局出牌问题导致输牌。原因同上：激进打法没影响到价值计算 Fixed
#landlord_cards =  [5, 6, 6, 7, 7, 7, 8, 8, 8, 9, 10, 10, 11, 12, 13, 13, 14, 20, 20, 30]
#peasant_cards =  [5, 5, 5, 6, 7, 9, 9, 9, 10, 11, 12, 13, 14, 14, 20, 20, 40]

# 55 地主出牌顺序不当，导致输牌 Fixed
#landlord_cards =  [5, 5, 5, 5, 6, 6, 6, 7, 7, 8, 9, 10, 11, 12, 13, 13, 14, 14, 14, 20]
#peasant_cards =  [7, 8, 8, 8, 9, 9, 10, 10, 10, 11, 11, 12, 13, 20, 20, 20, 30]

#23_出牌顺序导致输牌 Fixed
#landlord_cards =  [5, 6, 6, 6, 7, 8, 8, 9, 9, 9, 10, 10, 11, 11, 12, 12, 13, 20, 20, 30]
#peasant_cards =  [5, 5, 6, 7, 8, 8, 10, 10, 12, 12, 13, 13, 14, 14, 14, 20, 40]

#landlord_cards =  [5, 5, 5, 6, 6, 7, 7, 9, 9, 9, 10, 12, 13, 13, 14, 14, 14, 14, 20, 30]
#peasant_cards =  [5, 6, 6, 7, 8, 8, 8, 8, 10, 11, 12, 12, 12, 20, 20, 20, 40]

#landlord_cards =  [5, 5, 6, 6, 6, 7, 7, 8, 9, 9, 10, 10, 11, 13, 13, 14, 14, 20, 20, 40]
#peasant_cards =  [5, 5, 6, 8, 8, 8, 9, 10, 10, 11, 12, 12, 12, 13, 13, 20, 20]

# 48_lose_地主出牌顺序导致输牌 Fixed
#landlord_cards =  [6, 6, 7, 8, 8, 9, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 20, 20, 40]
#peasant_cards =  [5, 5, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 11, 14, 20, 20, 30]

#landlord_cards =  [5, 5, 5, 6, 7, 8, 9, 9, 11, 11, 12, 12, 12, 13, 13, 14, 14, 20, 20, 40]
#peasant_cards =  [6, 7, 7, 8, 8, 9, 10, 10, 10, 11, 11, 12, 13, 13, 14, 20, 30]

#peasant_cards =  [6, 6, 6, 7, 7, 8, 9, 9, 10, 10, 12, 13, 14, 14, 14, 20, 20]
#landlord_cards = [5, 5, 5, 6, 7, 7, 8, 8, 8, 9, 9, 10, 10, 11, 12, 13, 14, 20, 30, 40]

#peasant_cards =  [5, 5, 7, 7, 7, 8, 8, 9, 10, 11, 11, 12, 12, 13, 13, 14, 20] #
#landlord_cards = [5, 6, 7, 8, 9, 9, 9, 10, 10, 10, 13, 14, 14, 14, 20, 30, 40] #AI

#peasant_cards =  [5, 6, 8, 8, 9, 9, 10, 11, 11, 12, 12, 13, 14, 14, 14, 30, 40] #AI
#landlord_cards = [5, 5, 7, 7, 7, 7, 8, 9, 9, 10, 10, 10, 11, 11, 12, 13, 13]

#peasant_cards =  [5, 5, 6, 6, 7, 7, 8, 10, 10, 11, 12, 12, 13, 13, 13, 14, 30]
#landlord_cards = [5, 5, 6, 6, 7, 8, 8, 8, 9, 9, 12, 13, 14, 20, 20, 20, 20] #AI

#peasant_cards = [5, 6, 7, 8, 10, 12, 13, 13, 30, 20, 20, 12, 8, 8, 9, 6, 5] #AI
#landlord_cards =  [5, 6, 7, 10, 11, 12, 13, 14, 20, 20, 14, 13, 8, 9, 7, 6, 5]

#landlord_cards = [14, 14, 14, 14, 13, 12, 12, 12, 10, 8, 8, 8, 8, 7, 7, 5, 5]
#peasant_cards =  [9, 13, 9, 6, 11, 20, 7, 20, 10, 10, 30, 11, 10, 13, 40, 5, 12] #AI

#landlord_cards = [8, 8, 8, 11, 5, 20, 7, 6, 5, 6, 7, 6, 7, 5, 12, 8, 11] #AI 三飞机
#peasant_cards =  [30, 40, 20, 20, 20, 14, 12, 12, 12, 10, 10, 10, 9, 9, 7, 6, 5]

''' TOP2是最好的，细微之处怎么体现？
Top: 1 200.0 Lead: [12, 12, 12, 13, 13, 13, 14, 14, 14, 5, 6, 6] -> [[9, 9, 9, 9], [12, 12, 12, 13, 13, 13, 14, 14, 14, 5, 6, 6], [20]]
Top: 2 200.0 Lead: [12, 12, 12, 13, 13, 13, 5, 20] -> [[9, 9, 9, 9], [12, 12, 12, 13, 13, 13, 5, 20], [14, 14, 14, 6, 6]]
Top: 3 200.0 Lead: [12, 12, 12, 13, 13, 13, 6, 6] -> [[9, 9, 9, 9], [12, 12, 12, 13, 13, 13, 6, 6], [14, 14, 14, 5], [20]]
Top: 4 200.0 Lead: [12, 12, 12, 13, 13, 13, 5, 6] -> [[9, 9, 9, 9], [12, 12, 12, 13, 13, 13, 5, 6], [14, 14, 14, 6], [20]]
'''
#landlord_cards = [5, 6, 6, 9, 9, 9, 9, 12, 12, 12, 13, 13, 13, 14, 14, 14, 20]
#peasant_cards = [5, 5, 5, 6, 7, 7, 7, 8, 10, 10, 10, 10, 11, 11, 13, 30, 40]

#landlord_cards =  [5, 5, 5, 6, 7, 8, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 20, 20, 30] #AI
#peasant_cards =  [5, 6, 6, 7, 7, 7, 8, 8, 8, 9, 10, 11, 12, 13, 14, 20, 40]

landlord_cards =  [5, 6, 6, 8, 8, 9, 9, 10, 10, 10, 11, 11, 12, 13, 14, 14, 14, 20, 30, 40] #AI
peasant_cards =  [5, 6, 6, 7, 7, 7, 7, 8, 9, 10, 11, 12, 13, 13, 13, 14, 20]

# 注意，以后需要改进 只输入一方的牌
#landlord_cards =  [5, 5, 5, 5, 6, 7, 7, 8, 9, 10, 11, 12, 12, 13, 14, 14, 20, 20, 20, 40] #AI
#peasant_cards =  [6, 6, 6, 7, 8, 8, 9, 9, 9, 10, 10, 12, 13, 13, 13, 20, 30]

#TODO 校验牌数量
print("Peasant Card Length：", len(peasant_cards))
print("Landlord Card Length：", len(landlord_cards))

landlord_cards = sorted(landlord_cards)
peasant_cards = sorted(peasant_cards)
landlordCardSequence = []  # 地主出牌序列
peasantCardSequence = []  # 农民出牌序列

LogUtil.logOutEnabled()
#LogUtil.logOutDisabled()

# 选择身份
order = int(input("Which identity do you want? Landlord is 1, Peasant is 0:"))
humanRole = CardRole.INVALID
if order == 1:
    humanRole = CardRole.LANDLORD
else:
    humanRole = CardRole.PEASANT

game = DouDiZhu2(landlord_cards, peasant_cards)
print("Now:", datetime.datetime.now())
print("landlord_cards = ",landlord_cards)
print("peasant_cards = ", peasant_cards)

# 出牌
currentRole = CardRole.LANDLORD
cardDecision = AI2Players()
#cardDecision = AISparringLeft()

while(True):
    winnerRole = game.isOver()
    if winnerRole == CardRole.INVALID: # 无人胜利
        pass
    else: # 地主或者农民胜利
        gameOver(winnerRole)
        break

    if currentRole == humanRole: # Human
        cardKind = humanPlayCards(currentRole, game)
    else: # AI
        try:
            #cardKind = game.AIPlayCards(currentRole, cardDecision)
            cardKind = cardDecision.AIPlayCards(currentRole, game)
        except:
            traceback.print_exc()

    if currentRole == CardRole.LANDLORD:
        print("Landlord Played:", cardKind)
    elif currentRole == CardRole.PEASANT:
        print("Peasant Played:", cardKind)
    else:
        print("Exception Role Invallid:",currentRole)
        raise BaseException("Exception Invalid CardRole:", currentRole)

    game.playedCards(currentRole, cardKind)
    currentRole = getNextRole2Players(currentRole)