# -*- coding: utf-8 -*-
import math
import random
import itertools

class CardRole(object):
    INVALID = 0
    LANDLORD = 1 # 地主
    PEASANT = 2 # 农民，二人斗地主
    PEASANT_UP = 3 # 农民，三人斗地主，地主上家
    PEASANT_DOWN = 4 # 农民，三人斗地主，地主下家

# 出牌顺序
def getNextRole2Players(currentRole):
    ret = CardRole.INVALID
    if currentRole == CardRole.LANDLORD:
        ret = CardRole.PEASANT
    else:
        ret = CardRole.LANDLORD
    return ret

# 出牌顺序
def getNextRole3Players(currentRole):
    ret = CardRole.INVALID
    if currentRole == CardRole.LANDLORD:
        ret = CardRole.PEASANT_DOWN
    elif currentRole == CardRole.PEASANT_DOWN:
        ret = CardRole.PEASANT_UP
    elif currentRole == CardRole.PEASANT_UP:
        ret = CardRole.LANDLORD
    else:
        raise BaseException("Exception Invalid CardRole:", currentRole)
        ret = CardRole.INVALID
    return ret

# 判断List是否包含subList
def isSubList(subList, List):
    for element in subList:
        if subList.count(element) > List.count(element):
            return False
    return True

# 通过输入的乱序牌型，生成能识别的有效型
# 例如输入 3 4 4 4 5 5 5 6，输出 4 4 4 5 5 5 3 6
def generateCardKindFromCards(cards):
    cards = sorted(cards)
    # 分组合并
    length = len(cards)
    cardsDict = {}
    for index in range(1,5):
        cardsDict[index] = []

    # 分组，按照单张对子三张四张分组
    key = 0
    while key < length:
        count = 1
        for index in range(key+1,length):
            if cards[key] != cards[index]:
                break
            else:
                count += 1
        if count in (1,2,3,4): #合法性检查
            for i in range(0, count):
                cardsDict[count].append(cards[key])
        key = key + count

    # 合并, 依次是4张3张2张1张
    ret = []
    for index in range(4,0,-1):
        ret += cardsDict[index]

    # 校验一下
    if CardKind.INVALID == getCardKind(ret):
        print("INVALID Card Kind : ", cards)
        ret = None
    return ret

class CardClass(object):
    INVALID = 0
    SMALL = 1
    MIDDLE = 2
    LARGE = 3

def getCardClass(cardValue):
    if cardValue >=CardValue.Card_3 and cardValue < CardValue.Card_10: # 3 4 5 6 7 8 9为小牌
        return CardClass.SMALL
    elif cardValue >= CardValue.Card_10 and cardValue <= CardValue.Card_A: #10 J Q K A 为中牌
        return CardClass.MIDDLE
    elif cardValue == CardValue.Card_2 or cardValue == CardValue.Card_B or cardValue == CardValue.Card_R: # 2 小王 大王 为大牌
        return CardClass.LARGE
    else:
        return CardClass.INVALID

class CardKind(object):
    INVALID = 1000
    DUCK = 1001  # 让牌

    ROCKET = 800  # 火箭
    BOMB = 900  # 炸弹

    SINGLE = 1010 #单张
    PAIR = 1020 #对子
    THREE = 1030 #三张
    THREE_PLUS1 = 1031 # 三带单
    THREE_PLUS2 = 1032 # 三带对

    FOUR_PLUS1 = 1041  # 四带2单
    FOUR_PLUS2 = 1042  # 四带2对
    PLANE_EMPTY = 1060  # 飞机空载，TODO 出牌可能不支持此牌型
    PLANE_PLUS1 = 1061  # 飞机带单
    PLANE_PLUS2 = 1062  # 飞机带双
    PAIRS = 1080  # 连对
    STRAIGHT = 1100  # 顺子

class CardValue(object):
    Card_Min = 0 # 最小值
    Card_3 = 3
    Card_4 = 4
    Card_5 = 5
    Card_6 = 6
    Card_7 = 7
    Card_8 = 8
    Card_9 = 9
    Card_10 = 10
    Card_J = 11
    Card_Q = 12
    Card_K = 13
    Card_A = 14
    Card_2 = 20
    Card_B = 30 #小王
    Card_R = 40 #大王

OrderCardRank = {
    CardValue.Card_3: 3,
    CardValue.Card_4: 4,
    CardValue.Card_5: 5,
    CardValue.Card_6: 6,
    CardValue.Card_7: 7,
    CardValue.Card_8: 8,
    CardValue.Card_9: 9,
    CardValue.Card_10: 20,
    CardValue.Card_J: 22,
    CardValue.Card_Q: 23,
    CardValue.Card_K: 25,
    CardValue.Card_A: 24,
    CardValue.Card_2: 2,
    CardValue.Card_B: 1,  # 小王
    CardValue.Card_R: 0,  # 大王
}

GuardCardRank = {
    CardValue.Card_3: 3,
    CardValue.Card_4: 4,
    CardValue.Card_5: 5,
    CardValue.Card_6: 6,
    CardValue.Card_7: 7,
    CardValue.Card_8: 8,
    CardValue.Card_9: 9,
    CardValue.Card_10: 20,
    CardValue.Card_J: 22,
    CardValue.Card_Q: 23,
    CardValue.Card_K: 25,
    CardValue.Card_A: 24,
    CardValue.Card_2: 18,
    CardValue.Card_B: 16,  # 小王
    CardValue.Card_R: 15,  # 大王
}

class ConstCard(object):
    TOP_BY_COUNT = 10
    TOP_BY_PERCENT = 10
    CARD_ROCKET = [CardValue.Card_B, CardValue.Card_R]
    RANDCOM_COUNT = 100

""" #没有用上
# 扑克值到名称的映射
_cardsValue2Name = {3:'3', 4:'4', 5:'5', 6:'6', 7:'7', 8:'8', 9:'9', 10:'0',  11:'J', 12:'Q', 13:'K', 14:'A', 20:'2', 30:'B', 40:'R'}

# 扑克名称到值的映射
_cardsName2Value = {'3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, '0':10,  'J':11, 'Q':12, 'K':13, 'A':14, '2':20, 'B':30, 'R':40}

#name,value,desc
_cardsLib = (('3',3,'黑桃3'),('3',3,'红桃3'),('梅花3',3,'梅花3'),('3',3,'方片3'),
			('4',4,'黑桃4'),('4',4,'红桃4'),('梅花4',4,'梅花4'),('4',4,'方片4'),
			('5',5,'黑桃5'),('5',5,'红桃5'),('梅花5',5,'梅花5'),('5',5,'方片5'),
			('6',6,'黑桃6'),('6',6,'红桃6'),('梅花6',6,'梅花6'),('6',6,'方片6'),
			('7',7,'黑桃7'),('7',7,'红桃7'),('梅花7',7,'梅花7'),('7',7,'方片7'),
			('8',8,'黑桃8'),('8',8,'红桃8'),('梅花8',8,'梅花8'),('8',8,'方片8'),
			('9',9,'黑桃9'),('9',9,'红桃9'),('梅花9',9,'梅花9'),('9',9,'方片9'),
			('0',10,'黑桃10'),('0',10,'红桃10'),('0',10,'梅花10'),('0',10,'方片10'),
			('J',11,'黑桃J'),('J',11,'红桃J'),('J',11,'梅花J'),('J',11,'方片J'),
			('Q',12,'黑桃Q'),('Q',12,'红桃Q'),('Q',12,'梅花Q'),('Q',12,'方片Q'),
			('K',13,'黑桃K'),('K',13,'红桃K'),('K',13,'梅花K'),('K',13,'方片K'),
			('A',14,'黑桃A'),('A',14,'红桃A'),('A',14,'梅花A'),('A',14,'方片A'),
			('2',20,'黑桃2'),('2',20,'红桃2'),('2',20,'梅花2'),('2',20,'方片2'),
			('B',30,'小王'),('R',40,'大王')
			)
"""

#二人斗地主牌库
_cardsLib_for_2players = (5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10,
             11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14,
             20, 20, 20, 20, 30, 40)

_cardsLib_for_3players = (3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10,
                          11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14,
                          20, 20, 20, 20, 30, 40)

def initCardsFor2Players17vs17(cards = []):
    retList = []
    if len(cards) > 0:
        retList.append(cards)  # 地主牌
        cardsLib = list(_cardsLib_for_2players)
        for card in cards:
            cardsLib.remove(card)
        initCardsList = random.sample(cardsLib, 17)
        retList.append(initCardsList) # 二人斗地主农民牌
    else: # 没有指定地主牌，那随机发牌好了
        initCardsList = random.sample(_cardsLib_for_2players, 34)
        retList.append(initCardsList[0:17]) #二人斗地主地主牌
        retList.append(initCardsList[17:]) #二人斗地主农民牌

    for ret in retList: #排序
        ret.sort()
    return retList

# 发牌
# 输入cards为指定的地主牌
def initCardsFor2Players(cards = []):
    retList = []
    if len(cards) > 0:
        retList.append(cards)  # 地主牌
        cardsLib = list(_cardsLib_for_2players)
        for card in cards:
            cardsLib.remove(card)
        initCardsList = random.sample(cardsLib, 17)
        retList.append(initCardsList) # 二人斗地主农民牌
    else: # 没有指定地主牌，那随机发牌好了
        initCardsList = random.sample(_cardsLib_for_2players, 37)
        retList.append(initCardsList[0:20]) #二人斗地主地主牌
        retList.append(initCardsList[20:]) #二人斗地主农民牌

    for ret in retList: #排序
        ret.sort()
    return retList

# 输入cards为指定的地主牌
#TODO 叫牌功能
def initCardsFor3Players(cards = []):
    retList = []
    if len(cards) > 0:
        retList.append(cards)  # 地主牌
        cardsLib = list(_cardsLib_for_3players)
        for card in cards:
            cardsLib.remove(card)
        initCardsList = random.sample(cardsLib, 17)
        retList.append(initCardsList) #三人斗地主上家农民牌
        for card in initCardsList:
            cardsLib.remove(card)
        retList.append(cardsLib)  # 剩下的牌为三人斗地主下家农民牌
    else:
        initCardsList = random.sample(_cardsLib_for_3players, 37)
        retList.append(initCardsList[0:20]) #三人斗地主地主牌
        retList.append(initCardsList[20:]) #三人斗地主上家农民牌

        cardsLib = list(_cardsLib_for_3players)
        for card in initCardsList:
            cardsLib.remove(card)
        retList.append(cardsLib) # 剩下的牌为三人斗地主下家农民牌

    for ret in retList: #排序
        ret.sort()
    return retList

# 二人斗地主给对手随机发牌
# 返回：二维List，每个元素是一个列表，代表着该敌对角色的牌(为三人斗地主而设计的数据结构，因为1地主VS2农民)
def getRandomOpponentCards(gameInfo):
    cardsLib = None
    if gameInfo.getPlayers() == 2:
        cardsLib = list(_cardsLib_for_2players)
    else:
        cardsLib = list(_cardsLib_for_3players)

    '''
    if isinstance(gameInfo, DouDiZhu2):
        cardsLib = list(_cardsLib_for_2players)
    else:
        cardsLib = list(_cardsLib_for_3players)
    '''
    openedCards =  gameInfo.getOpenedCards()
    for card in openedCards:
        cardsLib.remove(card)

    random.shuffle(cardsLib)
    size = gameInfo.getOpponentRestCardsLength()

    ret = []
    if gameInfo.getPlayers() == 2:
        ret.append(sorted(cardsLib[0:size]))
    else: #三人斗地主
        if gameInfo.getCurrentRole() == CardRole.LANDLORD:
            ret.append(sorted(cardsLib[0:size]))
            ret.append(sorted(cardsLib[size:]))
        else:
            ret.append(sorted(cardsLib[0:size]))
    return ret

# 从牌面cardList中找出能管cardKind牌型的 牌型列表
def getCoverableCardKind(cardKind, cardList):
    retList = []
    sortedCardList = sorted(cardList)
    kind = getCardKind(cardKind)
    if kind == CardKind.SINGLE:
        retList = getCoverableCardKindBySingle(cardKind, sortedCardList)
    elif kind == CardKind.PAIR:
        retList = getCoverableCardKindByPair(cardKind, sortedCardList)

    elif kind == CardKind.THREE:
        retList = getCoverableCardKindByThreeEmpty(cardKind, sortedCardList)
    elif kind == CardKind.THREE_PLUS1:
        retList = getCoverableCardKindByThreePlus1(cardKind, sortedCardList)
    elif kind == CardKind.THREE_PLUS2:
        retList = getCoverableCardKindByThreePlus2(cardKind, sortedCardList)

    elif kind == CardKind.STRAIGHT:
        retList = getCoverableCardKindByStraight(cardKind, sortedCardList)
    elif kind == CardKind.PAIRS:
        retList = getCoverableCardKindByPairs(cardKind, sortedCardList)

    elif kind == CardKind.FOUR_PLUS1:
        retList = getCoverableCardKindByFourPlus1(cardKind, sortedCardList)
    elif kind == CardKind.FOUR_PLUS2:
        retList = getCoverableCardKindByFourPlus2(cardKind, sortedCardList)

    elif kind == CardKind.PLANE_EMPTY:
        retList = getCoverableCardKindByPlaneEmpty(cardKind, sortedCardList)
    elif kind == CardKind.PLANE_PLUS1:
        retList = getCoverableCardKindByPlanePlus1(cardKind, sortedCardList)
    elif kind == CardKind.PLANE_PLUS2:
        retList = getCoverableCardKindByPlanePlus2(cardKind, sortedCardList)

    elif kind == CardKind.BOMB:
        retList = getCoverableCardKindByBomb(cardKind, sortedCardList)
        rocketList = getRocketList(sortedCardList)
        retList += rocketList
        return retList
    elif kind == CardKind.ROCKET:
        retList = []
        return retList
    else:
        print("Exception:", kind, cardKind, cardList)
        return []

    minBomb = [CardValue.Card_Min, CardValue.Card_Min, CardValue.Card_Min, CardValue.Card_Min]
    bombList = getCoverableCardKindByBomb(minBomb, sortedCardList)
    retList += bombList
    rocketList = getRocketList(sortedCardList)
    retList += rocketList
    return retList

# 比牌
def getCoverableCardKindByKind(cardKind, kind, sortedCardList):
    pass

def getCoverableCardKindBySingle(cardKind, sortedCardList):
    retList = []
    cardKeyValue = cardKind[0]
    length = len(sortedCardList)
    index = 0
    while index < length:
        value = sortedCardList[index]
        if value > cardKeyValue:
            retList.append([value])
            cardKeyValue = value  # 避免返回重复
            index += 1
        else:
            index += 1
    return retList

def getCoverableCardKindByPair(cardKind, sortedCardList):
    cardKeyValue = cardKind[0]
    retList = []
    length = len(sortedCardList)
    index = 0
    while index < length-1:
        value = sortedCardList[index]
        if value > cardKeyValue and value == sortedCardList[index+1]:
            retList.append([value, value])
            cardKeyValue = value  # 避免返回重复
            index += 2
        else:
            index += 1
    return retList

def getCoverableCardKindByThreeEmpty(cardKind, sortedCardList):
    retList = []
    cardKeyValue = cardKind[0]
    length = len(sortedCardList)
    index = 0
    while index < length-2:
        value = sortedCardList[index]
        if value > cardKeyValue and value == sortedCardList[index+2]:
            retList.append([value, value, value])
            cardKeyValue = value # 避免返回重复
            index += 3
        else:
            index += 1
    return retList

def getCoverableCardKindByThreePlus1(cardKind, sortedCardList):
    retList = []
    threeList = getCoverableCardKindByThreeEmpty(cardKind, sortedCardList)
    singleList = getSingleListFromSortedCardList(sortedCardList)
    for three in threeList:
        for single in singleList:
            if three[0] != single[0]:
                threePlus1 = three + single
                retList.append(threePlus1)
    return retList

def getCoverableCardKindByThreePlus2(cardKind, sortedCardList):
    retList = []
    threeList = getCoverableCardKindByThreeEmpty(cardKind, sortedCardList)
    pairList = getPairListFromSortedCardList(sortedCardList)
    for three in threeList:
        for pair in pairList:
            if three[0] != pair[0]:
                threePlus2 = three + pair
                retList.append(threePlus2)
    return retList

# 四代单
def getCoverableCardKindByFourPlus1(cardKind, sortedCardList):
    retList = []
    fourList = getCoverableCardKindByBomb(cardKind, sortedCardList)
    singleList = sortedCardList[:]
    length = len(singleList)
    for four in fourList:
        for i in range(0,length):
            for j in range(i+1,length):
                if four[0] != singleList[i] and four[0] != singleList[j]:
                    FourPlus2 = four + [singleList[i]] + [singleList[j]]
                    retList.append(FourPlus2)

    retList.sort()
    uniqRet = []
    for value in retList:
        if value not in uniqRet:
            uniqRet.append(value)
    return uniqRet

# 四代双
def getCoverableCardKindByFourPlus2(cardKind, sortedCardList):
    retList = []
    fourList = getCoverableCardKindByBomb(cardKind, sortedCardList)
    pairList = getPairListFromSortedCardList(sortedCardList)
    length = len(pairList)
    for four in fourList:
        for i in range(0,length):
            for j in range(i+1,length):
                if four[0] != pairList[i][0] and four[0] != pairList[j][0]:
                    FourPlus2 = four + pairList[i] + pairList[j]
                    retList.append(FourPlus2)
    return retList

def getCoverableCardKindByStraight(cardKind, sortedCardList):
    retList = []
    if cardKind[-1] >= CardValue.Card_A:
        return retList

    length = len(cardKind)
    start = cardKind[0] + 1
    end = CardValue.Card_A - length + 1
    for index in range(start, end+1):
        bMatched = 1
        for element in range(index, index + length):
            if sortedCardList.count(element) == 0:
                bMatched = 0
                break
        if bMatched == 1:
            comb = sortedCardList[:]
            straight = []
            for element in range(index, index + length):
                straight.append(element)
                comb.remove(element)
            comb.insert(0, straight)
            retList.append(straight)
    return retList

def getCoverableCardKindByPairs(cardKind, sortedCardList):
    retList = []
    cardKeyValue = cardKind[0]
    length = math.floor(len(cardKind) / 2)

    start = cardKeyValue + 1
    end = CardValue.Card_A - length + 1
    for index in range(start, end+1):
        bMatched = 1
        for element in range(index, index + length):
            if sortedCardList.count(element) < 2:
                bMatched = 0
                break
        if bMatched == 1:
            comb = sortedCardList[:]
            pairs = []
            for element in range(index, index + length):
                pairs.append(element)
                pairs.append(element)
                comb.remove(element)
                comb.remove(element)
            comb.insert(0, pairs)
            retList.append(pairs)
    return retList

def getCoverableCardKindByPlane(cardKind, sortedCardList, kind):
    retList = []
    cardKeyValue = cardKind[0]
    if kind == CardKind.PLANE_EMPTY:
        length = math.floor(len(cardKind) / 3)
    elif kind == CardKind.PLANE_PLUS1:
        length = math.floor(len(cardKind) / 4)
    elif kind == CardKind.PLANE_PLUS2:
        length = math.floor(len(cardKind) / 5)
    else:
        raise BaseException("Exception getCoverableCardKindByPlane kind INVALID", kind, cardKind)

    start = cardKeyValue + 1
    end = CardValue.Card_A - length + 1
    for index in range(start, end+1):
        bMatched = 1
        for element in range(index, index + length):
            if sortedCardList.count(element) < 3:
                bMatched = 0
                break
        if bMatched == 1:
            comb = sortedCardList[:]
            plane = []
            for element in range(index, index + length):
                plane.append(element)
                plane.append(element)
                plane.append(element)
                comb.remove(element)
                comb.remove(element)
            comb.insert(0, plane)
            retList.append(plane)
    return retList

def getCoverableCardKindByPlaneEmpty(cardKind, sortedCardList):
    retList = getCoverableCardKindByPlane(cardKind, sortedCardList, CardKind.PLANE_EMPTY)
    return retList

def RemoveList(List, NeedRemove):
    list1 = List[:]
    for i in range(0, len(NeedRemove)):
        list1.remove(NeedRemove[i])
    return list1


# TODO 对于飞机，现在假定无牌能管
def getCoverableCardKindByPlanePlus1(cardKind, sortedCardList):
    retList = [][:]
    retList1 = [][:]
    planeList = getCoverableCardKindByPlane(cardKind, sortedCardList, CardKind.PLANE_PLUS1)[:]
    if planeList == []:
        return retList
    elif len(planeList[0]) == 6:
        for i in range(0, len(planeList)):
            listremove = RemoveList(sortedCardList, planeList[i])
            listsingle = list(itertools.combinations(listremove, 2))
            for j in range(0, len(listsingle)):
                if 30 not in listsingle[j] and 40 not in listsingle[j]:
                    list1 = planeList[i][:]
                    list1.append(listsingle[j][0])
                    list1.append(listsingle[j][1])
                    retList.append(list1)
        for i in range(0, len(retList)):
            if retList[i].count(retList[i][0]) != 4 and retList[i].count(retList[i][3]) != 4:
                retList1.append(retList[i])
        return retList1
    elif len(planeList[0]) == 9:
        listremove = RemoveList(sortedCardList, planeList[0])
        listsingle = list(itertools.combinations(listremove, 3))
        for j in range(0, len(listsingle)):
            if 30 not in listsingle[j] and 40 not in listsingle[j]:
                list1 = planeList[0][:]
                list1.append(listsingle[j][0])
                list1.append(listsingle[j][1])
                list1.append(listsingle[j][2])
                retList.append(list1)
        for i in range(0, len(retList)):
            if retList[i].count(retList[i][0]) != 4 and retList[i].count(retList[i][3]) != 4 and retList[i].count(retList[i][6]) != 4:
                retList1.append(retList[i])
        # print(retList1)
        return retList1
    elif len(planeList[0]) == 12:
        listremove = RemoveList(sortedCardList, planeList[0])
        listsingle = list(itertools.combinations(listremove, 4))
        for j in range(0, len(listsingle)):
            if 30 not in listsingle[j] and 40 not in listsingle[j]:
                list1 = planeList[0][:]
                list1.append(listsingle[j][0])
                list1.append(listsingle[j][1])
                list1.append(listsingle[j][2])
                list1.append(listsingle[j][3])
                retList.append(list1)
        for i in range(0, len(retList)):
            if retList[i].count(retList[i][0]) != 4 and retList[i].count(retList[i][3]) != 4 and retList[i].count(
                    retList[i][6]) != 4 and retList[i].count(retList[i][3]) != 4:
                retList1.append(retList[i])
        # print(retList1)
        return retList1
    else:
        return []


def getPairs(sortedcardlist):
    retList = []
    PairList = []
    for i in range(0, len(sortedcardlist)):
        if sortedcardlist.count(sortedcardlist[i]) >= 2:
            PairList.append([sortedcardlist[i], sortedcardlist[i]])
    for i in range(0, len(PairList)):
        if PairList[i] not in retList:
            retList.append(PairList[i])
    return retList


def getCoverableCardKindByPlanePlus2(cardKind, sortedCardList):
    retList = [][:]
    planeList = getCoverableCardKindByPlane(cardKind, sortedCardList, CardKind.PLANE_PLUS2)
    if planeList == []:
        return retList
    elif len(planeList[0]) == 6:
        for i in range(0, len(planeList)):
            listremove = RemoveList(sortedCardList, planeList[i])
            Pairs = getPairs(listremove)
            # print(Pairs)
            listPairs = list(itertools.combinations(Pairs, 2))
            if len(Pairs) >= len(cardKind) / 5:
                for j in range(0, len(listPairs)):
                    list1 = planeList[i][:]
                    list1.append(listPairs[j][0][0])
                    list1.append(listPairs[j][0][1])
                    list1.append(listPairs[j][1][0])
                    list1.append(listPairs[j][1][1])
                    retList.append(list1)
        return retList
    elif len(planeList[0]) == 9:
        listremove = RemoveList(sortedCardList, planeList[0])
        Pairs = getPairs(listremove)
        print(Pairs)
        listPairs = list(itertools.combinations(Pairs, 3))
        if len(Pairs) >= len(cardKind) / 5:
            for j in range(0, len(listPairs)):
                list1 = planeList[0][:]
                list1.append(listPairs[j][0][0])
                list1.append(listPairs[j][0][1])
                list1.append(listPairs[j][1][0])
                list1.append(listPairs[j][1][1])
                list1.append(listPairs[j][2][0])
                list1.append(listPairs[j][2][1])
                retList.append(list1)
        return retList
    elif len(planeList[0]) == 12:
        listremove = RemoveList(sortedCardList, planeList[0])
        Pairs = getPairs(listremove)
        # print(Pairs)
        listPairs = list(itertools.combinations(Pairs, 4))
        if len(Pairs) >= len(cardKind) / 5:
            for j in range(0, len(listPairs)):
                list1 = planeList[0][:]
                list1.append(listPairs[j][0][0])
                list1.append(listPairs[j][0][1])
                list1.append(listPairs[j][1][0])
                list1.append(listPairs[j][1][1])
                list1.append(listPairs[j][2][0])
                list1.append(listPairs[j][2][1])
                list1.append(listPairs[j][3][0])
                list1.append(listPairs[j][3][1])
                retList.append(list1)
        return retList

# 找炸弹
def getCoverableCardKindByBomb(cardKind, sortedCardList):
    retList = []
    cardKeyValue = cardKind[0]
    length = len(sortedCardList)
    index = 0
    while index < length-3:
        value = sortedCardList[index]
        if value > cardKeyValue and value == sortedCardList[index+3]:
            retList.append([value, value, value, value])
            index += 4
        else:
            index += 1
    return retList

# 找火箭，返回[] 或者[[30,40]]
def getRocketList(sortedCardList):
    retList = []
    if len(sortedCardList) >= 2 and sortedCardList[-1] == CardValue.Card_R and sortedCardList[-2] == CardValue.Card_B:
        retList.append(ConstCard.CARD_ROCKET)
    return retList


def isCarrier(cardWeight):
    if cardWeight >= 0.90:
        return True
    else:
        return False

# 比牌，牌型对比，即cardKindFollower > cardKindLeader ?
def canCardKindCover(cardKindFollower, cardKindLeader):
    kindLeader = getCardKind(cardKindLeader)
    kindFollwer = getCardKind(cardKindFollower)
    if kindLeader == kindFollwer:
        if cardKindFollower[0] > cardKindLeader[0] and len(cardKindFollower) == len(cardKindLeader): #顺子要求长度相等
            return True
        else:
            return False

    elif kindLeader == CardKind.ROCKET:
        return False
    elif kindFollwer == CardKind.BOMB:
        return True
    elif kindFollwer == CardKind.ROCKET:
        return True
    else: # kindLeader == CardKind.BOMB
        return False

# 从排序列表中找出所有可能的单张列表
def getSingleListFromSortedCardList(sortedCardList):
    retList = []
    length = len(sortedCardList)
    retList.append([sortedCardList[0]])
    for key in range(1, length):
        if sortedCardList[key] != sortedCardList[key-1]:
            retList.append([sortedCardList[key]])
    return retList

# 从排序列表中找出所有可能的对子列表
def getPairListFromSortedCardList(sortedCardList):
    cardKeyValue = CardValue.Card_Min
    retList = []
    length = len(sortedCardList)
    index = 0
    while index < length-1:
        value = sortedCardList[index]
        if value > cardKeyValue and value == sortedCardList[index+1]:
            retList.append([value, value])
            cardKeyValue = value  # 避免返回重复
            index += 2
        else:
            index += 1
    return retList

def isStraight(cards): #e.g [3,4,5,6,7,8,9,10]
    if len(cards) < 5:
        return 0
    for key,value in enumerate(cards):
        if value != cards[0] + key:
            return 0
    return 1

def isSingle(cards):
    if len(cards) == 1:
        return True
    else:
        return False

def isPair(cards):
    if len(cards) == 2 and cards[0] == cards[1]:
        return True
    else:
        return False

def isPairs(cards): #顺序有要求 e.g 3,3,4,4,5,5,6,6
    if len(cards) < 6 or len(cards) % 2 != 0:
        return 0
    for key,value in enumerate(cards):
        if value != cards[0] + math.floor(key / 2):
            return 0
    return 1

def hasBomb(cardKind):
    sortedCards = sorted(cardKind)
    if sortedCards[-1] == CardValue.Card_R and sortedCards[-2] == CardValue.Card_B:
        return 1
    # 因为已经排好序了，所以不需要两级循环
    for key in range(0, len(sortedCards)-4):
        if sortedCards[key] == sortedCards[key+3]: #已经排好序，所以只需要比较一头一尾即可
            return 1
    #for key in range(0, len(sortedCards)):
    #    if sortedCards.count(sortedCards[key]) >= 4 :
    #        return 1
    return 0

def isPlaneEmpty(cards): #顺序有要求e.g 3,3,3,4,4,4,5,5,5
    length = len(cards)
    if length < 6 or length % 3 != 0:
        return 0
    for key in range(0, length):
        if cards[key] != cards[0] + math.floor(key / 3): #飞机判断
            return 0

    #不允许出现四张相同的 或者 火箭
    if hasBomb(cards):
        return 0
    else:
        return 1

def isPlanePlus1(cards): #顺序有要求e.g 3,3,3,4,4,4,5,5,5,6,7,8
    length = len(cards)
    if length < 8 or length % 4 != 0:
        return 0
    size = math.floor(length / 4)
    for key in range(0, 3 * size):
        if cards[key] != cards[0] + math.floor(key / 3): #飞机判断
            return 0

    ''' #带单可以相同
    for key in range(3*size, length - 1):
        if cards[key] == cards[key + 1]:  # 带单不能相同
            return 0
    '''

    #不允许出现四张相同的 或者 火箭
    if hasBomb(cards):
        return 0
    else:
        return 1

def isPlanePlus2(cards): #顺序有要求e.g 3,3,3,4,4,4,5,5,5,6,6,7,7,9,9
    length = len(cards)
    if length < 10 or length % 5 != 0:
        return 0
    size = math.floor(len(cards) / 5)
    for key in range(0, 3 * size):
        if cards[key] != cards[0] + math.floor(key / 3): #飞机判断
            return 0

    for key in range(3*size, length - 2, 2):
        if cards[key] != cards[key+1] or cards[key] == cards[key+2]: #必须带对子
            return 0

    #不允许出现四张相同的 或者 火箭
    if hasBomb(cards):
        return 0
    else:
        return 1

def getCardKind(cards):
    length = len(cards)
    if length == 1:
        return CardKind.SINGLE
    elif length == 2 and cards[0] == cards[1]:
        return CardKind.PAIR
    elif length == 2 and cards[0] == CardValue.Card_B and cards[1] == CardValue.Card_R:
        return CardKind.ROCKET

    elif length == 3 and cards[0] == cards[1] and cards[0] == cards[2]:
        return CardKind.THREE
    elif length == 4 and cards[0] == cards[1] and cards[0] == cards[2] \
            and cards[0] != cards[3]:
        return CardKind.THREE_PLUS1
    elif length == 5 and cards[0] == cards[1] and cards[0] == cards[2] \
            and cards[0] != cards[3] and cards[3] == cards[4]:
        return CardKind.THREE_PLUS2

    elif length == 4 and cards[0] == cards[1] and cards[0] == cards[2] and cards[0] == cards[3]:
        return CardKind.BOMB
    elif length == 6 and cards[0] == cards[1] and cards[0] == cards[2] and cards[0] == cards[3] \
        and cards[0] != cards[4] and cards[4] != cards[5]:
        return CardKind.FOUR_PLUS1
    elif length == 8 and cards[0] == cards[1] and cards[0] == cards[2] and cards[0] == cards[3] \
        and cards[0] != cards[4] and cards[4] == cards[5] and cards[0] != cards[6] and cards[6] == cards[7]:
        return CardKind.FOUR_PLUS2
    #四带对，视为四带2
    elif length == 6 and cards[0] == cards[1] and cards[0] == cards[2] and cards[0] == cards[3] \
        and cards[0] != cards[4] :
        return CardKind.FOUR_PLUS2

    elif length == 0: # DUCK
        return CardKind.DUCK

    elif isStraight(cards):
        return CardKind.STRAIGHT
    elif isPairs(cards):
        return CardKind.PAIRS

    elif isPlanePlus1(cards):
        return CardKind.PLANE_PLUS1
    elif isPlanePlus2(cards):
        return CardKind.PLANE_PLUS2
    elif isPlaneEmpty(cards):
        return CardKind.PLANE_EMPTY

    else:
        print("Card Kind Invalid!", cards)
        #raise BaseException("Card Kind Invalid!")
        return CardKind.INVALID