# -*- coding: utf-8 -*-

#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-12-28
class LogUtil(object):
    def __init__(self):
        print("LogUtil Initialized")
        pass

    @staticmethod
    def logOutEnabled():
        LogUtil.logEnabled = True
        pass

    @staticmethod
    def logOutDisabled():
        LogUtil.logEnabled = False

    @staticmethod
    def Log(*args):
        if LogUtil.logEnabled == True:
            for args in args:
                print(args, sep='', end=' ')
            print()
        else:
            pass

# 默认将日志输出开关打开，即初始化为打开
LogUtil.logEnabled = True