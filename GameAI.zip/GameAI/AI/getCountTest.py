from __future__ import division
from GuessCardTest import *
import sys

def getCount(fileName):
    count = 0
    records = 0
    with open('%s' % fileName, 'r') as f:
        for eachLine in f:
            eachLine = eachLine.strip().split('|')
            firstCards, openCards, hiddenCardsList, trueValue = eachLine[0], eachLine[1], eachLine[2], eachLine[3]
            #firstCards = eachLine[0]
            firstCards = [int(x) for x in firstCards[1:-1].split(',')]
            openCards = [int(x) for x in openCards[1:-1].split(',')]
            hiddenCardsList = hiddenCardsList[1:-1]
            hiddenCardsList = hiddenCardsList.split(',')
            hiddenOne = hiddenCardsList[0]
            hiddenTwo = hiddenCardsList[1].strip()
            hiddenOne = [int(x) for x in hiddenOne[1:-1].split(',')]
            hiddenTwo = [int(x) for x in hiddenTwo[1:-1].split(',')]
            hiddenCardsList = []
            hiddenCardsList.append(hiddenOne)
            hiddenCardsList.append(hiddenTwo)
            trueValue = [int(x) for x in trueValue[1:-1].split(',')]

            guessValue = getTopSimularity(firstCards, openCards, hiddenCardsList)
            if guessValue == trueValue:
                count += 1
            else:
                count += 0
            records += 1
            print("Count: ", count, "Records: ", records)
            #if records >= 100:
            #    break
    return count
	
if __name__ == '__main__':
    fileName = sys.argv[1]
    print("FileName: ", fileName)
    count = getCount(fileName)
    print("Succeeded Count:",count)
    #sys.exit(0)
    fileCount = len(open(fileName,'rU').readlines())
    print (count / fileCount)