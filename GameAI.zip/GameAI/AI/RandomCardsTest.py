# -*- coding: utf-8 -*-
#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2017-1-19

#计算牌型概率的程序

import random
from Util.CardUtil import *
from Util.LogUtil import *

#二人斗地主牌库
_cardsLib_for_2players = (5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10,
             11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14,
             20, 20, 20, 20, 30, 40)

_cardsLib_for_3players = (3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10,
                          11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14,
                          20, 20, 20, 20, 30, 40)

# 发牌
# 输入cards为指定的地主牌
def initCardsFor2Players(cards = []):
    retList = []
    if len(cards) > 0:
        retList.append(cards)  # 地主牌
        cardsLib = list(_cardsLib_for_2players)
        for card in cards:
            cardsLib.remove(card)
        initCardsList = random.sample(cardsLib, 17)
        retList.append(initCardsList) # 二人斗地主农民牌
    else: # 没有指定地主牌，那随机发牌好了
        initCardsList = random.sample(_cardsLib_for_2players, 37)
        retList.append(initCardsList[0:20]) #二人斗地主地主牌
        retList.append(initCardsList[20:]) #二人斗地主农民牌

    for ret in retList: #排序
        ret.sort()
    return retList

# 测试发牌程序，计算火箭的概率
def testInitCards(cards, total):
    # print(cardsLib)
    count = 0
    matched = 0
    while count < total:
        count = count + 1
        slice = initCardsFor2Players(cards)
        peasants = slice[1]

        if peasants[-2] == CardValue.Card_B and peasants[-1] == CardValue.Card_R:
            for index in range(0,len(peasants)-4):
                if peasants[index] == peasants[index+3] and peasants[index] > CardValue.Card_9:
                    if matched == 0:
                        print(peasants)
                    matched += 1
                    break

    return matched

landlord_cards = [5, 6, 6, 9, 9, 9, 9, 12, 12, 12, 13, 13, 13, 14, 14, 14, 20]
#peasant_cards = [5, 5, 5, 6, 7, 7, 7, 8, 10, 10, 10, 10, 11, 11, 13, 30, 40]
matched = testInitCards(landlord_cards, 1000000) # %5的概率对手有双王+大于10的炸弹
print(matched)

