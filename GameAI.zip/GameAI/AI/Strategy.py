# -*- coding: utf-8 -*-
#Author： Wei Zhou
#Email: wilston@126.com
#Date: 2016-09-21

import random
from Util.CardUtil import *

def sortCards(cards):
    return sorted(cards)


# 合并同类项 牌型
def mergeCards(cards):
    sortedCards = sorted(cards)
    cardCombinations = []  # len 0
    index = 0
    value = sortedCards[0]
    for v in sortedCards:
        if v != value:  # append combination
            value = v
            index = index + 1

        if len(cardCombinations) > index:
            cardCombinations[index].append(v)
        else:
            cardCombinations.append([])
            cardCombinations[index].append(v)

    return cardCombinations

def extendCardCombinationForStraight(cardKind,cardCombination):
    singleList = getListByKindFromCombination(CardKind.SINGLE, cardCombination)
    min = cardKind[0]
    max = cardKind[-1]

    comb = cardCombination[:]
    kind = cardKind[:]
    bExtended = True
    while(min >= CardValue.Card_3 and bExtended == True):
        min = min - 1
        bExtended = False
        for value in singleList:
            if value[0] == min: # Extended
                comb.remove(kind)
                kind.insert(0,value[0])
                singleList.remove(value)
                comb.remove(value)
                comb.append(kind)
                comb.sort()
                bExtended = True
                kind = kind[:] # 将 kind复制一份，避免以后kind的修改影响到comb FixedBug
                break

    bExtended = True
    while(max <= CardValue.Card_A and bExtended == True):
        max = max + 1
        bExtended = False
        for value in singleList:
            if value[0] == max: # Extended
                comb.remove(kind)
                kind.append(value[0])
                singleList.remove(value)
                comb.remove(value)
                comb.append(kind)
                comb.sort()
                bExtended = True
                break

    if comb == cardCombination:
        return []
    else:
        return comb

def extendCardCombinationForPairs(cardKind, cardCombination):
    pairList = getListByKindFromCombination(CardKind.PAIR, cardCombination)
    min = cardKind[0]
    max = cardKind[-1]

    comb = cardCombination[:]
    kind = cardKind[:]
    bExtended = True
    while(min >= CardValue.Card_3 and bExtended == True):
        min = min - 1
        bExtended = False
        for value in pairList:
            if value[0] == min: # Extended
                comb.remove(kind)
                kind.insert(0,value[1])
                kind.insert(0,value[0])
                pairList.remove(value)
                comb.remove(value)
                comb.append(kind)
                comb.sort()
                bExtended = True
                break

    bExtended = True
    while(max <= CardValue.Card_A and bExtended == True):
        max = max + 1
        bExtended = False
        for value in pairList:
            if value[0] == max: # Extended
                comb.remove(kind)
                kind += value
                pairList.remove(value)
                comb.remove(value)
                comb.append(kind)
                comb.sort()
                bExtended = True
                break

    if comb == cardCombination:
        return []
    else:
        return comb

# 三张 如牌组有小中牌的单张和对子，需要带上
def extendCardCombinationForThree(cardKind, cardCombination):
    ret = []
    return ret

def extendCardCombinationForPlaneEmpty(cardKind, cardCombination):
    ret = []
    return ret

def extendCardCombinationForPlanePlus1(cardKind, cardCombination):
    ret = []
    return ret

def extendCardCombinationForPlanePlus2(cardKind, cardCombination):
    ret = []
    return ret

def extendCardCombinationForKind(cardKind,cardCombination):
    extendedCombination = []
    kind = getCardKind(cardKind)

    if kind == CardKind.STRAIGHT:
        extendedCombination = extendCardCombinationForStraight(cardKind,cardCombination)
    # 暂时废除 因为这会导致拆开的连对又合拢来
    #案例：cards = [3, 4, 6, 7, 7, 8, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 20, 30]
    #elif kind == CardKind.PAIRS:
    #    extendedCombination = extendCardCombinationForPairs(cardKind,cardCombination)

    #elif kind == CardKind.THREE: #3张需要带上单个小中牌，似乎没必要
    #    extendedCombination = extendCardCombinationForThree(cardKind, cardCombination)
    #elif kind == CardKind.PLANE_PLUS1: #飞机的自动扩充，似乎没必要
    #    extendedCombination = extendCardCombinationForPlanePlus1(cardKind, cardCombination)
    #elif kind == CardKind.PLANE_PLUS2:
    #    extendedCombination = extendCardCombinationForPlanePlus2(cardKind, cardCombination)
    #elif kind == CardKind.PLANE_EMPTY:
    #    extendedCombination = extendCardCombinationForPlaneEmpty(cardKind, cardCombination)
    else:
        return []

    if len(extendedCombination) == 0: # NOT extended
       return []
    else:
        return extendedCombination

# TODO 在已有牌组顺子/连对/飞机的情况下自由扩展(到中牌)
# 之前已经对combination中的部分已经调用过了geNatureCombination
def extendCardCombinationNaturally(cardCombination):
    ret = []
    bExtended = True
    extendedComb = cardCombination[:]

    while bExtended == True:
        bExtended = False
        for cardKind in extendedComb:
            comb = extendCardCombinationForKind(cardKind, extendedComb)
            if len(comb) == 0:
                continue
            else:
                extendedComb = comb
                bExtended = True
                break
        if bExtended == False: #该牌组已经无法自由扩展了
            ret.append(extendedComb)
    return ret

# 生成自然牌组，即不拆牌的情况下组成顺子/连对/飞机 组成火箭
def getNatureCardCombination(cards):
    cards = mergeCards(cards)
    ret = []
    delList = []
    deleted = 0

    # 匹配火箭
    length = len(cards)
    bRocket = False #火箭需要添加到最后面
    if length >= 2 and cards[-2][0] == CardValue.Card_B and cards[-1][0] == CardValue.Card_R:
        delList.append(cards[-2])
        delList.append(cards[-1])
        bRocket = True

    for key, value in enumerate(cards):
        deleted = 0
        for v in delList:
            if value == v:
                deleted = 1
                break
        if deleted == 1: continue

        # print(key,value)
        bFound = 0  # 是否自然匹配到了 顺子/连对/飞机
        cardCombination = []
        if len(value) == 3 and key + 1 < length:  # 匹配飞机
            cardCombination.append(value)
            for i in range(key + 1, length):  # range:[k+1, len(cards)), 右闭区间
                if len(cards[i]) == 3 and cards[i][0] == cards[i - 1][0] + 1:  # 满足飞机条件
                    # print(k, i, cards[i])
                    cardCombination.append(cards[i])
                    bFound = 1
                    continue
                else:
                    break
            if bFound == 1:
                delList.extend(cardCombination)
                flatCardCombination = []
                for v in cardCombination:
                    flatCardCombination += v
                # flatCardCombination = [CardKind.PLANE] + flatCardCombination
                ret.append(flatCardCombination)
            else:
                ret.append(value)

        elif len(value) == 2 and key + 2 < length:  # 匹配连对
            cardCombination.append(value)
            cardCombination.append(cards[key + 1])
            for i in range(key + 2, len(cards)):
                if len(cards[i]) == 2 and cards[i][0] == cards[i - 1][0] + 1 and len(cards[i - 1]) == 2 \
                        and cards[i - 1][0] == cards[i - 2][0] + 1:  # 满足连对条件
                    # print(k, i, cards[i])
                    cardCombination.append(cards[i])
                    bFound = 1
                    continue
                else:
                    break
            if bFound == 1:
                delList.extend(cardCombination)
                flatCardCombination = []
                for v in cardCombination:
                    flatCardCombination += v
                # flatCardCombination = [CardKind.PAIRS] + flatCardCombination
                ret.append(flatCardCombination)
            else:
                ret.append(value)

        elif len(value) == 1 and key + 4 < length:  # 匹配顺子
            cardCombination.append(value)
            cardCombination.append(cards[key + 1])
            cardCombination.append(cards[key + 2])
            cardCombination.append(cards[key + 3])
            for i in range(key + 4, length):  # 满足顺子条件
                bInvalid = False  # 先假定满足顺子条件
                for n in range(i - 3, i + 1):  # 判断 i-4 ~ i 是否能自然组成顺子
                    if len(cards[n]) != 1 or cards[n][0] != cards[n - 1][0] + 1:
                        bInvalid = True
                        break

                if bInvalid == False:
                    cardCombination.append(cards[i])
                    bFound = 1
                    # print(k, i, cardCombination)
                    continue
                else:
                    break

            if bFound == 1:
                delList.extend(cardCombination)
                flatCardCombination = []
                for v in cardCombination:
                    flatCardCombination += v
                # flatCardCombination = [CardKind.STRAIGHT] + flatCardCombination
                ret.append(flatCardCombination)
            else:
                ret.append(value)

        else:
            ret.append(value)

    if(bRocket == True):
        ret.append(ConstCard.CARD_ROCKET)
    return ret


# 返回所有可能的包含1个飞机的牌组，可拆4
def combinateCardsForPlane(cards):
    ret = []
    for len in range(2, 6 + 1): #最少2连，最多6连，因为地主也只有20张牌
        start = CardValue.Card_3
        end = CardValue.Card_A - len + 1
        for index in range(start, end+1):
            bMatched = 1
            for element in range(index, index + len):
                if cards.count(element) < 3:
                    bMatched = 0
                    break
            if bMatched == 1:
                comb = cards[:]
                pairs = []
                for element in range(index, index + len):
                    pairs.append(element)
                    pairs.append(element)
                    pairs.append(element)
                    comb.remove(element)
                    comb.remove(element)
                    comb.remove(element)
                comb.insert(0, pairs)
                ret.append(comb)
    return ret


# 返回所有可能的包含1个连对的牌组，可拆3拆4
def combinateCardsForPairs(cards):
    ret = []
    for len in range(3, 10 + 1): #最少3连对，最多10连对，因为地主也只有20张牌
        start = CardValue.Card_3
        end = CardValue.Card_A - len + 1
        for index in range(start, end+1):
            bMatched = 1
            for element in range(index, index + len):
                if cards.count(element) < 2:
                    bMatched = 0
                    break
            if bMatched == 1:
                comb = cards[:]
                pairs = []
                for element in range(index, index + len):
                    pairs.append(element)
                    pairs.append(element)
                    comb.remove(element)
                    comb.remove(element)
                comb.insert(0, pairs)
                ret.append(comb)
    return ret


# 返回所有可能的包含1个顺子的牌组，可拆2拆3拆4
def combinateCardsForStraight(cards):
    ret = []
    for len in range(5, 12 + 1): #顺子最短为5，最长为3到A，12
        start = CardValue.Card_3
        end = CardValue.Card_A - len + 1
        for index in range(start, end+1):
            bMatched = 1
            for element in range(index, index + len):
                if cards.count(element) == 0:
                    bMatched = 0
                    break
            if bMatched == 1:
                comb = cards[:]
                straight = []
                for element in range(index, index + len):
                    straight.append(element)
                    comb.remove(element)
                comb.insert(0, straight)
                ret.append(comb)
    return ret


# 按照类型组牌, 每种类型返回所有可能的包含1个目标牌型的牌组
# CardKind.PLANE_INVALID:
# CardKind.PAIRS:
# CardKind.STRAIGHT
def combinateCardsListForKind(cardsList):
    ret = []
    for cards in cardsList:
        ret += combinateCardsForPlane(cards)
    for cards in cardsList:
        ret += combinateCardsForPairs(cards)
    for cards in cardsList:
        ret += combinateCardsForStraight(cards)
    return ret


def combinateCards(cards):
    ret = []
    ret.append(cards)  # 什么都不拆的原始Cards，也要保存并返回
    cards = combinateCardsListForKind(ret)
    while (len(cards) > 0):  # 仍然有新的组合生成
        ret += cards
        cards = combinateCardsListForKind(cards)
    return ret


# cards牌组，拆牌组，根据顺子/连对/飞机 来拆2拆3拆4
# 先组牌，然后剩下的牌 自然组合
def combinateCardsList(cardsList):
    retList = []
    for cards in cardsList:
        retList += combinateCards(cards)

    # 自然归并, 即剩下的牌要组成自然牌组
    cardsList = retList
    retList = []
    for cards in cardsList:
        ret = []
        natureList = []
        for value in cards:
            if isinstance(value, list):
                ret.append(value)
            else:
                natureList.append(value)
        if len(natureList) > 0:
            # TODO 这里的disperseRet是为了解决一手春天，大飞机拆连对顺子的问题，会导致计算量暴增，不一定划算，需要慎重考虑！
            # 案例：cards = [4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 10, 11, 12, 13]  # 一手春天，Bug：因为5飞机不支持拆顺子
            '''
            if len(natureList) <= 8:
                comb = mergeCards(natureList)
                dispersedRet = ret + comb
                retList.append(dispersedRet)
            '''
            ret += getNatureCardCombination(natureList)
        retList.append(ret)

    # 排重
    retList = uniqCardCombinations(retList)
    return retList

def getListByKindFromCombination(kind, cardCombination):
    ret = []
    for cardKind in cardCombination:
        if(kind == getCardKind(cardKind)):
            ret.append(cardKind)
    return ret

# 3带1 4带2的设定
def plusCardCombinationForKind(comb):
    ret = []
    singleList = []
    pairList = []
    cardCombination = comb[:]
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        #if kind == CardKind.SINGLE and getCardClass(cardKind[0]) != CardClass.LARGE: # 中小牌单张
        if kind == CardKind.SINGLE:
            singleList.append(cardKind)
        #elif kind == CardKind.PAIR and getCardClass(cardKind[0]) != CardClass.LARGE: # 中小牌对子:
        elif kind == CardKind.PAIR: # 不支持轰炸机，即飞机带炸弹
            if len(pairList) == 0 or cardKind[0] != pairList[-1][0]:
                pairList.append(cardKind)

    # 排序，确保优先带小的
    # TODO 因为cardCombination已经排序，所以这里的排序可能不需要
    singleList.sort()
    # 有火箭不会也不能拆开来带 不支持航天飞机，即飞机带火箭
    if len(singleList) >= 2 and singleList[-1][0] == CardValue.Card_R and singleList[-2][0] == CardValue.Card_B:
        singleList.pop(-1)
        singleList.pop(-1) # remove then last one
    # TODO 因为cardCombination已经排序，所以这里的排序可能不需要
    pairList.sort()

    threeList = []
    fourList = []
    planeList = []
    for cardKind in cardCombination:
        kind = getCardKind(cardKind)
        if kind == CardKind.THREE: #三带1
            threeList.append(cardKind)
        elif kind == CardKind.BOMB: #四带2
            fourList.append(cardKind)
        elif kind == CardKind.PLANE_EMPTY: #飞机
            planeList.append(cardKind)

    # 排序，确保优先带小的
    # TODO 因为cardCombination已经排序，所以这里的排序可能不需要
    threeList.sort()
    fourList.sort()
    planeList.sort()

    for three in threeList: #找最小的带
        if len(singleList) >= 1: # TODO 单张不能和三张相等，如果相等，就当是个炸弹？
            cards = cardCombination[:]
            threePlus1 = three + singleList[0]
            cards.remove(three)
            cards.remove(singleList[0])
            cards.append(threePlus1)
            ret.append(cards)
        if len(pairList) >= 1:
            cards = cardCombination[:]
            threePlus2 = three + pairList[0]
            cards.remove(three)
            cards.remove(pairList[0])
            cards.append(threePlus2)
            ret.append(cards)

    for four in fourList: #找最小的带
        if len(singleList) >= 2 :
            cards = cardCombination[:]
            fourPlusSingle = four + singleList[0] + singleList[1]
            cards.remove(four)
            cards.remove(singleList[0])
            cards.remove(singleList[1])
            cards.append(fourPlusSingle)
            ret.append(cards)
        if len(pairList) >= 2:
            cards = cardCombination[:]
            fourPlusPair = four + pairList[0] + pairList[1]
            cards.remove(four)
            cards.remove(pairList[0])
            cards.remove(pairList[1])
            cards.append(fourPlusPair)
            ret.append(cards)
        if len(pairList) >= 1: #4带对，视为4带2
            cards = cardCombination[:]
            fourPlusPair = four + pairList[0]
            cards.remove(four)
            cards.remove(pairList[0])
            cards.append(fourPlusPair)
            ret.append(cards)

    #TODO 需要支持双飞机拆开一对来带
    for plane in planeList: #找最小的带
        length = math.floor(len(plane) / 3)
        count = 0
        # 单张不能和飞机的三张相等
        planeValueList = []
        for i in range(plane[0], plane[0]+length):
            planeValueList.append(i)
        for i in range(0, len(singleList)):
            if singleList[i][0] not in planeValueList:
                count = count + 1

        if count >= length:
        #if len(singleList) >= length:
            planePlusSingle = plane[:]
            cards = cardCombination[:]
            delList = []
            index = 0
            for m in range(0,len(singleList)):
            #for m in range(0, length):
                if singleList[m][0] not in planeValueList:
                    planePlusSingle += singleList[m]
                    delList.append(singleList[m])
                    index += 1
                if index == length:
                    break

            for item in delList:
                cards.remove(item)
            cards.remove(plane)
            cards.append(planePlusSingle)
            ret.append(cards)

        if len(pairList) >= length:
            planePlusPair = plane[:]
            cards = cardCombination[:]
            for m in range(0,length):
                planePlusPair += pairList[m]
            cards.remove(plane)
            for m in range(0,length):
                cards.remove(pairList[m])
            cards.append(planePlusPair)
            ret.append(cards)

    return ret

def plusCardCombinationsForKind(cardCombinations):
    ret = []
    for combination in cardCombinations:
        ret += plusCardCombinationForKind(combination)

    # 修复上级死循环导致卡死的BUG
    # 案例：cards = [4, 5, 5, 6, 6, 7, 8, 9, 9, 10, 11, 11, 11, 12, 12, 12, 13, 20, 20, 30] #会卡死？
    filteredRet = []
    for element in ret:
        if element not in cardCombinations:
            filteredRet.append(element)
    return filteredRet

def plusCardCombination(cardCombinations):
    ret = []
    ret.append(cardCombinations)  # 什么都不带的原始Cards，也要保存并返回
    plus = plusCardCombinationsForKind(ret)
    while (len(plus) > 0):  # 仍然有新的组合生成
        ret += plus
        plus = plusCardCombinationsForKind(plus)

    """ #如果飞机不带是合法牌型，则不需要这段代码
    length = len(ret)
    for key in range(length-1, -1, -1): #从高到低遍历，过滤掉无效的牌组
        cardCombination = ret[key]
        for value in cardCombination:
            if getCardKind(value) == CardKind.PLANE_INVALID:
                ret.pop(key)
                break
    """
    return ret

# 3带1 4带2的设定plus
def plusCardCombinations(cardCombinations):
    ret = []
    #index = 0
    for cardCombination in cardCombinations:
        plus = plusCardCombination(cardCombination)
        ret += plus
        #index += 1 #用于条件断点调试
        #print("CardCombination:", cardCombination)

    # 排重
    ret = uniqCardCombinations(ret)
    return ret


# 拆大牌？
# 含中牌的连对飞机可主动拆，
# 中牌三张可主动拆为单加对
# 对子可拆开，只拆一个对
def adjustCardKind(cardKind, gameInfo=None):
    kind = getCardKind(cardKind)
    ret = []
    tempRet = []
    tempRet.append(cardKind)
    ret.append(tempRet)  # 第1种组合，不拆

    if kind == CardKind.THREE and getCardClass(cardKind[0]) == CardClass.MIDDLE:  # 中牌三张,拆成单加对
        tempRet = []
        tempRet.append(cardKind[0:1])  # 第2种组合 拆出1个单张和1对
        tempRet.append(cardKind[1:3])
        ret.append(tempRet)
    # print(ret)

    elif kind == CardKind.PAIRS:
        length = len(cardKind)
        size = math.floor(len(cardKind) / 2)
        if getCardClass(cardKind[-1]) == CardClass.MIDDLE:  # 含中牌的连对可拆开
            while size > 3 and getCardClass(cardKind[size * 2 - 1]) == CardClass.MIDDLE:
                size = size - 1
                tempRet = []
                part = []
                for key in range(0, 2 * size):  # 拆剩下的连对
                    part.append(cardKind[key])
                tempRet.append(part)

                for key in range(2 * size, length, 2):  # 拆剩下的对子
                    part = []
                    part.append(cardKind[key])
                    part.append(cardKind[key + 1])
                    tempRet.append(part)
                ret.append(tempRet)

            if size <= 3 and getCardClass(cardKind[size * 2 - 1]) == CardClass.MIDDLE:  # 如果除掉中牌对之后<3对，则拆散之
                tempRet = []
                for key in range(0, length, 2):
                    part = []
                    part.append(cardKind[key])
                    part.append(cardKind[key + 1])
                    tempRet.append(part)  # 拆散连对
                ret.append(tempRet)

    elif kind == CardKind.PLANE_EMPTY:  # 中牌飞机可以拆
        length = len(cardKind)
        size = math.floor(len(cardKind) / 3)
        if getCardClass(cardKind[length - 1]) == CardClass.MIDDLE:  # 含中牌的飞机可拆开
            while (size > 2 and getCardClass(cardKind[3 * size - 1]) == CardClass.MIDDLE):
                size = size - 1
                tempRet = []
                part = []
                for key in range(0, 3 * size):  # 拆剩下的飞机
                    part.append(cardKind[key])
                tempRet.append(part)

                for key in range(3 * size, length, 3):  # 拆剩下的三张
                    part = []
                    part.append(cardKind[key])
                    part.append(cardKind[key + 1])
                    part.append(cardKind[key + 2])
                    tempRet.append(part)
                ret.append(tempRet)

            if size <= 2 and getCardClass(cardKind[3 * size - 1]) == CardClass.MIDDLE:  # 拆开中牌飞机之后，剩下的三张小于2，则拆散之
                tempRet = []
                for key in range(0, length, 3):
                    part = []
                    part.append(cardKind[key])
                    part.append(cardKind[key + 1])
                    part.append(cardKind[key + 2])
                    tempRet.append(part)  # 拆散飞机
            ret.append(tempRet)

    elif getCardClass(cardKind[0]) == CardClass.LARGE:  # 大牌拆散
        tempRet = []
        if kind == CardKind.ROCKET:
            tempRet.append(cardKind[0:1])  # 第2种组合 拆成两个王
            tempRet.append(cardKind[1:2])
            ret.append(tempRet)
        elif kind == CardKind.PAIR:
            tempRet.append(cardKind[0:1])  # 第2种组合 拆成两个单张
            tempRet.append(cardKind[1:2])
            ret.append(tempRet)
        elif kind == CardKind.THREE:
            tempRet.append(cardKind[0:1])  # 第2种组合 拆成1个单张+1对
            tempRet.append(cardKind[1:3])
            ret.append(tempRet)
            tempRet = []
            tempRet.append(cardKind[0:1])  # 第3种组合 拆成3个单张
            tempRet.append(cardKind[1:2])
            tempRet.append(cardKind[2:3])
            ret.append(tempRet)
        elif kind == CardKind.BOMB:
            tempRet.append(cardKind[0:1])  # 第2种组合 拆成1个3张+单张
            tempRet.append(cardKind[1:4])
            ret.append(tempRet)
            tempRet = []
            tempRet.append(cardKind[0:2])  # 第3种组合 拆成2个对
            tempRet.append(cardKind[2:4])
            ret.append(tempRet)
            tempRet = []
            tempRet.append(cardKind[0:1])  # 第4种组合 拆成4个单张
            tempRet.append(cardKind[1:2])
            tempRet.append(cardKind[2:3])
            tempRet.append(cardKind[3:4])
            ret.append(tempRet)

    # TODO 所有条件下拆对子的话，可能会导致计算量暴增, 单局从1秒增长到3秒
    elif kind == CardKind.PAIR:
        '''
        tempRet = []
        tempRet.append(cardKind[0:1])  # 第2种组合 拆成两个单张
        tempRet.append(cardKind[1:2])
        ret.append(tempRet)
        '''
        if gameInfo and gameInfo.getOpponentRestCardsLength() == 2: #对手只剩两张牌时，需要拆对
            tempRet = []
            tempRet.append(cardKind[0:1])  # 第2种组合 拆成两个单张
            tempRet.append(cardKind[1:2])
            ret.append(tempRet)
        elif getCardClass(cardKind[0]) == CardClass.MIDDLE and gameInfo and gameInfo.getPlayedTotalTurns() >= 4: #第4轮残局阶段才考虑拆中对
            tempRet = []
            tempRet.append(cardKind[0:1])  # 第2种组合 拆成两个单张
            tempRet.append(cardKind[1:2])
            ret.append(tempRet)
    return ret


def adjustCardCombination(cardCombination, gameInfo):
    ret = [[]]  # 二维数组，实际返回的是三维数组，定义为二维是为了方便eunumerate
    for value in cardCombination:
        cardKinds = adjustCardKind(value, gameInfo)  # 裂变
        tempRet = []
        for comb in cardKinds:  # 倍乘
            for key, combination in enumerate(ret):
                tempCombination = combination[:]
                tempCombination = tempCombination + comb
                tempRet.append(tempCombination)
        ret = tempRet
    return ret

# 自然扩展牌组并去重
def uniqCardCombinations(cardCombinations):
    ret = []
    # ret = cardCombinations[:]
    for key, value in enumerate(cardCombinations):
        extendedCombs = extendCardCombinationNaturally(value)  # 自然扩展
        if len(extendedCombs) > 0: # extended
            ret += extendedCombs
        else:
            ret.append(value)

    # 排序，该排序可能不需要
    #ret.sort()
    # 可能不需要对每个元素排序
    for value in ret:
        value.sort()

    #for key in range(len(ret) -1,  -1, -1):
    #    if ret.count(ret[key]) > 1:
    #        ret.remove(ret[key])
    #return ret

    uniqRet = []
    for value in ret:
        if value not in uniqRet:
            uniqRet.append(value)
    return uniqRet


# 按照以下规则对牌组重新调整
# 含中牌的连对可主动拆，
# 中牌三张可主动拆为单加对
def adjustCardCombinations(cardCombinations, gameInfo=None):
    ret = []
    # 第一轮，拆开飞机 可能的中牌三张拆单+对
    first = []
    for cardCombination in cardCombinations:
        first += adjustCardCombination(cardCombination, None)

    # 第二轮，主要是对第一轮拆开的飞机 再做可能的中牌三张拆单+对
    # for key,value in enumerate(ret):
    #	print("First:", key, value)
    for cardCombination in first:
        ret += adjustCardCombination(cardCombination,gameInfo)

    # 排重
    ret = uniqCardCombinations(ret)
    return ret