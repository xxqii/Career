#!/usr/bin/python
#encoding=utf-8

import subprocess
import sys
import re
#reload(sys)
#sys.setdefaultencoding("utf8")

def getEndFile(pdate):
    hsql1 = "hadoop fs -get /data/rawlog/card/ddz_two_end/pdate=%s/%s" % (pdate, pdate)
    subprocess.call(hsql1, shell=True)
    hsql2 = "mv %s %s_end" % (pdate, pdate)
    subprocess.call(hsql2, shell=True)

def getPokerFile(pdate):
    hsql1 = "hadoop fs -get /data/rawlog/card/ddz_two_pokers/pdate=%s/%s" % (pdate, pdate)
    subprocess.call(hsql1, shell=True)
    hsql2 = "mv %s %s_poker" % (pdate, pdate)
    subprocess.call(hsql2, shell=True)

def getLastPoker(inputPokerFile):
    logId_lastPoker_Map = {}
    with open('%s' % inputPokerFile, 'r') as f:
        for eachLine in f:
            eachLine = eachLine.strip().split('|')
            logId = eachLine[4]
            outPokerOrder = eachLine[9]
            line = outPokerOrder.split(',')
            lastPoker = line[-3]
            logId_lastPoker_Map[logId] = lastPoker
    return logId_lastPoker_Map

def numberAddword(temp_number, temp_word, temp):
    number = " ".join(temp_number.split(temp)).strip()
    word = " ".join(temp_word.split(temp)).strip()
    numberOne = "".join(number.split())
    wordOne = "".join(word.split())
    return numberOne + wordOne

def processFile(inputEndFile, inputPokerFile):
    logId_lastPoker_Map = getLastPoker(inputPokerFile)
    myPoker = ""
    winnerPoker = ""
    residualPoker = ""
    with open('%s' % inputEndFile, 'r') as f:
        for eachLine in f:
            eachLine = eachLine.replace('_小王', 'X')
            eachLine = eachLine.replace('_大王', 'D')
             
            eachLine = eachLine.strip().split('|') 
            logId = eachLine[4]
            handPokers = eachLine[8]
            bottomPokers = eachLine[10]
            abandonPokers = eachLine[11]
            landlordDouble = eachLine[13]
            landlordId = eachLine[19]
            winnerId = eachLine[20]
            if landlordDouble == ' 1' and logId in logId_lastPoker_Map:
                playerOne, playerTwo, other = handPokers.split(',')
                playerOneId, playerOnePoker = playerOne.split('=')
                playerTwoId, playerTwoPoker = playerTwo.split('=')

                lastHandPoker = logId_lastPoker_Map[logId]
                lastHandPoker = lastHandPoker.replace('_小王', 'X')
                lastHandPoker = lastHandPoker.replace('_大王', 'D')

                lasthand_line = lastHandPoker.strip().decode('utf-8', 'ignore')
                one_line = playerOnePoker.strip().decode('utf-8', 'ignore')
                two_line = playerTwoPoker.strip().decode('utf-8', 'ignore')
                bottom_line = bottomPokers.strip().decode('utf-8', 'ignore')
                abandon_line = abandonPokers.strip().decode('utf-8', 'ignore')
                temp_number = re.compile(ur'[^\u0030-\u0039]')
                temp_word = re.compile(ur'[^\u0041-\u005a]')
                
                lasthand_poker = numberAddword(temp_number, temp_word, lasthand_line)
                one_poker = numberAddword(temp_number, temp_word, one_line) 
                two_poker = numberAddword(temp_number, temp_word, two_line) 
                last_bottom = numberAddword(temp_number, temp_word, bottom_line)
                abandon_poker = numberAddword(temp_number, temp_word, abandon_line)

                residualPoker = abandon_poker
                if playerOneId == landlordId and playerOneId == winnerId:
                    myPoker = two_poker
                    winnerPoker = one_poker + last_bottom
                    print logId, myPoker, winnerPoker, abandon_poker, lasthand_poker
                elif playerOneId == landlordId and playerTwoId == winnerId:
                    myPoker = one_poker + last_bottom
                    winnerPoker = two_poker 
                    print logId, myPoker, winnerPoker, abandon_poker, lasthand_poker
                elif playerTwoId == landlordId and playerTwoId == winnerId:
                    myPoker = one_poker
                    winnerPoker = two_poker + last_bottom
                    print logId, myPoker, winnerPoker, abandon_poker, lasthand_poker
                else:
                    myPoker = two_poker + last_bottom
                    winnerPoker = one_poker
                    print logId, myPoker, winnerPoker, abandon_poker, lasthand_poker
               
if __name__ == '__main__':
    pdate = sys.argv[1]
    inputEndFile = pdate + '_end'
    inputPokerFile = pdate + '_poker'
    getEndFile(pdate) 
    getPokerFile(pdate)
    getLastPoker(inputPokerFile)
    processFile(inputEndFile, inputPokerFile)
    #landlordDouble, myPoker, winnerPoker, residualPoker = processFile(inputFile)    
    #print landlordDouble, myPoker, winnerPoker, residualPoker
