import tensorflow as tf
import numpy as np
import sys
import csv

tf.logging.set_verbosity(tf.logging.INFO)

DATA_SET_FILE_NAME = "10wan_feature_label.csv"

reader=csv.reader(open(DATA_SET_FILE_NAME,'rb')) 

data_set=np.array([line for line in reader]).astype('int')

n=len(data_set)

training_n = int(n*0.8)
training_set=data_set[0:training_n,:]

test_set=data_set[training_n:,:]

training_set_x = training_set[:, 0:3].astype('float32')
training_set_y = training_set[:,3]-1

test_set_x = test_set[:,0:3].astype('float32')
test_set_y = test_set[:,3]-1

feature_columns = [tf.contrib.layers.real_valued_column("", dimension=3)]

classifier = tf.contrib.learn.DNNClassifier(feature_columns=feature_columns,
                                            hidden_units=[5, 5],
                                            n_classes=7,
                                            optimizer=tf.train.ProximalAdagradOptimizer(
                                            	learning_rate=0.05,
                                            	l1_regularization_strength=0.05
                                            	))

classifier.fit(x=training_set_x,
               y=training_set_y,
               steps=8000)

accuracy_score_train = classifier.evaluate(x=training_set_x,
                                     y=training_set_y)["accuracy"]
print('train set: Accuracy: {0:f}'.format(accuracy_score_train))

accuracy_score_test = classifier.evaluate(x=test_set_x,
                                     y=test_set_y)["accuracy"]
print('test set: Accuracy: {0:f}'.format(accuracy_score_test))